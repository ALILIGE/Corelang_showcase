// ======================================================================
// dsl.cpp -- DSLFrontend Dogrulama ve DSLDispatcher Implementasyonu
// ======================================================================
// [UPGRADE v2] Değişiklikler (mevcut DSL'leri kırmayan):
//
//  1. DSLDispatcher constructor → DSLRegistry kullanır.
//     registerFaz2DSLs / registerBridgeDSLs imzası DSLRegistry& alır.
//     startup'ta validateDependencies() çağrılır.
//
//  2. lowerStmt() → canHandleStmt() ile guard edilir (SAHTE-4 kalıcı fix).
//     Mevcut Faz1 DSL'ler canHandleStmt() override etmez → etkilenmez.
//
//  3. findByNamespace() + buildNsCache() → TypeChecker inline registry yerine
//     DSL'lerin kendi describe() verisini kullanır; tek kaynak of truth.
// ======================================================================

#include "dsl.h"
#include "dsl_registry.h"
#include "dsl_faz2.h"
#include "bridge_dsl.h"
#include "../core/diagnostics.h"
#include "../frontend/ast.h"
// F1 DSL kayıt: f1_dsl.cpp::registerF1DSLs — API uyumluluğu için oraya taşındı

#include "dsl_quantum.h"
#include <string>

namespace corelang::dsl {

// ── DSLFrontend::validate ─────────────────────────────────────────────────────
bool DSLFrontend::validate(const CallSiteCtx& ctx) const {
    return DSLVerifier::check(describe(), ctx);
}

// ── DSLVerifier::check ────────────────────────────────────────────────────────
// TASARIM NOTU: Bu fonksiyon ile TypeChecker::checkDSLCallSite() ayni
// context/privilege/target mantığını iki farkli yerde uguluyor.
// Bu intentional — iki ayri guvenlik katmani:
//   1. checkDSLCallSite(): PARSE-TIME check — kaynak koda bakar, hata mesaji uretir.
//   2. DSLVerifier::check(): LOWERING-TIME check — IR uretimi oncesi son bariyer.
// Birisi guncellenmeden digeri atlanirsa check eksik kalir.
// HER IKISINI GUNCELLEMEYI UNUTMAYIN.
// Fix 9: FreestandingOk target req burada check edilmez — intentional.
//   FreestandingOk "bu DSL freestanding ortamda da calisir" anlaminda pozitif flag,
//   "sadece freestanding'de calisir" seklinde negatif kisitlama degil.
//   Dolayisiyla target uyumluluk check'e girmesi yanlis olur.
bool DSLVerifier::check(const DSLCapabilityDescriptor& desc,
                        const CallSiteCtx& ctx) {
    auto& diag = Diagnostics::get();

    // 1. Context check
    if (desc.allowedContexts != DSLContext::Any &&
        !contextAllowed(desc.allowedContexts, ctx.fnContext)) {
        std::string msg = std::string("DSL '") + desc.name +
            "' is not allowed in " + dslContextName(ctx.fnContext);
        if (desc.contextRestrictionReason)
            msg += std::string(": ") + desc.contextRestrictionReason;
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }

    // 2. Privilege check
    if (desc.privilege == DSLPrivilege::Ring0 &&
        ctx.privilege != DSLPrivilege::Ring0) {
        std::string msg = std::string("DSL '") + desc.name +
            "' requires Ring0 privilege; current function '" +
            ctx.fnName + "' is not marked as kernel/Ring0";
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }
    if (desc.privilege == DSLPrivilege::Ring3 &&
        ctx.privilege == DSLPrivilege::Ring0) {
        diag.warn(ctx.srcFile, ctx.line, ctx.col,
            std::string("DSL '") + desc.name +
            "' is intended for user-mode; calling from Ring0 context");
    }
    if (desc.privilege == DSLPrivilege::GPU &&
        ctx.fnContext != DSLContext::GPUDevice) {
        std::string msg = std::string("DSL '") + desc.name +
            "' is only valid inside a GPU device kernel";
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }

    // 3. Target check
    if (desc.targetReq == DSLTargetReq::X86Only &&
        ctx.target != DSLTargetReq::X86Only) {
        std::string msg = std::string("DSL '") + desc.name +
            "' requires x86/x86-64 target architecture";
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }
    if (desc.targetReq == DSLTargetReq::LinuxABI &&
        ctx.target != DSLTargetReq::LinuxABI) {
        std::string msg = std::string("DSL '") + desc.name +
            "' requires Linux ABI target";
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }
    if ((desc.targetReq == DSLTargetReq::NVIDIACuda ||
         desc.targetReq == DSLTargetReq::VulkanSPIRV ||
         desc.targetReq == DSLTargetReq::AnyGPU) &&
        ctx.fnContext != DSLContext::GPUDevice &&
        ctx.fnContext != DSLContext::GPUHost) {
        std::string msg = std::string("DSL '") + desc.name +
            "' requires a GPU target";
        diag.error(ctx.srcFile, ctx.line, ctx.col, msg);
        return false;
    }

    return true;
}

// ── DSLDispatcher constructor ─────────────────────────────────────────────────
// [UPGRADE v2] DSLRegistry üzerinden kayıt + startup dep validation.
DSLDispatcher::DSLDispatcher() {
    DSLRegistry reg;

    // Faz 1 DSLs
    reg.add(std::make_unique<IntegerDSL>());
    reg.add(std::make_unique<StringDSL>());
    reg.add(std::make_unique<FloatDSL>());
    reg.add(std::make_unique<MemoryDSL>());
    reg.add(std::make_unique<IODSL>());
    reg.add(std::make_unique<SyscallDSL>());
    reg.add(std::make_unique<AtomicDSL>());
    reg.add(std::make_unique<ThreadDSL>());
    reg.add(std::make_unique<TrustDSL>());

    // Stub DSL'ler — call-site context/privilege check sağlar, lowering yok.
    // gpio, warp, mmio, x86 namespace'leri sadece TypeChecker registry'sinde
    // vardı; artık dispatcher da bunları findByNamespace() ile buluyor.
    reg.add(std::make_unique<GpioDSL>());
    reg.add(std::make_unique<WarpDSL>());
    reg.add(std::make_unique<MmioDSL>());
    reg.add(std::make_unique<X86DSL>());
    reg.add(std::make_unique<NetworkDSL>());

    // Faz 2 + Bridge DSLs
    registerFaz2DSLs(reg);
    registerBridgeDSLs(reg);

    // F1 Lang DSL'leri — telemetri, lap, sim
    // F1 DSL'ler ayrı kayıt mekanizmasıyla eklenir (irgen init sırasında)

    registerQuantumDSL(reg);  // Quantum DSL — quantum<T> süperpozisyon tipi

    // requiresDSL bağımlılıklarını startup'ta doğrula.
    // Eksik dep → stderr + std::abort().
    reg.validateDependencies();

    dsls_ = reg.release();
}

// Helper to extract namespace from a call/field expression
static std::string getNamespaceFromExpr(const Expr* e) {
    if (!e || e->kind != Expr::Kind::Call) return "";
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee) return "";
    if (call->callee->kind == Expr::Kind::Field) {
        auto* field = static_cast<const FieldExpr*>(call->callee.get());
        if (field->base && field->base->kind == Expr::Kind::Ident) {
            return static_cast<const IdentExpr*>(field->base.get())->name;
        }
    } else if (call->callee->kind == Expr::Kind::ScopeResolution) {
        return static_cast<const ScopeResolutionExpr*>(call->callee.get())->typeName;
    }
    return "";
}

// Helper to extract namespace for stmt-like DSL calls (if needed)
static std::string getNamespaceFromStmt(const Stmt* s) {
    // For now, no known stmt DSLs that use namespace; return empty
    (void)s;
    return "";
}

// ── canHandle ────────────────────────────────────────────────────────────────
bool DSLDispatcher::canHandle(const Expr* e) const {
    if (!nsCacheBuilt_) buildNsCache();

    // First try O(1) namespace-based lookup
    std::string ns = getNamespaceFromExpr(e);
    if (!ns.empty()) {
        auto it = dslCache_.find(ns);
        if (it != dslCache_.end()) {
            if (it->second->canHandle(e)) return true;
        }
    }

    // Fallback for DSLs without namespace (like TrustDSL)
    for (auto& dsl : dsls_) {
        auto desc = dsl->describe();
        if (!desc.namespacePrefix || desc.namespacePrefix[0] == '\0') {
            if (dsl->canHandle(e)) return true;
        }
    }

    return false;
}

// ── lowerExpr ────────────────────────────────────────────────────────────────
llvm::Value* DSLDispatcher::lowerExpr(const Expr* e, void* irCtx,
                                       const CallSiteCtx& siteCtx) {
    if (!nsCacheBuilt_) buildNsCache();

    // First try O(1) namespace-based lookup
    std::string ns = getNamespaceFromExpr(e);
    if (!ns.empty()) {
        auto it = dslCache_.find(ns);
        if (it != dslCache_.end()) {
            if (it->second->canHandle(e)) {
                if (!it->second->validate(siteCtx)) return nullptr;
                return it->second->lowerExpr(e, irCtx);
            }
        }
    }

    // Fallback for DSLs without namespace (like TrustDSL)
    for (auto& dsl : dsls_) {
        auto desc = dsl->describe();
        if (!desc.namespacePrefix || desc.namespacePrefix[0] == '\0') {
            if (!dsl->canHandle(e)) continue;
            if (!dsl->validate(siteCtx)) return nullptr;
            return dsl->lowerExpr(e, irCtx);
        }
    }

    return nullptr;
}

// ── lowerStmt ────────────────────────────────────────────────────────────────
// [UPGRADE v2] SAHTE-4 FIX'in kalıcı çözümü.
//
// Eski: her DSL'in lowerStmt()'i kör biçimde deniyordu.
//   → N DSL × M stmt gereksiz çağrı; sessiz hata riski.
//
// Yeni: canHandleStmt(s) == true olan ilk DSL işler ve durulur.
//   Mevcut Faz1 DSL'ler canHandleStmt() override etmediğinden false döner
//   ve lowerStmt çağrılmaz — davranışları değişmez.
//   Stmt DSL'leri (DistortDSL) canHandleStmt() override eder.
//   validate() burada da uygulanır.
void DSLDispatcher::lowerStmt(const Stmt* s, void* irCtx,
                               const CallSiteCtx& siteCtx) {
    // TASARIM NOTU: irgen.cpp şu an dslDispatch_.lowerStmt() ÇAĞIRMIYOR.
    // DistortStmt gibi DSL stmt'leri irgen_dsl.cpp içinde lowerDistortStmt()
    // gibi özel fonksiyonlarla işleniyor. Bu dispatcher metodu dolayısıyla
    // şu an dead path — ama DOĞRU tasarlanmış: ilerleyen bir refactor'da
    // irgen.cpp DSL stmt'lerini buraya delege edebilir.
    // canHandleStmt() guard'ı o refactor için hazır durumda.
    if (!s) return;

    // First try O(1) namespace-based lookup (if applicable for stmt DSLs)
    std::string ns = getNamespaceFromStmt(s);
    if (!ns.empty()) {
        if (!nsCacheBuilt_) buildNsCache();
        auto it = dslCache_.find(ns);
        if (it != dslCache_.end()) {
            if (it->second->canHandleStmt(s)) {
                if (!it->second->validate(siteCtx)) return;
                it->second->lowerStmt(s, irCtx);
                return;
            }
        }
    }

    // Fallback to linear scan
    for (auto& dsl : dsls_) {
        if (!dsl->canHandleStmt(s)) continue;
        if (!dsl->validate(siteCtx)) return;
        dsl->lowerStmt(s, irCtx);
        return; // ilk eslesen isler
    }
    // Hicbir DSL tanımadı -> irgen kendi isler (normal durum)
}

// ── buildNsCache ─────────────────────────────────────────────────────────────
// descStore_ ve nsCache_'i doldurur. Tembel baslatma: ilk findByNamespace
// cagrisinda tetiklenir.
//
// Neden descStore_ (DSLRegistry::descs_'den ayri)?
//   DSLRegistry construction-time'da yasayan gecici bir yapı:
//   add() ile dolup release() ile bosaliyor.
//   descStore_ ise DSLDispatcher'in kalici bellegi:
//   findByNamespace() cagrilarina karsi stable pointer saglar.
//   Iki ayri cache — intentional: registry construction garantisi saglar,
//   descStore_ runtime lookup saglar.
//
// describe() neden tekrar cagriliyor (registry'den almak yerine)?
//   DSLRegistry::release() cagrilinca descs_ bosaliyor.
//   Dispatcher bunlara erisemez. Bu yuzden dispatcher kendi kopyasini tutar.
void DSLDispatcher::buildNsCache() const {
    descStore_.clear();
    nsCache_.clear();
    dslCache_.clear();

    // Adım 1: tüm descriptor'ları descStore_'a kopyala.
    // reserve() sonradan push_back'in realloc yapmamasını sağlar →
    // pointer stabilitesi: &descStore_[i] invalidate olmaz.
    descStore_.reserve(dsls_.size());
    for (size_t i = 0; i < dsls_.size(); ++i) {
        descStore_.push_back(dsls_[i]->describe());
    }

    // Adım 2: namespacePrefix dolu olanları nsCache_ ve dslCache_'e ekle.
    for (size_t i = 0; i < dsls_.size(); ++i) {
        const auto& desc = descStore_[i];
        if (!desc.namespacePrefix || desc.namespacePrefix[0] == '\0') continue;
        std::string key(desc.namespacePrefix);
        if (nsCache_.count(key)) {
            llvm::errs() << "[DSLDispatcher] WARNING: duplicate namespacePrefix '"
                         << key << "' (DSL: '" << desc.name
                         << "'). Her namespace sadece bir DSL'e ait olmali.\n";
        }
        nsCache_[key] = &desc;
        dslCache_[key] = dsls_[i].get();
    }

    nsCacheBuilt_ = true;
}

// ── findByNamespace ───────────────────────────────────────────────────────────
// [UPGRADE v2] TypeChecker'ın inline registry'sini kaldırır.
//
// Kullanım (type_checker.cpp):
//   const auto* desc = dslDispatcher_.findByNamespace("syscall");
//   if (!desc) return;
//   // context/privilege/target check — aynı mantık, ama artık tek kaynak
//
// nullptr dönüşü: bilinmeyen namespace → TypeChecker sessizce devam eder.
const DSLCapabilityDescriptor* DSLDispatcher::findByNamespace(
        const std::string& ns) const {
    if (!nsCacheBuilt_) buildNsCache();
    auto it = nsCache_.find(ns);
    return it != nsCache_.end() ? it->second : nullptr;
}


// ═══════════════════════════════════════════════════════════════════════════════
// Faz 1 DSL canHandle() implementasyonlari
// ═══════════════════════════════════════════════════════════════════════════════
// lowerExpr() implementasyonlari dsl_lowering.cpp dosyasindadir.
// Bu ayirim:
//   - dsl.cpp: dispatcher mekanizmasi + canHandle() (LLVM bagimli degil)
//   - dsl_lowering.cpp: IR emit (LLVM IRBuilder gerektirir)
// Amac: runtime/platform varyasyonu icin sadece dsl_lowering.cpp degistirilir.

static bool isCallTo(const Expr* e, const std::string& ns) {
    if (!e || e->kind != Expr::Kind::Call) return false;
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee) return false;
    if (call->callee->kind == Expr::Kind::Field) {
        auto* field = static_cast<const FieldExpr*>(call->callee.get());
        if (field->base && field->base->kind == Expr::Kind::Ident) {
            auto* id = static_cast<const IdentExpr*>(field->base.get());
            return id->name == ns;
        }
    }
    return false;
}

bool IntegerDSL::canHandle(const Expr* e) const { return isCallTo(e, "integer"); }
bool StringDSL::canHandle(const Expr* e)  const { return isCallTo(e, "string");  }
bool FloatDSL::canHandle(const Expr* e)   const { return isCallTo(e, "float");   }
bool MemoryDSL::canHandle(const Expr* e)  const { return isCallTo(e, "memory");  }
bool IODSL::canHandle(const Expr* e)      const { return isCallTo(e, "io");      }
bool SyscallDSL::canHandle(const Expr* e) const { return isCallTo(e, "syscall"); }
bool AtomicDSL::canHandle(const Expr* e)  const { return isCallTo(e, "atomic");  }
bool ThreadDSL::canHandle(const Expr* e)  const { return isCallTo(e, "thread");  }
bool GpioDSL::canHandle(const Expr* e)    const { return isCallTo(e, "gpio");    }
bool WarpDSL::canHandle(const Expr* e)    const { return isCallTo(e, "warp");    }
bool MmioDSL::canHandle(const Expr* e)    const { return isCallTo(e, "mmio");    }
bool X86DSL::canHandle(const Expr* e)     const { return isCallTo(e, "x86");     }
bool NetworkDSL::canHandle(const Expr* e) const { return isCallTo(e, "network"); }

bool TrustDSL::canHandle(const Expr* e) const {
    if (!e || e->kind != Expr::Kind::Call) return false;
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee) return false;
    if (call->callee->kind != Expr::Kind::Field) return false;
    auto* field = static_cast<const FieldExpr*>(call->callee.get());
    return field->field == "verify";
}

} // namespace corelang::dsl
