// ======================================================================
// dsl_lowering.cpp — Faz 1 DSL lowerExpr Implementasyonlari
// ======================================================================
// Onceki durum: Tum Faz1 DSL'lerin lowerExpr'i "(void)e; (void)irCtx;
//   return nullptr;" diyordu. Bu sessiz yanlis IR'a yol aciyordu:
//   irgen.cpp lowerCall'da nullptr geri donunce caller context'e gore
//   ya 0 emit ediyor ya da yanlislikla void sayiyordu.
//
// Yeni durum: Her DSL, cagriyi tanimlar ve karsilik gelen __dsl_*
//   external fonksiyonunu declare edip LLVM call IR'i emit eder.
//   Bu fonksiyonlar:
//     a) Hosted platform: runtime/dsl_stubs.c'de libc ile implement edilir
//     b) Bare-metal: platform-spesifik dsl_stubs_baremetal.c ile implement edilir
//     c) Gelecekte: intrinsic'e (llvm.ctlz, llvm.cttz, vs.) donusturulebilir
//
// Mimari:
//   DSL call:  integer::clz(x)
//   AST:       CallExpr { callee: FieldExpr { base: "integer", field: "clz" },
//                          args: [x] }
//   IR emit:   declare i32 @__dsl_integer_clz(i32)
//              %r = call i32 @__dsl_integer_clz(%x)
//
// Neden nullptr yerine extern call?
//   - Linker eksik implementasyonu yakalar (sessiz yanlislik yerine link hatasi)
//   - Stubs.c dosyasina fprintf yerine gercek mantik eklemek kolay
//   - LLVM optimize eder: saf fonksiyonlar (pure) CSE/LICM'e girer
//   - LLVM intrinsic'e gecis: sadece bu dosyayi degistirmek yeterli
//
// Her DSL icin cagri adlandirma kurali:
//   __dsl_<namespace>_<method>(args...)
//   Ornek: integer::clz → __dsl_integer_clz
//          atomic::fence → __dsl_atomic_fence
//          syscall::write → __dsl_syscall_write
// ======================================================================

#include "dsl.h"
#include "../frontend/ast.h"
#include "../core/diagnostics.h"
#include "../irgen/irgen.h"   // IRContext — N1 FIX: lowerExprCallback erişimi

#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Constants.h>

using namespace corelang;
using namespace corelang::dsl;
using namespace corelang::irgen;

// ── Yardimci: irCtx (void*) → IRBuilder<> ───────────────────────────────────
static llvm::IRBuilder<>* bld(void* irCtx) {
    return static_cast<llvm::IRBuilder<>*>(irCtx);
}

// ── Yardimci: CallExpr'den namespace ve method adini cikart ─────────────────
struct DSLCallParts {
    std::string ns;      // "integer"
    std::string method;  // "clz"
    bool valid = false;
};
static DSLCallParts parseDSLCall(const Expr* e) {
    if (!e || e->kind != Expr::Kind::Call) return {};
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee || call->callee->kind != Expr::Kind::Field) return {};
    auto* field = static_cast<const FieldExpr*>(call->callee.get());
    if (!field->base || field->base->kind != Expr::Kind::Ident) return {};
    auto* id = static_cast<const IdentExpr*>(field->base.get());
    return { id->name, field->field, true };
}

// ── N1 FIX: DSL arg evaluation ──────────────────────────────────────────────
// Onceki sorun: arg'lar her zaman i32 0 olarak emit ediliyordu.
//   integer::clz(x) → __dsl_integer_clz(0) — x yerine sabit 0!
//   io::outb(0x3F8, 'A') → __dsl_io_outb(0, 0) — port ve deger kayboluyordu.
//
// Cozum: IRContext'e inject edilen lowerExprCallback.
//   IRGenerator, IRContext'e bir function pointer set eder:
//     ic.lowerExprCallback = [](void* self, Expr* e) -> llvm::Value* { ... }
//   DSL lowering bu callback'i Expr* → Value* icin cagirarak gercek
//   arg degerlerini evaluate eder.
//
// irCtx burada aslinda IRBuilder<>* — ama biz IRContext*'e de ihtiyac duyuyoruz.
// Cozum: DSLDispatcher::lowerExpr irCtx olarak IRContext*'i void* olarak aliyor.
// IRBuilder'a ic.bld uzerinden erisiyoruz.
//
// NOT: Bu callback thread-safe degil — DSL lowering her zaman tek thread'de
// IRGenerator::generate() icinde calisir, sorun yok.

// N1 FIX: irCtx artik IRContext* (void*) — bld ve callback buradan alinir
static llvm::IRBuilder<>* bldFromCtx(void* irCtx) {
    auto* ic = static_cast<IRContext*>(irCtx);
    return static_cast<llvm::IRBuilder<>*>(ic->bld);
}

static IRContext::LowerExprFn getLowerCb(void* irCtx) {
    return static_cast<IRContext*>(irCtx)->lowerExprCallback;
}
static void* getLowerSelf(void* irCtx) {
    return static_cast<IRContext*>(irCtx)->lowerExprSelf;
}

// ── Yardimci: External DSL fonksiyonu declare et ve cagir ───────────────────
static llvm::Value* emitExternCall(
    void*                             irCtx,
    llvm::Module*                     mod,
    const std::string&                fnName,
    llvm::Type*                       retType,
    const std::vector<llvm::Value*>&  args)
{
    auto* b   = bldFromCtx(irCtx);
    auto& ctx = mod->getContext();

    if (!retType) retType = llvm::Type::getInt32Ty(ctx);

    std::vector<llvm::Type*> argTys;
    for (auto* a : args) argTys.push_back(a->getType());

    auto* fnTy = llvm::FunctionType::get(retType, argTys, /*vararg=*/false);
    auto* fn   = mod->getOrInsertFunction(fnName, fnTy).getCallee();
    auto* fnV  = llvm::cast<llvm::Function>(fn);

    if (fnName.find("integer") != std::string::npos ||
        fnName.find("float")   != std::string::npos) {
        fnV->setDoesNotAccessMemory();
        fnV->setDoesNotThrow();
    }

    if (retType->isVoidTy()) {
        b->CreateCall(fnV, args);
        return nullptr;
    }
    return b->CreateCall(fnV, args, fnName + ".ret");
}

// ── Yardimci: CallExpr arg'larini evaluate et (N1 FIX) ──────────────────────
// lowerCb != nullptr ise gercek arg Value*'lari evaluate edilir.
// lowerCb == nullptr ise fallback: defaultArgTy turunde 0 (eski davranis).
static std::vector<llvm::Value*> evalArgs(
    const CallExpr* call,
    void*           irCtx,        // IRBuilder<>*
    llvm::Module*   mod,
    llvm::Type*     defaultArgTy = nullptr,
    // N1: opsiyonel callback — IRContext'ten inject edilir
    IRContext::LowerExprFn lowerCb   = nullptr,
    void*                  lowerSelf = nullptr)
{
    auto& ctx = mod->getContext();
    if (!defaultArgTy) defaultArgTy = llvm::Type::getInt32Ty(ctx);

    std::vector<llvm::Value*> vals;

    if (lowerCb && lowerSelf) {
        // N1 FIX: gercek arg evaluate — integer::clz(x) artik x degerini gerciriyor
        for (auto& argExpr : call->args) {
            llvm::Value* v = lowerCb(lowerSelf, argExpr.get());
            if (!v) {
                // Evaluate basarisiz — fallback olarak 0 kullan
                v = llvm::ConstantInt::get(defaultArgTy, 0);
            }
            vals.push_back(v);
        }
    } else {
        // Fallback: callback inject edilmemisse eski davranis
        // (sadece test/stub ortami icin)
        for (size_t i = 0; i < call->args.size(); ++i)
            vals.push_back(llvm::ConstantInt::get(defaultArgTy, 0));
    }
    return vals;
}

// ── Yardimci: Sik kullanilan tipler ─────────────────────────────────────────
static llvm::Type* i32Ty(llvm::Module* mod) {
    return llvm::Type::getInt32Ty(mod->getContext());
}
static llvm::Type* i64Ty(llvm::Module* mod) {
    return llvm::Type::getInt64Ty(mod->getContext());
}
static llvm::Type* voidTy(llvm::Module* mod) {
    return llvm::Type::getVoidTy(mod->getContext());
}
static llvm::Type* ptrTy(llvm::Module* mod) {
    return llvm::PointerType::getUnqual(mod->getContext());
}

// ─────────────────────────────────────────────────────────────────────────────
// IntegerDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Desteklenen metodlar:
//   integer::clz(x: i32) -> i32   — count leading zeros
//   integer::ctz(x: i32) -> i32   — count trailing zeros
//   integer::popcount(x: i32) -> i32
//   integer::bswap(x: i32) -> i32 — byte swap
//   integer::abs(x: i32) -> i32   — absolute value
//   integer::min(a, b: i32) -> i32
//   integer::max(a, b: i32) -> i32
//   integer::saturating_add(a, b: i32) -> i32
//   integer::saturating_sub(a, b: i32) -> i32
//   integer::wrapping_add(a, b: i32) -> i32
//   integer::wrapping_sub(a, b: i32) -> i32
//   integer::pow(base, exp: i32) -> i32
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* IntegerDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();
    auto& ctx  = mod->getContext();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_integer_" + parts.method;

    // Donus tipi: cogu method i32 donduruyor
    llvm::Type* retTy = i32Ty(mod);

    // Void dondurenler yok — integer:: hepsi deger donduruyor
    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// FloatDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Desteklenen metodlar:
//   float::sqrt(x: f64) -> f64
//   float::sin(x: f64) -> f64
//   float::cos(x: f64) -> f64
//   float::floor(x: f64) -> f64
//   float::ceil(x: f64) -> f64
//   float::round(x: f64) -> f64
//   float::abs(x: f64) -> f64
//   float::min(a, b: f64) -> f64
//   float::max(a, b: f64) -> f64
//   float::pow(base, exp: f64) -> f64
//   float::log(x: f64) -> f64
//   float::log2(x: f64) -> f64
//   float::exp(x: f64) -> f64
//   float::is_nan(x: f64) -> bool (i1)
//   float::is_inf(x: f64) -> bool (i1)
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* FloatDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();
    auto& ctx  = mod->getContext();

    // Float arg tipi: f64 (double)
    auto* f64 = llvm::Type::getDoubleTy(ctx);
    auto args = evalArgs(call, irCtx, mod, f64, getLowerCb(irCtx), getLowerSelf(irCtx));

    std::string fnName = "__dsl_float_" + parts.method;

    // is_nan, is_inf -> i1 (bool) donduruyor
    llvm::Type* retTy = f64;
    if (parts.method == "is_nan" || parts.method == "is_inf") {
        retTy = llvm::Type::getInt1Ty(ctx);
    }

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// StringDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Desteklenen metodlar:
//   string::len(s: *i8) -> i64
//   string::cmp(a, b: *i8) -> i32
//   string::copy(dst, src: *i8) -> *i8
//   string::concat(dst, src: *i8, max: i64) -> *i8
//   string::find(haystack, needle: *i8) -> i64   (-1 = not found)
//   string::starts_with(s, prefix: *i8) -> bool
//   string::to_int(s: *i8) -> i64
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* StringDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();
    auto& ctx  = mod->getContext();

    // String arg tipi: ptr (opaque pointer)
    auto args = evalArgs(call, irCtx, mod, ptrTy(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_string_" + parts.method;

    llvm::Type* retTy = i32Ty(mod);
    if (parts.method == "len" || parts.method == "find" || parts.method == "to_int")
        retTy = i64Ty(mod);
    else if (parts.method == "copy" || parts.method == "concat")
        retTy = ptrTy(mod);
    else if (parts.method == "starts_with")
        retTy = llvm::Type::getInt1Ty(ctx);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// MemoryDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Desteklenen metodlar:
//   memory::alloc(size: i64) -> *i8          — heap alloc
//   memory::alloc_zeroed(size: i64) -> *i8   — heap alloc + zeroed
//   memory::free(ptr: *i8) -> void
//   memory::copy(dst, src: *i8, n: i64) -> void  — memcpy
//   memory::set(dst: *i8, val: i32, n: i64) -> void  — memset
//   memory::fence() -> void                  — memory barrier
//   memory::realloc(ptr: *i8, size: i64) -> *i8
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* MemoryDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();
    auto& ctx  = mod->getContext();

    auto args = evalArgs(call, irCtx, mod, i64Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_memory_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "alloc" || parts.method == "alloc_zeroed" || parts.method == "realloc")
        retTy = ptrTy(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// IODSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// x86 Port I/O — Ring0 + x86 only (TypeChecker zaten dogruladi)
// Desteklenen metodlar:
//   io::outb(port: i32, value: i32) -> void   — 1-byte port write
//   io::outw(port: i32, value: i32) -> void   — 2-byte port write
//   io::outd(port: i32, value: i32) -> void   — 4-byte port write
//   io::inb(port: i32) -> i32                 — 1-byte port read
//   io::inw(port: i32) -> i32                 — 2-byte port read
//   io::ind(port: i32) -> i32                 — 4-byte port read
//   io::write(fd: i32, buf: *i8, n: i64) -> i64  — hosted write syscall
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* IODSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_io_" + parts.method;

    // port read'ler deger donduruyor, write'lar void
    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "inb" || parts.method == "inw" || parts.method == "ind")
        retTy = i32Ty(mod);
    else if (parts.method == "write")
        retTy = i64Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// SyscallDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Linux ABI syscall'lari — Ring3 + LinuxABI only
// Desteklenen metodlar:
//   syscall::write(fd: i32, buf: *i8, n: i64) -> i64
//   syscall::read(fd: i32, buf: *i8, n: i64) -> i64
//   syscall::exit(code: i32) -> void (noreturn)
//   syscall::open(path: *i8, flags: i32, mode: i32) -> i32
//   syscall::close(fd: i32) -> i32
//   syscall::mmap(addr: *i8, len: i64, prot: i32, flags: i32, fd: i32, off: i64) -> *i8
//   syscall::munmap(addr: *i8, len: i64) -> i32
//   syscall::getpid() -> i32
//   syscall::delta(a, b: i64) -> i64   — (custom, assumption module icin)
//   syscall::entry_exit_delta           — intent_watch icin metadata
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* SyscallDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i64Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_syscall_" + parts.method;

    llvm::Type* retTy = i64Ty(mod);
    if (parts.method == "exit")
        retTy = voidTy(mod);
    else if (parts.method == "open" || parts.method == "close" || parts.method == "getpid")
        retTy = i32Ty(mod);
    else if (parts.method == "mmap")
        retTy = ptrTy(mod);

    auto* v = emitExternCall(irCtx, mod, fnName, retTy, args);

    // exit: noreturn — LLVM IR'da unreachable ekle
    if (parts.method == "exit") {
        b->CreateUnreachable();
        return nullptr;
    }
    return v;
}

// ─────────────────────────────────────────────────────────────────────────────
// AtomicDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Atomik islemler ve bellek bariyerleri — her context'te gecerli
// Desteklenen metodlar:
//   atomic::fence(order: i32) -> void     — memory fence (0=seq_cst, 1=acq, 2=rel)
//   atomic::load(ptr: *i32) -> i32
//   atomic::store(ptr: *i32, val: i32) -> void
//   atomic::add(ptr: *i32, val: i32) -> i32   — fetch_add
//   atomic::sub(ptr: *i32, val: i32) -> i32   — fetch_sub
//   atomic::and(ptr: *i32, val: i32) -> i32
//   atomic::or(ptr: *i32, val: i32) -> i32
//   atomic::xchg(ptr: *i32, val: i32) -> i32  — exchange
//   atomic::cas(ptr: *i32, expected, desired: i32) -> i32 — compare_exchange
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* AtomicDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_atomic_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "load"  || parts.method == "add"  ||
        parts.method == "sub"   || parts.method == "and"  ||
        parts.method == "or"    || parts.method == "xchg" ||
        parts.method == "cas")
        retTy = i32Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// ThreadDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// OS thread / mutex operasyonlari — Ring3 + hosted only
// Desteklenen metodlar:
//   thread::spawn(fn: *i8, arg: *i8) -> i64   — thread id
//   thread::join(tid: i64) -> i32
//   thread::yield() -> void
//   thread::sleep_ms(ms: i64) -> void
//   thread::id() -> i64
//   thread::mutex_init(m: *i8) -> i32
//   thread::mutex_lock(m: *i8) -> i32
//   thread::mutex_unlock(m: *i8) -> i32
//   thread::mutex_destroy(m: *i8) -> void
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* ThreadDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, ptrTy(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_thread_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "spawn" || parts.method == "id")
        retTy = i64Ty(mod);
    else if (parts.method == "join" || parts.method == "mutex_init" ||
             parts.method == "mutex_lock" || parts.method == "mutex_unlock")
        retTy = i32Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// TrustDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// trust<T>.verify() cagrisi — her context'te gecerli
// Candle: trust<T, CONF, OBS>.verify() → i32 (score value)
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* TrustDSL::lowerExpr(const Expr* e, void* irCtx) {
    if (!e || e->kind != Expr::Kind::Call) return nullptr;
    auto* call = static_cast<const CallExpr*>(e);

    auto* b   = bld(irCtx);
    auto* mod = b->GetInsertBlock()->getModule();

    // trust<T>.verify() → __dsl_trust_verify(ptr_to_trust_value) -> i32
    // Arg: trust value pointer (placeholder icin ptr null)
    std::vector<llvm::Value*> args;
    args.push_back(llvm::ConstantPointerNull::get(
        llvm::PointerType::getUnqual(mod->getContext())));

    return emitExternCall(irCtx, mod, "__dsl_trust_verify", i32Ty(mod), args);
}

// ─────────────────────────────────────────────────────────────────────────────
// X86DSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// x86-specific intrinsics — x86/x86-64 only (TypeChecker dogruladi)
// Desteklenen metodlar:
//   x86::cpuid(leaf: i32) -> i32        — EAX sonucu
//   x86::rdmsr(msr: i32) -> i64         — MSR okuma
//   x86::wrmsr(msr: i32, val: i64)      — MSR yazma
//   x86::rdtsc() -> i64                 — timestamp counter
//   x86::cli() -> void                  — disable interrupts
//   x86::sti() -> void                  — enable interrupts
//   x86::hlt() -> void                  — halt
//   x86::pause() -> void                — spin-wait hint
//   x86::invlpg(addr: *i8) -> void      — TLB invalidate
//   x86::wbinvd() -> void               — cache flush
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* X86DSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_x86_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "cpuid")
        retTy = i32Ty(mod);
    else if (parts.method == "rdmsr" || parts.method == "rdtsc")
        retTy = i64Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// MmioDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// Memory-mapped I/O — Ring0, kernel/freestanding only
// Desteklenen metodlar:
//   mmio::read8(addr: i64) -> i32
//   mmio::read16(addr: i64) -> i32
//   mmio::read32(addr: i64) -> i32
//   mmio::read64(addr: i64) -> i64
//   mmio::write8(addr: i64, val: i32) -> void
//   mmio::write16(addr: i64, val: i32) -> void
//   mmio::write32(addr: i64, val: i32) -> void
//   mmio::write64(addr: i64, val: i64) -> void
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* MmioDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i64Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_mmio_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "read8" || parts.method == "read16" || parts.method == "read32")
        retTy = i32Ty(mod);
    else if (parts.method == "read64")
        retTy = i64Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// GpioDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// GPIO register access — Ring0, kernel/freestanding/interrupt
// Desteklenen metodlar:
//   gpio::set(pin: i32) -> void
//   gpio::clear(pin: i32) -> void
//   gpio::toggle(pin: i32) -> void
//   gpio::read(pin: i32) -> i32
//   gpio::set_mode(pin: i32, mode: i32) -> void  — input/output/alt
//   gpio::set_pull(pin: i32, pull: i32) -> void  — none/up/down
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* GpioDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_gpio_" + parts.method;

    llvm::Type* retTy = voidTy(mod);
    if (parts.method == "read")
        retTy = i32Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// WarpDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// GPU warp-level operations — GPUDevice context only
// Desteklenen metodlar:
//   warp::shuffle(val: i32, src_lane: i32) -> i32
//   warp::vote_all(pred: i32) -> i32
//   warp::vote_any(pred: i32) -> i32
//   warp::ballot(pred: i32) -> i64
//   warp::lane_id() -> i32
//   warp::sync() -> void
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* WarpDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_warp_" + parts.method;

    llvm::Type* retTy = i32Ty(mod);
    if (parts.method == "ballot")
        retTy = i64Ty(mod);
    else if (parts.method == "sync")
        retTy = voidTy(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}

// ─────────────────────────────────────────────────────────────────────────────
// NetworkDSL::lowerExpr
// ─────────────────────────────────────────────────────────────────────────────
// OS network stack — Ring3, LinuxABI
// Desteklenen metodlar:
//   network::send(fd: i32, buf: *i8, n: i64, flags: i32) -> i64
//   network::recv(fd: i32, buf: *i8, n: i64, flags: i32) -> i64
//   network::connect(fd: i32, addr: *i8, addrlen: i32) -> i32
//   network::bind(fd: i32, addr: *i8, addrlen: i32) -> i32
//   network::listen(fd: i32, backlog: i32) -> i32
//   network::accept(fd: i32) -> i32
//   network::socket(domain: i32, type: i32, proto: i32) -> i32
//   network::close(fd: i32) -> i32
// ─────────────────────────────────────────────────────────────────────────────
llvm::Value* NetworkDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* b    = bld(irCtx);
    auto* mod  = b->GetInsertBlock()->getModule();

    auto args = evalArgs(call, irCtx, mod, i32Ty(mod), getLowerCb(irCtx), getLowerSelf(irCtx));
    std::string fnName = "__dsl_network_" + parts.method;

    llvm::Type* retTy = i32Ty(mod);
    if (parts.method == "send" || parts.method == "recv")
        retTy = i64Ty(mod);

    return emitExternCall(irCtx, mod, fnName, retTy, args);
}
