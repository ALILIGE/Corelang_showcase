// ======================================================================
// dsl.h — CoreLang DSL Frontend Sistemi ve Faz 1 DSL Tanimlari
// ======================================================================
// DSL altyapisi + Faz 1 DSL implementasyonlarini icerir.
//
// Iki fazli tasarim:
//   Faz 1 (Parser)  : canHandle() + parseNode() -> DSLNode* (AST dugumu)
//   Faz 2 (Lowering): validate() -> gecerse lower() -> llvm::Value*
//
// DSLFrontend base class metodlari:
//   describe()    — OOP Requiem: capability descriptor dondurur
//   canHandle()   — bu ifade bu DSL tarafindan islenebilir mi?
//   validate()    — call site descriptor ile uyumlu mu? (hata emit eder)
//   lowerExpr()   — expr -> llvm::Value* (IR uretimi)
//   lowerStmt()   — stmt -> void (IR yan etkisi)
//
// Faz 1 DSL'leri (bu dosyada tanimli):
//   IntegerDSL    — integer:: , pure compute, LICM/GVN guvenli
//   StringDSL     — string:: , MMIO etkisi (bellek yazar)
//   FloatDSL      — float:: , pure compute
//   MemoryDSL     — memory:: , heap + MMIO + fence (interrupt'ta yasak)
//   IODSL         — io:: , port I/O + MMIO, Ring0 + x86 only
//   SyscallDSL    — syscall:: , Ring3 + Linux ABI only
//   AtomicDSL     — atomic:: , RMW + fence, her context'te legal
//   ThreadDSL     — thread:: , mutex:: , Ring3 + OS gerektirir
//   TrustDSL      — trust<T>.verify() cagrilari
//
// Faz 2 DSL'leri: dsl_faz2.h'de tanimli (guvenlik mimarisi DSL'leri).
// ======================================================================

#pragma once
#include "capability.h"
#include "../frontend/ast.h"
#include <memory>
#include <vector>
#include <string>
#include <unordered_map>

// Forward declarations
namespace llvm { class Value; class LLVMContext; }

namespace corelang::dsl {

// ── Call site context (populated by TypeChecker/Parser) ──────────────────────
struct CallSiteCtx {
    DSLContext  fnContext   = DSLContext::Normal;
    DSLPrivilege privilege  = DSLPrivilege::Any;
    DSLTargetReq target     = DSLTargetReq::Any;
    bool        inUnsafe    = false;
    std::string fnName;       // for error messages
    std::string srcFile;
    uint32_t    line = 0;
    uint32_t    col  = 0;
};

// ── DSLFrontend base ──────────────────────────────────────────────────────────
// Two-phase design:
//   Phase 1 (Parser)  : canParse() + parseNode() → DSLNode* (AST)
//   Phase 2 (Lowering): lower() → llvm::Value*
//
// canHandle() is kept for legacy dispatcher compatibility but
// validate() MUST be called before lower().
class DSLFrontend {
public:
    virtual ~DSLFrontend() = default;

    // OOP Requiem: every DSL must describe itself
    virtual DSLCapabilityDescriptor describe() const = 0;

    // Parser phase: can this DSL handle the expression?
    virtual bool canHandle(const Expr* e) const { (void)e; return false; }

    // [UPGRADE v2] Statement dispatch — SAHTE-4 FIX'in kalıcı çözümü.
    //
    // Önceki sorun: DSLDispatcher::lowerStmt(), her DSL'in lowerStmt()'ini
    // kör biçimde deniyordu (canHandle(nullptr) her zaman false döndüğünden
    // stmt dispatch dead code'du; yama olarak tüm DSL'lere denendi).
    //
    // Yeni akış:
    //   dispatcher: if (dsl->canHandleStmt(s)) { validate(); lowerStmt(); return; }
    //
    // Default false → mevcut Faz1 DSL'lerin hiçbiri etkilenmez.
    // Stmt işleyen DSL'ler (DistortDSL gibi) bu metodu override eder.
    virtual bool canHandleStmt(const Stmt* s) const { (void)s; return false; }

    // Validate call site against capability descriptor.
    // Returns false + emits diagnostic on mismatch.
    bool validate(const CallSiteCtx& ctx) const;

    // Lowering phase — called only after validate() passes
    // Returns nullptr on error (diagnostic already emitted)
    virtual llvm::Value* lowerExpr(const Expr* e, void* irCtx) { (void)e; (void)irCtx; return nullptr; }
    virtual void         lowerStmt(const Stmt* s, void* irCtx) { (void)s; (void)irCtx; }
};

// ── DSLVerifier ───────────────────────────────────────────────────────────────
// Used by TypeChecker to validate DSL call sites before lowering.
class DSLVerifier {
public:
    // Check a DSL call against its descriptor and call site context.
    // Emits a Diagnostics error and returns false on violation.
    static bool check(const DSLCapabilityDescriptor& desc,
                      const CallSiteCtx& ctx);
};

// ═══════════════════════════════════════════════════════════════════════════════
// Faz 1 DSL Implementations
// ═══════════════════════════════════════════════════════════════════════════════

// ── IntegerDSL ────────────────────────────────────────────────────────────────
class IntegerDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "IntegerDSL";
        d.effects          = DSLEffect::PureCompute;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = true;
        d.pureIfArgsPure   = true;
        d.namespacePrefix  = "integer";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── StringDSL ─────────────────────────────────────────────────────────────────
class StringDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "StringDSL";
        d.effects          = DSLEffect::MMIO;
        d.allowedContexts  = DSLContext::Normal | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.namespacePrefix  = "string";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── FloatDSL ──────────────────────────────────────────────────────────────────
class FloatDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "FloatDSL";
        d.effects          = DSLEffect::PureCompute;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = true;
        d.pureIfArgsPure   = true;
        d.namespacePrefix  = "float";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── MemoryDSL ─────────────────────────────────────────────────────────────────
class MemoryDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "MemoryDSL";
        d.effects          = DSLEffect::Heap | DSLEffect::MMIO | DSLEffect::Fence;
        d.allowedContexts  = DSLContext::Normal | DSLContext::Kernel |
                             DSLContext::Freestanding | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::FreestandingOk;
        d.contextRestrictionReason =
            "heap allocation is not allowed in interrupt handlers or GPU device kernels";
        d.namespacePrefix  = "memory";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── IODSL ─────────────────────────────────────────────────────────────────────
// Port I/O (in/out) + MMIO operations — x86 Ring0 only
class IODSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "IODSL";
        d.effects          = DSLEffect::PortIO | DSLEffect::MMIO;
        d.allowedContexts  = DSLContext::Normal | DSLContext::Interrupt |
                             DSLContext::Kernel | DSLContext::Freestanding;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::X86Only;
        d.contextRestrictionReason =
            "port I/O requires Ring0 privilege; not available in user-mode, "
            "GPU device, or GPUHost contexts";
        d.namespacePrefix  = "io";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── SyscallDSL ────────────────────────────────────────────────────────────────
class SyscallDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "SyscallDSL";
        d.effects          = DSLEffect::Syscall;
        d.allowedContexts  = DSLContext::Normal | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Ring3;
        d.targetReq        = DSLTargetReq::LinuxABI;
        d.contextRestrictionReason =
            "syscalls are not allowed inside interrupt handlers, "
            "freestanding kernels, or GPU code";
        d.namespacePrefix  = "syscall";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── AtomicDSL ─────────────────────────────────────────────────────────────────
class AtomicDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "AtomicDSL";
        d.effects          = DSLEffect::Atomic | DSLEffect::Fence;
        d.allowedContexts  = DSLContext::Normal | DSLContext::Interrupt |
                             DSLContext::Kernel | DSLContext::Freestanding |
                             DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.namespacePrefix  = "atomic";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── ThreadDSL ─────────────────────────────────────────────────────────────────
class ThreadDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "ThreadDSL";
        d.effects          = DSLEffect::Syscall | DSLEffect::Heap;
        d.allowedContexts  = DSLContext::Normal;
        d.privilege        = DSLPrivilege::Ring3;
        d.targetReq        = DSLTargetReq::LinuxABI;
        d.contextRestrictionReason =
            "thread operations require an OS environment; "
            "not available in freestanding, interrupt, or GPU contexts";
        d.namespacePrefix  = "thread";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── TrustDSL ──────────────────────────────────────────────────────────────────
// Handles trust<T>.verify() calls
class TrustDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "TrustDSL";
        d.effects          = DSLEffect::TrustCheck | DSLEffect::PureCompute;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        // TrustDSL ozel canHandle() kullanir (verify field match).
        // Namespace prefix yok — findByNamespace bu DSL'i bulamaz, intentional.
        d.namespacePrefix  = nullptr;
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};


// ── GpioDSL ───────────────────────────────────────────────────────────────────
// Hardware GPIO register access — Ring0, kernel/freestanding/interrupt only.
// Stub: context/privilege check only; no expr lowering (irgen_dsl.cpp handles it).
class GpioDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpioDSL";
        d.effects          = DSLEffect::PortIO | DSLEffect::MMIO;
        d.allowedContexts  = DSLContext::Kernel | DSLContext::Freestanding |
                             DSLContext::Interrupt | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::Any;
        d.contextRestrictionReason =
            "gpio:: requires Ring0 privilege; not available in normal user-mode functions";
        d.namespacePrefix  = "gpio";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── WarpDSL ───────────────────────────────────────────────────────────────────
// GPU warp-level operations — GPU device context only.
// Stub: context/privilege check only.
class WarpDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "WarpDSL";
        d.effects          = DSLEffect::GPUWarp;
        d.allowedContexts  = DSLContext::GPUDevice;
        d.privilege        = DSLPrivilege::GPU;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.contextRestrictionReason =
            "warp:: operations are only valid inside GPU device kernel functions "
            "(@#[gpu_kernel]); cannot be called from CPU code";
        d.namespacePrefix  = "warp";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── MmioDSL ───────────────────────────────────────────────────────────────────
// Memory-mapped I/O access — Ring0, no normal/GPU.
// Stub: context/privilege check only.
class MmioDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "MmioDSL";
        d.effects          = DSLEffect::MMIO;
        d.allowedContexts  = DSLContext::Kernel | DSLContext::Freestanding |
                             DSLContext::Interrupt | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::Any;
        d.contextRestrictionReason =
            "mmio:: requires Ring0 privilege; not callable from user-mode normal functions";
        d.namespacePrefix  = "mmio";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── X86DSL ────────────────────────────────────────────────────────────────────
// x86-specific intrinsics: CPUID, MSR, port I/O — x86/x86-64 target only.
// Stub: context/target check only.
class X86DSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "X86DSL";
        d.effects          = DSLEffect::PortIO;
        d.allowedContexts  = DSLContext::Normal | DSLContext::Kernel |
                             DSLContext::Freestanding | DSLContext::Interrupt |
                             DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::X86Only;
        d.contextRestrictionReason =
            "x86:: intrinsics are only available on x86/x86_64 targets";
        d.namespacePrefix  = "x86";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};


// ── NetworkDSL — TEST: upgrade sonrasi yeni DSL ekleme kolayligi ─────────────
// Sadece 2 yerde degisiklik gerekiyor:
//   1. Bu sinif tanimi (dsl.h)
//   2. dsl.cpp constructor'a reg.add() satiri
// type_checker.cpp'ye DOKUNMAK GEREKMIYOR.
class NetworkDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "NetworkDSL";
        d.namespacePrefix  = "network";   // network::send(), network::recv()
        d.effects          = DSLEffect::Syscall | DSLEffect::MMIO;
        d.allowedContexts  = DSLContext::Normal | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Ring3;
        d.targetReq        = DSLTargetReq::LinuxABI;
        d.contextRestrictionReason =
            "network:: requires OS network stack; "
            "not available in interrupt handlers, kernel freestanding, or GPU";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ── DSLDispatcher ─────────────────────────────────────────────────────────────
class DSLDispatcher {
public:
    DSLDispatcher();

    // Kopyalama ve taşıma yasak:
    // dsls_ zaten unique_ptr barındırdığından copy = delete (otomatik).
    // Move yasak çünkü nsCache_ pointer'ları descStore_'a işaret eder;
    // descStore_ taşınırsa bu pointer'lar dangling olur.
    DSLDispatcher(const DSLDispatcher&)            = delete;
    DSLDispatcher& operator=(const DSLDispatcher&) = delete;
    DSLDispatcher(DSLDispatcher&&)                 = delete;
    DSLDispatcher& operator=(DSLDispatcher&&)      = delete;

    // Find DSL + validate context + lower
    llvm::Value* lowerExpr(const Expr* e, void* irCtx, const CallSiteCtx& siteCtx);
    void         lowerStmt(const Stmt* s, void* irCtx, const CallSiteCtx& siteCtx);

    bool canHandle(const Expr* e) const;

    // [UPGRADE v2] Namespace lookup — TypeChecker'ın inline registry'sini kaldırır.
    // "syscall", "atomic", "io" gibi namespacePrefix'e göre descriptor döner.
    // Bilinmeyen namespace → nullptr (sessizce devam, hata değil).
    //
    // Bu metod sayesinde TypeChecker ve DSLDispatcher aynı describe() verisini
    // kullanır; iki yerde güncelleme yapmak gerekmez.
    const DSLCapabilityDescriptor* findByNamespace(const std::string& ns) const;

private:
    std::vector<std::unique_ptr<DSLFrontend>> dsls_;
    // [UPGRADE v2] namespace → descriptor index hızlı lookup için
    mutable std::unordered_map<std::string, const DSLCapabilityDescriptor*> nsCache_;
    // [PERF] namespace → DSLFrontend* for O(1) dispatch
    mutable std::unordered_map<std::string, DSLFrontend*> dslCache_;
    mutable std::vector<DSLCapabilityDescriptor> descStore_;  // describe() sonuçları kalıcı olarak burada
    mutable bool nsCacheBuilt_ = false;
    void buildNsCache() const;
};

} // namespace corelang::dsl
