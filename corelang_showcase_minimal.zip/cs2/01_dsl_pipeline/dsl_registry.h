// ======================================================================
// dsl_registry.h — CoreLang DSL Kayıt ve Bağımlılık Doğrulama Sistemi
// ======================================================================
// [UPGRADE v2] Yeni dosya.
//
// DSLRegistry, DSLDispatcher constructor'ının tek-adımda yaptığı işi
// iki adıma ayırır:
//   1. DSL'leri kaydet (add)
//   2. Bağımlılıkları doğrula (validateDependencies) — startup garantisi
//
// Neden ayrı bir sınıf?
//   DSLDispatcher daha önce requiresDSL alanını hiç kontrol etmiyordu.
//   Validation mantığını dispatcher'a gömmek constructor'ı karmaşıklaştırır.
//   DSLRegistry ayrı tutularak test edilebilir ve genişletilebilir olur.
//
// Kullanım:
//   DSLDispatcher::DSLDispatcher() {
//       DSLRegistry reg;
//       reg.add(std::make_unique<MemoryDSL>());
//       reg.add(std::make_unique<DriverDSL>());  // requiresDSL = {"MemoryDSL"}
//       reg.validateDependencies();  // ← startup'ta garantilenir
//       dsls_ = reg.release();
//   }
//
// Eksik bağımlılık → stderr'e açıklayıcı mesaj + std::abort().
// Bu bir geliştirici hatasıdır (runtime değil), abort uygundur.
//
// Geriye uyumluluk:
//   Mevcut hiçbir DSL etkilenmez. requiresDSL boş olan DSL'ler
//   (IntegerDSL, StringDSL, ...) validation'dan otomatik geçer.
// ======================================================================

#pragma once
#include "capability.h"   // DSLCapabilityDescriptor — descs_ icin
#include "dsl.h"          // DSLFrontend — dsls_ icin
#include <memory>
#include <vector>
#include <string>
#include <unordered_set>
#include <llvm/Support/raw_ostream.h>

namespace corelang::dsl {

// ── DSLRegistry ───────────────────────────────────────────────────────────────
class DSLRegistry {
public:
    // DSL'i kaydet.
    // describe() çağrılır ve name boş/null ise hemen abort — erken yakalama.
    void add(std::unique_ptr<DSLFrontend> dsl) {
        if (!dsl) {
            llvm::errs() << "[DSLRegistry] FATAL: null DSL pointer passed to add().\n";
            std::abort();
        }
        auto desc = dsl->describe();
        if (!desc.name || desc.name[0] == '\0') {
            llvm::errs() << "[DSLRegistry] FATAL: DSL returned empty name from describe().\n"
                         << "  All DSLFrontend subclasses must return a non-empty name.\n";
            std::abort();
        }
        registeredNames_.insert(desc.name);
        // Descriptor'u bir kez saklıyoruz — validateDependencies tekrar
        // describe() çağırmak zorunda kalmaz (gereksiz allocation yok).
        descs_.push_back(std::move(desc));
        dsls_.push_back(std::move(dsl));
    }

    // Tüm requiresDSL bağımlılıklarını kontrol et.
    // Her DSL'in bağımlı olduğu DSL'lerin kayıtlı olduğunu doğrular.
    // Eksik bağımlılık → açıklayıcı mesaj + std::abort().
    //
    // Çağrı zamanı: tüm add() çağrıları bittikten sonra, release() öncesinde.
    void validateDependencies() const {
        bool anyFailed = false;

        for (const auto& desc : descs_) {
            for (const char* dep : desc.requiresDSL) {
                if (!dep || dep[0] == '\0') continue;
                if (registeredNames_.count(dep) == 0) {
                    llvm::errs()
                        << "[DSLRegistry] FATAL: Dependency violation detected.\n"
                        << "  DSL '" << desc.name << "' requires '" << dep
                        << "' but it is not registered.\n"
                        << "  Registered DSLs:";
                    for (auto& n : registeredNames_)
                        llvm::errs() << " " << n;
                    llvm::errs() << "\n"
                        << "  Fix: add the missing DSL to DSLDispatcher constructor"
                        << " before '" << desc.name << "'.\n";
                    anyFailed = true;
                }
            }
        }

        if (anyFailed) {
            llvm::errs() << "[DSLRegistry] Aborting due to dependency violations.\n";
            std::abort();
        }
    }

    // Kayıtlı DSL'leri dispatcher'a teslim et (move semantics).
    // Bu çağrıdan sonra registry boşalır.
    std::vector<std::unique_ptr<DSLFrontend>> release() {
        registeredNames_.clear();
        descs_.clear();
        return std::move(dsls_);
    }

    // Sadece test/debug: kayıtlı isimler kümesi
    const std::unordered_set<std::string>& registeredNames() const {
        return registeredNames_;
    }

    std::size_t count() const { return dsls_.size(); }

private:
    std::vector<std::unique_ptr<DSLFrontend>> dsls_;
    std::vector<DSLCapabilityDescriptor>      descs_;       // add() sırasında kaydedilir
    std::unordered_set<std::string>            registeredNames_;
};

} // namespace corelang::dsl
