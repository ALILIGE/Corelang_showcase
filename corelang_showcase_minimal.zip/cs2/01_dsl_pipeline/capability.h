// ======================================================================
// capability.h — CoreLang DSL Capability Descriptor Sistemi (OOP Requiem)
// ======================================================================
// Her DSL, compile-time'da DSLCapabilityDescriptor ile kendini tanimlar.
// TypeChecker bu descriptor'i kullanarak call site'lari dogrular:
//   yanlis context, yanlis privilege veya yanlis target -> compile error.
//
// Temel enum'lar (bitmask):
//   DSLEffect    — IR seviyesi yan etki kategorileri
//                  PortIO | MMIO | Heap | Syscall | Atomic | PureCompute | ...
//   DSLContext   — Cagri icin izin verilen context'ler
//                  Normal | Interrupt | Kernel | Freestanding | GPUDevice | ...
//   DSLPrivilege — Gereken en dusuk ayric seviyesi (Any / Ring0 / Ring3 / GPU)
//   DSLTargetReq — Mimari gereksinimi (Any / X86Only / AArch64Only / ...)
//
// Optimizer flag'leri (DSLCapabilityDescriptor):
//   licmSafe       — LICM (Loop Invariant Code Motion) guvenli mi?
//   gvnSafe        — GVN (Global Value Numbering) ile tekil alabilir mi?
//   pureIfArgsPure — Tum argümanlar sabit ise pure sayilir mi?
//
// Yasak listesi (kesinlikle degismez):
//   syscall::*     — Interrupt context'te YASAK (kernel deadlock)
//   io::outb       — GPUDevice'da YASAK (port I/O komutu yok)
//   warp::shuffle  — Normal/Interrupt/Kernel'de YASAK (GPU-only)
//   mutex::lock    — Interrupt'ta YASAK (ISR spin deadlock)
//   thread::spawn  — Interrupt/Freestanding'de YASAK (clone() syscall)
// ======================================================================

#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace corelang::dsl {

// ── DSLEffect — IR-level side effect categories (bitmask) ────────────────────
enum class DSLEffect : uint32_t {
    None        = 0,
    PortIO      = 1 << 0,   // x86 in/out instructions
    MMIO        = 1 << 1,   // volatile memory-mapped I/O
    Heap        = 1 << 2,   // dynamic memory allocation/free
    Syscall     = 1 << 3,   // OS syscall
    Atomic      = 1 << 4,   // atomic RMW / fence
    PureCompute = 1 << 5,   // no side effects, safe to CSE/hoist
    Interrupt   = 1 << 6,   // modifies interrupt state (cli/sti)
    GPULaunch   = 1 << 7,   // dispatches GPU kernel
    GPUMemory   = 1 << 8,   // GPU buffer alloc/transfer
    GPUSync     = 1 << 9,   // GPU barrier / sync
    GPUWarp     = 1 << 10,  // intra-warp shuffle/vote
    PolicyHint  = 1 << 11,  // policy annotation, no runtime effect
    TrustCheck  = 1 << 12,  // trust<T> score verification
    Fence       = 1 << 13,  // memory fence / barrier
    // ── Köprü DSL — dış runtime effect bitleri ───────────────────────────────
    GCAlloc        = 1 << 14,  // GC kontrollü heap (Python, JVM, Go)
    ForeignCall    = 1 << 15,  // bilinmeyen ABI geçişi (FFI)
    ForeignExc     = 1 << 16,  // exception fırlatabilir (Python exc, C++ throw)
    NetworkIO      = 1 << 17,  // socket, HTTP, IPC
    SharedMem      = 1 << 18,  // process'ler arası paylaşımlı bellek
    ExternalProc   = 1 << 19,  // sub-process başlatma
    GILAcquire     = 1 << 20,  // Python GIL acquire (tek thread, blocking riski)
    AsyncRuntime   = 1 << 21,  // async event loop bağımlı (tokio, asyncio)
    // ── Ownership Effect bitleri ──────────────────────────────────────────────
    OwnedAlloc     = 1 << 22,  // owned<T> heap alloc — interrupt context'te yasak
    SharedLock     = 1 << 23,  // shared<T>.lock() — interrupt context'te yasak
    PinnedDMA      = 1 << 24,  // pinned<T> DMA alloc — sadece kernel/freestanding
    BorrowEscape   = 1 << 25,  // borrow<T> event boundary'yi aşıyor — yasak
    TrustObserve   = 1 << 26,  // trust<T> gözlem sayısı artışı
};
inline DSLEffect operator|(DSLEffect a, DSLEffect b) {
    return static_cast<DSLEffect>(
        static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}
inline bool hasEffect(DSLEffect set, DSLEffect flag) {
    return (static_cast<uint32_t>(set) & static_cast<uint32_t>(flag)) != 0;
}

// ── DSLContext — where the DSL call is allowed (bitmask) ─────────────────────
enum class DSLContext : uint32_t {
    Any          = 0xFFFFFFFF,
    Normal       = 1 << 0,   // regular function
    Interrupt    = 1 << 1,   // #[interrupt] function
    Kernel       = 1 << 2,   // bare-metal kernel context
    Freestanding = 1 << 3,   // no OS, no libc
    GPUDevice    = 1 << 4,   // GPU kernel function
    GPUHost      = 1 << 5,   // host-side GPU dispatch
    UnsafeBlock  = 1 << 6,   // inside unsafe { }
};
inline DSLContext operator|(DSLContext a, DSLContext b) {
    return static_cast<DSLContext>(
        static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}
inline bool contextAllowed(DSLContext allowed, DSLContext current) {
    if (allowed == DSLContext::Any) return true;
    return (static_cast<uint32_t>(allowed) & static_cast<uint32_t>(current)) != 0;
}

// ── DSLPrivilege ──────────────────────────────────────────────────────────────
enum class DSLPrivilege : uint8_t {
    Any   = 0,   // no restriction
    Ring0 = 1,   // kernel mode only
    Ring3 = 2,   // user mode only
    GPU   = 3,   // GPU device context only
};

// ── DSLTargetReq ──────────────────────────────────────────────────────────────
enum class DSLTargetReq : uint8_t {
    Any          = 0,
    X86Only      = 1,
    FreestandingOk = 2,   // POZITIF FLAG: DSL freestanding ortamda da calisir.
                             // "Yalnizca freestanding" kisitlamasi degil.
                             // DSLVerifier::check() bu deger icin target check yapmaz.
    LinuxABI     = 3,
    NVIDIACuda   = 4,
    VulkanSPIRV  = 5,
    AnyGPU       = 6,
    AArch64Only  = 7,
    RISCVOnly    = 8,
};

// ── DSLCapabilityDescriptor ───────────────────────────────────────────────────
// Every DSL must return one of these from describe().
// The DSLVerifier uses it at compile-time to validate call sites.
//
// [UPGRADE v2] Yeni alanlar:
//   namespacePrefix — "syscall", "atomic", "io" gibi çağrı namespace'i.
//                     nullptr = stmt-only DSL (distort gibi) veya özel
//                     canHandle() kullanan DSL (TrustDSL gibi).
//                     TypeChecker bu alanı kullanarak inline registry'sini
//                     kaldırır; tek kaynak of truth burası olur.
struct DSLCapabilityDescriptor {
    const char*    name;              // DSL human name, e.g. "IODSL"

    DSLEffect      effects;           // bitset of IR side effects
    DSLContext     allowedContexts;   // bitset of legal call contexts
    DSLPrivilege   privilege;         // minimum privilege level
    DSLTargetReq   targetReq;         // architecture requirement

    // Dependency: this DSL requires these other DSLs to be loaded.
    // [UPGRADE v2] DSLRegistry::validateDependencies() tarafindan startup'ta
    // gercekten enforce edilir. Eksik dep -> std::abort().
    std::vector<const char*> requiresDSL;

    // Optimizer hints
    bool licmSafe       = false;  // safe to hoist out of loops
    bool gvnSafe        = false;  // safe to deduplicate via GVN
    bool pureIfArgsPure = false;  // pure when all args are compile-time constant

    // Human-readable reason for context restriction (shown in error messages)
    const char* contextRestrictionReason = nullptr;

    // [UPGRADE v2] Cagri namespace'i - "myns::fn(...)" kalibindaki "myns".
    // SONUNA KONULDU: Faz1 DSL'lerin aggregate init'leri { name, effects, ctx, ... }
    // sirasini kullaniyor; bu alan sona eklenince o init'ler bozulmaz (default nullptr).
    //
    // DSLDispatcher::findByNamespace() ve TypeChecker bu alanla lookup yapar.
    // nullptr = stmt-only DSL veya ozel canHandle() kullanan DSL (TrustDSL gibi).
    //
    // Yeni DSL yazarken:
    //   d.namespacePrefix = "myns";  // myns::fn(...) cagrilari buraya gelir
    // TypeChecker'da baska hicbir sey eklemenize gerek kalmaz.
    const char*    namespacePrefix = nullptr;
};

// ── Helper: context name for error messages ───────────────────────────────────
inline const char* dslContextName(DSLContext ctx) {
    switch (ctx) {
        case DSLContext::Normal:       return "normal function";
        case DSLContext::Interrupt:    return "interrupt handler";
        case DSLContext::Kernel:       return "kernel context";
        case DSLContext::Freestanding: return "freestanding context";
        case DSLContext::GPUDevice:    return "GPU device kernel";
        case DSLContext::GPUHost:      return "GPU host code";
        case DSLContext::UnsafeBlock:  return "unsafe block";
        default:                       return "unknown context";
    }
}

// ── Ownership Category — Köprü'de bellek sahipliği kategorileri ─────────────────
// [koprudsl.md §3] Her dil farklı sahiplik kuralına sahip: GC, ARC, ownership, manual
// CoreSemanticABI normalizasyonu için ortak kategoriler.
enum class OwnershipCategory : uint8_t {
    Owned      = 0,   // CoreLang heap allocation, tek sahip, drop ile serbest
    Borrowed    = 1,   // Başka sahip tarafından sağlanan referans, sahip yaşadığı sürece geçerli
    Shared      = 2,   // GC/ARC tarafından yönetilen çoklu sahiplik
    External    = 3,   // Manuel free gerektiren dış bellek
    GCOwned     = 4,   // Python/JVM/Go GC tarafından sahiplenilen nesne
    PinnedBuffer= 5,   // GC taşıması engellenmiş buffer (buffer protocol ile sabitlenmiş)
    ArcShared   = 6,   // Rust Arc<T> gibi paylaşımlı sahiplik
};

// ── Determinism Level — Belirlenimcilik seviyeleri ───────────────────────────────
// [koprudsl.md §3] Boolean determinism yetmez! 5 seviye var.
// CoreSemanticABI'nin bir parçası — scheduler ve replay sistemi bunu kullanır.
enum class DeterminismLevel : uint8_t {
    Strong     = 0,   // Aynı input → her zaman aynı output (pure fonksiyonlar)
    Temporal   = 1,   // Aynı zaman koşullarında aynı (donanım zamanlama sabitse)
    Probabilistic= 2,  // RNG seed aynıysa aynı (seed'lenmiş RNG)
    Scheduler  = 3,   // Thread order sabitse aynı (deterministic scheduling)
    IO         = 4,   // Dış dünya sabitse aynı (file system, network sabit state)
    NonDeterministic = 5, // Hiçbir koşul sabit değil (gerçek world-facing I/O)
};
inline const char* determinismLevelName(DeterminismLevel lvl) {
    switch (lvl) {
        case DeterminismLevel::Strong:           return "StrongDeterministic";
        case DeterminismLevel::Temporal:         return "TemporalDeterministic";
        case DeterminismLevel::Probabilistic:     return "ProbabilisticDeterministic";
        case DeterminismLevel::Scheduler:        return "SchedulerDeterministic";
        case DeterminismLevel::IO:               return "IODeterministic";
        case DeterminismLevel::NonDeterministic:  return "NonDeterministic";
        default:                                 return "Unknown";
    }
}

// ── Async Model — Async çalışma modeli kategorileri ───────────────────────────
// [koprudsl.md §2] Python asyncio, Rust Tokio, CoreLang scheduler — üçü birden
// aynı async context'te kullanılamaz (compile-time yasak).
enum class AsyncModel : uint8_t {
    Sync           = 0,   // Blocking senkron çalışma (C, Rust sync fn)
    PythonAsyncio  = 1,   // Python asyncio event loop (tek thread, GIL)
    RustTokio      = 2,   // Tokio runtime (multi-thread runtime)
    CoreLangFuture = 3,   // CoreLang kendi Future modeli
    ThreadPool     = 4,   // Blocking thread pool (worker threads)
};
inline const char* asyncModelName(AsyncModel m) {
    switch (m) {
        case AsyncModel::Sync:           return "Sync";
        case AsyncModel::PythonAsyncio:  return "PythonAsyncio";
        case AsyncModel::RustTokio:     return "RustTokio";
        case AsyncModel::CoreLangFuture:return "CoreLangFuture";
        case AsyncModel::ThreadPool:     return "ThreadPool";
        default:                        return "Unknown";
    }
}

// ── Error Model — Hata modeli kategorileri ─────────────────────────────────────
// [koprudsl.md §2] C errno, Rust Result/panic, Python exception — hepsi normalize
enum class ErrorModel : uint8_t {
    Result       = 0,   // CoreLang/Rust Result<T,E> — normal hata yönetimi
    Panic        = 1,   // Rust panic — stack unwind, catch_unwind ile yakalanır
    CErrno       = 2,   // C errno — errno değişkeni set edilir
    CppException = 3,   // C++ exception — noexcept olmayan fonksiyonlar
    PythonExc    = 4,  // Python exception hierarchy
    GoPanic       = 5,  // Go panic/defer/recover
    Signal       = 6,  // UNIX signal (SIGSEGV, SIGINT, ...)
    None         = 7,  // No-failure fonksiyonlar
};
inline const char* errorModelName(ErrorModel m) {
    switch (m) {
        case ErrorModel::Result:       return "Result";
        case ErrorModel::Panic:       return "RustPanic";
        case ErrorModel::CErrno:       return "CErrno";
        case ErrorModel::CppException: return "CppException";
        case ErrorModel::PythonExc:   return "PythonException";
        case ErrorModel::GoPanic:      return "GoPanic";
        case ErrorModel::Signal:      return "Signal";
        case ErrorModel::None:        return "NoError";
        default:                       return "Unknown";
    }
}

// ── Execution Domain — Çalışma domain kategorileri ────────────────────────────────
// [koprudsl.md §1] Her node aynı dünyada yaşamaz — bu enum domain geçişini tanımlar.
enum class ExecutionDomain : uint8_t {
    NativeCPU   = 0,   // Native compute (CoreLang, C, Rust sync)
    Scripting   = 1,   // Scripting runtime (Python GIL, Ruby, Lua)
    GPUCompute  = 2,   // GPU kernel execution (CUDA, Vulkan SPIR-V)
    KernelMode  = 3,   // Bare-metal kernel context
    EmbeddedRT  = 4,   // Embedded realtime (no OS, deterministic)
    ExternalProc= 5,   // External process execution
    NetworkIO   = 6,   // Network socket/HTTP operations
    UnsafeBlock = 7,   // Unsafe block context
};
inline const char* executionDomainName(ExecutionDomain d) {
    switch (d) {
        case ExecutionDomain::NativeCPU:   return "NativeCPU";
        case ExecutionDomain::Scripting:   return "Scripting";
        case ExecutionDomain::GPUCompute:  return "GPUCompute";
        case ExecutionDomain::KernelMode: return "KernelMode";
        case ExecutionDomain::EmbeddedRT:  return "EmbeddedRealtime";
        case ExecutionDomain::ExternalProc:return "ExternalProcess";
        case ExecutionDomain::NetworkIO:   return "NetworkIO";
        case ExecutionDomain::UnsafeBlock: return "UnsafeBlock";
        default:                          return "Unknown";
    }
}

// ── Effect Propagation Result — Effect algebra sonuçları ────────────────────────
// [koprudsl.md §4] Effect birleştirme sonuçları — "Pure + HeapAlloc = Invalid" gibi
enum class EffectCombineResult : uint8_t {
    Valid    = 0,   // Effect'ler birleştirilebilir
    Invalid  = 1,   // Conflict: Pure + HeapAlloc, KernelOnly + Scripting
    Warning  = 2,   // Uyarı: performans etkisi olabilir
};

// ── Bridge Semantic Algebra Kuralları ────────────────────────────────────────────
// [koprudsl.md §4] Semantic kernel — execution semantics algebra
// Bu yapı effect combination kurallarını tanımlar.
struct SemanticAlgebraRule {
    DSLEffect       effectA;
    DSLEffect       effectB;
    EffectCombineResult result;
    const char*     reason;   // Human-readable açıklama
    const char*     lawName;  // "PURE LAW", "DOMAIN LAW", vb.
};

// Global effect algebra kuralları tablosu
inline const SemanticAlgebraRule* getSemanticAlgebraRules(size_t* outCount) {
    static const SemanticAlgebraRule rules[] = {
        // ── Pure Law: Pure + herhangi side effect = Invalid ──────────────────
        { DSLEffect::PureCompute, DSLEffect::Heap,        EffectCombineResult::Invalid, "Pure fonksiyon heap etkisi taşıyamaz", "PURE LAW I" },
        { DSLEffect::PureCompute, DSLEffect::GCAlloc,      EffectCombineResult::Invalid, "Pure fonksiyon GC heap etkisi taşıyamaz", "PURE LAW II" },
        { DSLEffect::PureCompute, DSLEffect::PortIO,        EffectCombineResult::Invalid, "Pure fonksiyon Port I/O etkisi taşıyamaz", "PURE LAW III" },
        { DSLEffect::PureCompute, DSLEffect::MMIO,         EffectCombineResult::Invalid, "Pure fonksiyon MMIO etkisi taşıyamaz", "PURE LAW IV" },
        { DSLEffect::PureCompute, DSLEffect::Syscall,       EffectCombineResult::Invalid, "Pure fonksiyon syscall etkisi taşıyamaz", "PURE LAW V" },
        { DSLEffect::PureCompute, DSLEffect::NetworkIO,     EffectCombineResult::Invalid, "Pure fonksiyon network I/O etkisi taşıyamaz", "PURE LAW VI" },
        { DSLEffect::PureCompute, DSLEffect::ForeignCall,  EffectCombineResult::Invalid, "Pure fonksiyon FFI çağrısı taşıyamaz", "PURE LAW VII" },
        { DSLEffect::PureCompute, DSLEffect::ForeignExc,    EffectCombineResult::Invalid, "Pure fonksiyon exception etkisi taşıyamaz", "PURE LAW VIII" },
        { DSLEffect::PureCompute, DSLEffect::AsyncRuntime,  EffectCombineResult::Invalid, "Pure fonksiyon async runtime bağımlı olamaz", "PURE LAW IX" },

        // ── Domain Law: Domain cross-check ───────────────────────────────────
        // Kernel-only policy, scripting domain ile çakışır
        // (Bu kural semantic kernel'de uygulanır, effect combination yerine domain check)

        // ── GIL Law: GIL + Interrupt = Invalid ────────────────────────────────
        { DSLEffect::GILAcquire, DSLEffect::Interrupt,     EffectCombineResult::Invalid, "GIL acquire interrupt context'te deadlock riski taşır", "GIL LAW I" },

        // ── Async Law: Async modeller karışık kullanılamaz ───────────────────
        { DSLEffect::AsyncRuntime, DSLEffect::GILAcquire,  EffectCombineResult::Warning, "Python async ve GIL acquire birlikte kullanılabilir ama dikkat", "ASYNC LAW I" },
    };
    *outCount = sizeof(rules) / sizeof(rules[0]);
    return rules;
}

// ── Retry Policy — Yeniden deneme politikası ─────────────────────────────────────
// [koprudsl.md §3] Retry mekanizması — kontrat'ta tanımlanır, scheduler uygular.
struct RetryPolicy {
    uint32_t    maxAttempts = 1;           // Maksimum deneme sayısı
    uint32_t    baseDelayMs = 100;          // Başlangıç gecikmesi (ms)
    bool        exponentialBackoff = false; // Üstel geri çekilme mi?
    uint32_t    maxDelayMs = 5000;           // Maksimum gecikme (ms)
    const char* retryableErrors = nullptr;  // Hangi hatalarda yeniden dene? (nullptr = tümü)
};

// ── Failure Strategy — Hata yayılma stratejisi ───────────────────────────────────
// [koprudsl.md §3] Bir node hata verince ne olur? Kontrat'ta belirlenir.
enum class FailureStrategy : uint8_t {
    Stop         = 0,   // Graph durur, hata yukarı taşır (Seçenek A)
    Fallback     = 1,   // Alternatif node'a geç (Seçenek B)
    PartialResult= 2,   // Bağımlı olmayan node'lar çalışmaya devam (Seçenek C)
    Ignore      = 3,   // Hata loglanır ama graph devam eder
};
inline const char* failureStrategyName(FailureStrategy s) {
    switch (s) {
        case FailureStrategy::Stop:          return "Stop";
        case FailureStrategy::Fallback:      return "Fallback";
        case FailureStrategy::PartialResult: return "PartialResult";
        case FailureStrategy::Ignore:        return "Ignore";
        default:                            return "Unknown";
    }
}

// ── Node State — Execution node durumları ──────────────────────────────────────
// [koprudsl.md §3] Graph çalışırken node durumları — VEE snapshot'ında saklanır.
enum class NodeState : uint8_t {
    Pending   = 0,   // Bağımlılıkları henüz bitmedi
    Ready     = 1,   // Çalışabilir, queue'da bekliyor
    Running   = 2,   // Aktif çalışıyor
    Completed = 3,   // Bitti, output hazır
    Failed    = 4,   // Hata verdi
    Cached    = 5,   // Önceki run'dan cache'de
    Timeout   = 6,   // Süre aşıldı
    Cancelled = 7,   // İptal edildi (upstream hata)
};
inline const char* nodeStateName(NodeState s) {
    switch (s) {
        case NodeState::Pending:    return "Pending";
        case NodeState::Ready:      return "Ready";
        case NodeState::Running:    return "Running";
        case NodeState::Completed:  return "Completed";
        case NodeState::Failed:      return "Failed";
        case NodeState::Cached:     return "Cached";
        case NodeState::Timeout:    return "Timeout";
        case NodeState::Cancelled:  return "Cancelled";
        default:                    return "Unknown";
    }
}

} // namespace corelang::dsl
