// runtime/ownership_runtime.c — CoreLang Ownership + Execution Strategy Layer
//
// Ownership runtime:
//   __memory_alloc / __memory_free   (owned<T>)
//   __shared_new / __shared_lock / __shared_unlock / __shared_release_ref  (shared<T>)
//   __dma_alloc  / __dma_free        (pinned<T>)
//
// Execution Strategy Layer runtime:
//   __epoch_defer_free               (deferred_epoch)
//   __rc_dec                         (rc_atomic)
//   __hazard_retire                  (hazard_epoch)
//   __global_epoch                   (global epoch clock)
//
// Derleme modları:
//   Hosted  : gcc -DCORELANG_HOSTED  → libc + pthreads
//   Bare-metal: (default)            → harici __baremetal_alloc/__baremetal_free

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#ifdef CORELANG_HOSTED
#  include <stdlib.h>
#  include <pthread.h>
#  include <stdatomic.h>
#else
   extern void* __baremetal_alloc(size_t n);
   extern void  __baremetal_free(void* p);
#  define malloc(n)  __baremetal_alloc(n)
#  define free(p)    __baremetal_free(p)
#  define aligned_alloc(a,s) __baremetal_alloc(s)
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Global epoch clock
// IRGen __global_epoch sembolüne referans verir; burada tanımlanır.
// ─────────────────────────────────────────────────────────────────────────────

volatile uint64_t __global_epoch = 0;

void __epoch_tick(void) {
    __atomic_add_fetch(&__global_epoch, 1, __ATOMIC_ACQ_REL);
}

// ─────────────────────────────────────────────────────────────────────────────
// owned<T> — __memory_alloc / __memory_free
// ─────────────────────────────────────────────────────────────────────────────

void* __memory_alloc(uint64_t size) {
    if (!size) return NULL;
    return malloc((size_t)size);
}

void __memory_free(void* ptr) {
    if (ptr) free(ptr);
}

// ─────────────────────────────────────────────────────────────────────────────
// shared<T> — header layout: [SharedHeader | T data]
// Pointer: T data başlangıcı döndürülür; header hemen önünde oturur.
// ─────────────────────────────────────────────────────────────────────────────

#ifdef CORELANG_HOSTED

typedef struct {
    pthread_mutex_t mtx;
    int             lock_order;
    uint32_t        ref_count;
} SharedHeader;

void* __shared_new(uint64_t data_size, int lock_order) {
    size_t total = sizeof(SharedHeader) + (size_t)data_size;
    SharedHeader* hdr = (SharedHeader*)malloc(total);
    if (!hdr) return NULL;
    pthread_mutex_init(&hdr->mtx, NULL);
    hdr->lock_order = lock_order;
    hdr->ref_count  = 1;
    return (void*)(hdr + 1);
}

int __shared_lock(void* ptr, int order) {
    if (!ptr) return -1;
    (void)order;  // TypeChecker compile-time'da kontrol etti
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    pthread_mutex_lock(&hdr->mtx);
    return 0;
}

void __shared_unlock(void* ptr) {
    if (!ptr) return;
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    pthread_mutex_unlock(&hdr->mtx);
}

void __shared_release_ref(void* ptr) {
    if (!ptr) return;
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    uint32_t prev = (uint32_t)__atomic_fetch_sub(&hdr->ref_count, 1, __ATOMIC_ACQ_REL);
    if (prev == 1) {
        pthread_mutex_destroy(&hdr->mtx);
        free(hdr);
    }
}

#else  // bare-metal spinlock

typedef struct {
    volatile int locked;
    int          lock_order;
    uint32_t     ref_count;
} SharedHeader;

void* __shared_new(uint64_t data_size, int lock_order) {
    size_t total = sizeof(SharedHeader) + (size_t)data_size;
    SharedHeader* hdr = (SharedHeader*)malloc(total);
    if (!hdr) return NULL;
    hdr->locked     = 0;
    hdr->lock_order = lock_order;
    hdr->ref_count  = 1;
    return (void*)(hdr + 1);
}

int __shared_lock(void* ptr, int order) {
    if (!ptr) return -1;
    (void)order;
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    while (__atomic_test_and_set(&hdr->locked, __ATOMIC_ACQUIRE)) {
#ifdef __x86_64__
        __asm__ volatile("pause");
#endif
    }
    return 0;
}

void __shared_unlock(void* ptr) {
    if (!ptr) return;
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    __atomic_clear(&hdr->locked, __ATOMIC_RELEASE);
}

void __shared_release_ref(void* ptr) {
    if (!ptr) return;
    SharedHeader* hdr = ((SharedHeader*)ptr) - 1;
    uint32_t prev = (uint32_t)__atomic_fetch_sub(&hdr->ref_count, 1, __ATOMIC_ACQ_REL);
    if (prev == 1) free(hdr);
}

#endif  // CORELANG_HOSTED

// ─────────────────────────────────────────────────────────────────────────────
// pinned<T> — DMA buffer
// ─────────────────────────────────────────────────────────────────────────────

#ifdef CORELANG_HOSTED
#  include <stdlib.h>

void* __dma_alloc(uint64_t size, uint64_t align, int direction) {
    (void)direction;
    if (!size) return NULL;
    void* ptr = aligned_alloc((size_t)align, (size_t)size);
    if (ptr) memset(ptr, 0, (size_t)size);
    return ptr;
}

void __dma_free(void* ptr, uint64_t phys) {
    (void)phys;
    free(ptr);
}

uint64_t __dma_virt_to_phys(void* virt) {
    // Hosted simülasyon: virtual == physical (gerçekte pagemap okur)
    return (uint64_t)(uintptr_t)virt;
}

#else  // bare-metal

extern void* __frame_alloc_contiguous(uint64_t size, uint64_t align);
extern void  __frame_free(void* ptr, uint64_t size);
extern void  __frame_pin(uint64_t phys);
extern void  __frame_unpin(uint64_t phys);
extern uint64_t __virt_to_phys(void* virt);

void* __dma_alloc(uint64_t size, uint64_t align, int direction) {
    (void)direction;
    void* ptr = __frame_alloc_contiguous(size, align);
    if (!ptr) return NULL;
    __frame_pin(__virt_to_phys(ptr));
    return ptr;
}

void __dma_free(void* ptr, uint64_t phys) {
    __frame_unpin(phys);
    __frame_free(ptr, 0);
}

uint64_t __dma_virt_to_phys(void* virt) {
    return __virt_to_phys(virt);
}

#endif

// ─────────────────────────────────────────────────────────────────────────────
// Module Ownership Registry — Bölüm 7.3
//
// Her modülün sahip olduğu allocation'ları takip eder.
// Modül Failed → force_drop tüm allocation'ları temizler.
// ─────────────────────────────────────────────────────────────────────────────

#define MODULE_MAX          32
#define MODULE_ALLOC_MAX   256

typedef struct {
    void*    ptr;
    uint8_t  kind;    // 0=owned, 1=pinned, 2=shared
    uint64_t phys;    // pinned için fiziksel adres
} ModuleAlloc;

typedef struct {
    uint32_t    module_id;
    uint32_t    alloc_count;
    ModuleAlloc allocs[MODULE_ALLOC_MAX];
    uint8_t     active;
} ModuleRegistry;

static ModuleRegistry module_registries_[MODULE_MAX];

#ifdef CORELANG_HOSTED
static pthread_mutex_t registry_mutex_ = PTHREAD_MUTEX_INITIALIZER;
#define REGISTRY_LOCK()   pthread_mutex_lock(&registry_mutex_)
#define REGISTRY_UNLOCK() pthread_mutex_unlock(&registry_mutex_)
#else
static volatile int registry_spin_ = 0;
#define REGISTRY_LOCK()   do { while (__atomic_test_and_set(&registry_spin_, __ATOMIC_ACQUIRE)) {} } while(0)
#define REGISTRY_UNLOCK() __atomic_clear(&registry_spin_, __ATOMIC_RELEASE)
#endif

void __module_registry_init(uint32_t module_id) {
    if (module_id >= MODULE_MAX) return;
    REGISTRY_LOCK();
    ModuleRegistry* r = &module_registries_[module_id];
    r->module_id   = module_id;
    r->alloc_count = 0;
    r->active      = 1;
    REGISTRY_UNLOCK();
}

void __module_track_alloc(uint32_t module_id, void* ptr, uint8_t kind, uint64_t phys) {
    if (module_id >= MODULE_MAX || !ptr) return;
    REGISTRY_LOCK();
    ModuleRegistry* r = &module_registries_[module_id];
    if (r->active && r->alloc_count < MODULE_ALLOC_MAX) {
        ModuleAlloc* a = &r->allocs[r->alloc_count++];
        a->ptr  = ptr;
        a->kind = kind;
        a->phys = phys;
    }
    REGISTRY_UNLOCK();
}

void __module_untrack_alloc(uint32_t module_id, void* ptr) {
    if (module_id >= MODULE_MAX || !ptr) return;
    REGISTRY_LOCK();
    ModuleRegistry* r = &module_registries_[module_id];
    for (uint32_t i = 0; i < r->alloc_count; i++) {
        if (r->allocs[i].ptr == ptr) {
            // Swap with last
            r->allocs[i] = r->allocs[--r->alloc_count];
            break;
        }
    }
    REGISTRY_UNLOCK();
}

// Modül Failed state'e geçince çağrılır — tüm allocation'ları temizle
void __module_force_drop(uint32_t module_id) {
    if (module_id >= MODULE_MAX) return;
    REGISTRY_LOCK();
    ModuleRegistry* r = &module_registries_[module_id];
    r->active = 0;
    uint32_t count = r->alloc_count;
    // Local kopyaya al — lock altında free yapmayalım
    ModuleAlloc local[MODULE_ALLOC_MAX];
    for (uint32_t i = 0; i < count; i++) local[i] = r->allocs[i];
    r->alloc_count = 0;
    REGISTRY_UNLOCK();

    // Lock dışında temizle
    for (uint32_t i = 0; i < count; i++) {
        switch (local[i].kind) {
        case 0:  // owned
            __memory_free(local[i].ptr);
            break;
        case 1:  // pinned — unpin + free
            __dma_free(local[i].ptr, local[i].phys);
            break;
        case 2:  // shared — ref release
            __shared_release_ref(local[i].ptr);
            break;
        }
    }
}

//
// Free request'leri bir ring buffer'a kuyruğa alır.
// __epoch_flush() çağrısında (context switch / scheduler tick) toplu serbest bırakır.
// ─────────────────────────────────────────────────────────────────────────────

#define DEFER_QUEUE_SIZE 256

typedef struct {
    void*    ptr;
    uint64_t epoch;  // hangi epoch'ta kuyruğa girdi
} DeferEntry;

static DeferEntry  defer_queue_[DEFER_QUEUE_SIZE];
static uint32_t    defer_head_ = 0;
static uint32_t    defer_tail_ = 0;

#ifdef CORELANG_HOSTED
static pthread_mutex_t defer_mutex_ = PTHREAD_MUTEX_INITIALIZER;
#define DEFER_LOCK()   pthread_mutex_lock(&defer_mutex_)
#define DEFER_UNLOCK() pthread_mutex_unlock(&defer_mutex_)
#else
static volatile int defer_spin_ = 0;
#define DEFER_LOCK()   do { while (__atomic_test_and_set(&defer_spin_, __ATOMIC_ACQUIRE)) {} } while(0)
#define DEFER_UNLOCK() __atomic_clear(&defer_spin_, __ATOMIC_RELEASE)
#endif

void __epoch_defer_free(void* ptr) {
    if (!ptr) return;
    DEFER_LOCK();
    uint32_t next = (defer_tail_ + 1) % DEFER_QUEUE_SIZE;
    if (next != defer_head_) {
        defer_queue_[defer_tail_].ptr   = ptr;
        defer_queue_[defer_tail_].epoch = __global_epoch;
        defer_tail_ = next;
    } else {
        // Queue dolu — fallback: immediate free
        __memory_free(ptr);
    }
    DEFER_UNLOCK();
}

// Scheduler tick / context switch'te çağrılır — en az 2 epoch geçmiş olanları free et
void __epoch_flush(void) {
    uint64_t cur = __global_epoch;
    DEFER_LOCK();
    while (defer_head_ != defer_tail_) {
        DeferEntry* e = &defer_queue_[defer_head_];
        if (cur - e->epoch >= 2) {
            __memory_free(e->ptr);
            defer_head_ = (defer_head_ + 1) % DEFER_QUEUE_SIZE;
        } else {
            break;  // Kalan entry'ler daha yeni — dur
        }
    }
    DEFER_UNLOCK();
    __epoch_tick();  // Epoch'u ilerlet
}

// ─────────────────────────────────────────────────────────────────────────────
// Execution Strategy Layer — rc_atomic
//
// Header layout: [RcHeader | T data]
// __rc_dec: refcount-- → 0 ise __epoch_defer_free'ye push
// ─────────────────────────────────────────────────────────────────────────────

typedef struct {
    uint32_t ref_count;
} RcHeader;

void* __rc_new(uint64_t data_size) {
    size_t total = sizeof(RcHeader) + (size_t)data_size;
    RcHeader* hdr = (RcHeader*)malloc(total);
    if (!hdr) return NULL;
    hdr->ref_count = 1;
    return (void*)(hdr + 1);
}

void __rc_inc(void* ptr) {
    if (!ptr) return;
    RcHeader* hdr = ((RcHeader*)ptr) - 1;
    __atomic_add_fetch(&hdr->ref_count, 1, __ATOMIC_ACQ_REL);
}

// Dönüş değeri: yeni refcount (0 ise serbest bırakıldı — irgen branch yapar)
int32_t __rc_dec(void* ptr) {
    if (!ptr) return -1;
    RcHeader* hdr = ((RcHeader*)ptr) - 1;
    uint32_t prev = (uint32_t)__atomic_fetch_sub(&hdr->ref_count, 1, __ATOMIC_ACQ_REL);
    if (prev == 1) {
        // Refcount sıfır — epoch queue'ya push (irgen bu branch'i de emit eder)
        __epoch_defer_free((void*)hdr);
        return 0;
    }
    return (int32_t)(prev - 1);
}

// Interrupt-safe variant: CAS loop (spinlock yok, NMI-safe)
int32_t __rc_dec_irq_safe(void* ptr) {
    if (!ptr) return -1;
    RcHeader* hdr = ((RcHeader*)ptr) - 1;
    uint32_t old, desired;
    do {
        old     = __atomic_load_n(&hdr->ref_count, __ATOMIC_ACQUIRE);
        desired = old - 1;
    } while (!__atomic_compare_exchange_n(&hdr->ref_count, &old, desired,
                                           /*weak=*/1,
                                           __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE));
    if (desired == 0) {
        __epoch_defer_free((void*)hdr);
        return 0;
    }
    return (int32_t)desired;
}

// ─────────────────────────────────────────────────────────────────────────────
// Execution Strategy Layer — hazard_epoch
//
// Her retire isteği: { ptr, epoch } → hazard_retire_queue
// Flush: hiçbir CPU o epoch'u "aktif" tutmuyorsa free et.
// ─────────────────────────────────────────────────────────────────────────────

#define HAZARD_QUEUE_SIZE 128
#define HAZARD_MAX_CPUS   64

typedef struct {
    void*    ptr;
    uint64_t retire_epoch;
} HazardEntry;

static HazardEntry  hazard_queue_[HAZARD_QUEUE_SIZE];
static uint32_t     hazard_head_ = 0;
static uint32_t     hazard_tail_ = 0;

// Her CPU'nun aktif epoch'u — scheduler bu tabloyu günceller
static volatile uint64_t cpu_epoch_[HAZARD_MAX_CPUS] = {0};

#ifdef CORELANG_HOSTED
static pthread_mutex_t hazard_mutex_ = PTHREAD_MUTEX_INITIALIZER;
#define HAZARD_LOCK()   pthread_mutex_lock(&hazard_mutex_)
#define HAZARD_UNLOCK() pthread_mutex_unlock(&hazard_mutex_)
#else
static volatile int hazard_spin_ = 0;
#define HAZARD_LOCK()   do { while (__atomic_test_and_set(&hazard_spin_, __ATOMIC_ACQUIRE)) {} } while(0)
#define HAZARD_UNLOCK() __atomic_clear(&hazard_spin_, __ATOMIC_RELEASE)
#endif

void __hazard_retire(void* ptr, uint64_t epoch) {
    if (!ptr) return;
    HAZARD_LOCK();
    uint32_t next = (hazard_tail_ + 1) % HAZARD_QUEUE_SIZE;
    if (next != hazard_head_) {
        hazard_queue_[hazard_tail_].ptr          = ptr;
        hazard_queue_[hazard_tail_].retire_epoch = epoch;
        hazard_tail_ = next;
    } else {
        // Queue dolu — fallback: immediate free
        __memory_free(ptr);
    }
    HAZARD_UNLOCK();
}

// Scheduler tarafından çağrılır — güvenli olanları free et
void __hazard_flush(uint32_t num_cpus) {
    if (num_cpus > HAZARD_MAX_CPUS) num_cpus = HAZARD_MAX_CPUS;

    HAZARD_LOCK();
    uint32_t read = hazard_head_;
    while (read != hazard_tail_) {
        HazardEntry* e = &hazard_queue_[read];
        // Tüm CPU'ların bu epoch'u geçtiğini kontrol et
        int safe = 1;
        for (uint32_t c = 0; c < num_cpus; c++) {
            if (cpu_epoch_[c] <= e->retire_epoch) { safe = 0; break; }
        }
        if (safe) {
            __memory_free(e->ptr);
            hazard_head_ = (hazard_head_ + 1) % HAZARD_QUEUE_SIZE;
            read = hazard_head_;
        } else {
            read = (read + 1) % HAZARD_QUEUE_SIZE;
        }
    }
    HAZARD_UNLOCK();
}

// CPU epoch güncelleme — context switch'te çağrılır
void __hazard_cpu_epoch_set(uint32_t cpu_id, uint64_t epoch) {
    if (cpu_id < HAZARD_MAX_CPUS)
        __atomic_store_n(&cpu_epoch_[cpu_id], epoch, __ATOMIC_RELEASE);
}

// ─────────────────────────────────────────────────────────────────────────────
// IPC Ownership Runtime — Bölüm 7.1
//
// __ipc_send_transfer: owned<T> move — kaynak drop edildi, hedef yeni sahip
// __ipc_send_borrow:   borrow<T> gönder — maxDelayUs sonra iade beklenir
// __ipc_shared_map:    pinned<T> — hedef modüle fiziksel sayfayı map et
// __ipc_send:          generic fallback
// __ipc_recv:          hedef tarafında veri al
// ─────────────────────────────────────────────────────────────────────────────

#define IPC_QUEUE_MAX 64

typedef struct {
    void*    data;
    uint8_t  ownership;  // 0=Transfer, 1=Borrow, 2=Shared
    uint32_t delay_us;   // Borrow için deadline
    uint64_t sent_epoch;
} IpcMessage;

typedef struct {
    IpcMessage msgs[IPC_QUEUE_MAX];
    uint32_t   head, tail;
#ifdef CORELANG_HOSTED
    pthread_mutex_t mu;
#else
    volatile int spin;
#endif
} IpcQueue;

// Basit global queue — gerçek OS'te per-channel olur
static IpcQueue ipc_queue_ = {0};

static void ipc_queue_init_(void) {
#ifdef CORELANG_HOSTED
    pthread_mutex_init(&ipc_queue_.mu, NULL);
#endif
}

#ifdef CORELANG_HOSTED
#define IPC_LOCK()   pthread_mutex_lock(&ipc_queue_.mu)
#define IPC_UNLOCK() pthread_mutex_unlock(&ipc_queue_.mu)
#else
#define IPC_LOCK()   do { while (__atomic_test_and_set(&ipc_queue_.spin, __ATOMIC_ACQUIRE)) {} } while(0)
#define IPC_UNLOCK() __atomic_clear(&ipc_queue_.spin, __ATOMIC_RELEASE)
#endif

// Transfer: kaynak modül move etti — hedef sahip olur
void __ipc_send_transfer(void* edge_meta, void* data) {
    (void)edge_meta;
    IPC_LOCK();
    uint32_t next = (ipc_queue_.tail + 1) % IPC_QUEUE_MAX;
    if (next != ipc_queue_.head) {
        ipc_queue_.msgs[ipc_queue_.tail].data       = data;
        ipc_queue_.msgs[ipc_queue_.tail].ownership  = 0;
        ipc_queue_.msgs[ipc_queue_.tail].delay_us   = 0;
        ipc_queue_.msgs[ipc_queue_.tail].sent_epoch = __global_epoch;
        ipc_queue_.tail = next;
    }
    IPC_UNLOCK();
    // data'nın drop edilmemesi için caller drop flag set etti (IRGen yaptı)
}

// Borrow: maxDelayUs içinde iade beklenir
void __ipc_send_borrow(void* edge_meta, void* data, uint32_t max_delay_us) {
    (void)edge_meta;
    IPC_LOCK();
    uint32_t next = (ipc_queue_.tail + 1) % IPC_QUEUE_MAX;
    if (next != ipc_queue_.head) {
        ipc_queue_.msgs[ipc_queue_.tail].data       = data;
        ipc_queue_.msgs[ipc_queue_.tail].ownership  = 1;
        ipc_queue_.msgs[ipc_queue_.tail].delay_us   = max_delay_us;
        ipc_queue_.msgs[ipc_queue_.tail].sent_epoch = __global_epoch;
        ipc_queue_.tail = next;
    }
    IPC_UNLOCK();
    // Kaynak modülde pointer hâlâ geçerli — drop edilmiyor
}

// Shared: pinned<T> buffer fiziksel adresiyle map
void* __ipc_shared_map(void* edge_meta, void* virt_ptr, uint64_t phys_addr) {
    (void)edge_meta;
    // Gerçek OS'te: hedef modülün sanal adres uzayına phys_addr'ı map et
    // Hosted simülasyon: aynı sanal adresi döndür
    (void)phys_addr;
    return virt_ptr;
}

// Generic fallback
void __ipc_send(void* channel, void* data) {
    (void)channel;
    __ipc_send_transfer(NULL, data);
}

// Recv: hedef modülde veri al — Transfer'de ownership geçer
void* __ipc_recv(void* channel) {
    (void)channel;
    IPC_LOCK();
    if (ipc_queue_.head == ipc_queue_.tail) {
        IPC_UNLOCK();
        return NULL;
    }
    IpcMessage msg = ipc_queue_.msgs[ipc_queue_.head];
    ipc_queue_.head = (ipc_queue_.head + 1) % IPC_QUEUE_MAX;
    IPC_UNLOCK();
    return msg.data;
}

// ─────────────────────────────────────────────────────────────────────────────
// Trust + Ownership entegrasyonu — Bölüm 4
//
// __trust_observe: shared<trust<T>>.inner erişiminde gözlem sayısını artır.
//                  Bayesian güncelleme: yeni gözlem → güven skoru güncellenir.
// __trust_reset:   owned<trust<T>> move sonrası — yeni sahip bağlamında sıfırla.
// ─────────────────────────────────────────────────────────────────────────────

// trust<T> bellek düzeni — TypeContext TrustType ile eşleşmeli
// { inner: T, score: f32, obs_count: i32, timestamp: u64 }
typedef struct {
    // inner değer — değişken boyut, burada opak
    float    score;      // güven skoru [0.0, 1.0]
    int32_t  obs_count;  // gözlem sayısı
    uint64_t timestamp;  // son güncelleme epoch
} TrustHeader;

// Bayesian güven skoru güncelleme:
// Her yeni gözlemde: score = score * decay_factor
// (Yeni gözlem önceki tahminle çelişmiyorsa score artar,
//  çelişiyorsa düşer — basit model: her erişim hafif düşürür)
#define TRUST_DECAY_FACTOR  0.999f
#define TRUST_MIN_SCORE     0.0f
#define TRUST_MAX_SCORE     1.0f

void __trust_observe(void* trust_ptr) {
    if (!trust_ptr) return;
    // trust_ptr: trust<T> struct'ının başlangıcı
    // score alanı offset'ini bilmek gerekiyor — inner boyutu bilinmiyor
    // Basit implementasyon: trust_ptr bir TrustHeader* olarak ele al
    // (inner boyutu 0 varsayımı — gerçekte IRGen doğru offset'i verir)
    // Production'da: __trust_observe(void* score_ptr, void* obs_ptr) şeklinde olur
    // Şimdilik: ilk float = score, sonraki i32 = obs_count
    float*   score_ptr = (float*)((uint8_t*)trust_ptr);
    int32_t* obs_ptr   = (int32_t*)((uint8_t*)trust_ptr + sizeof(float));

    // Gözlem sayısını artır
    int32_t obs = __atomic_add_fetch(obs_ptr, 1, __ATOMIC_ACQ_REL);

    // Bayesian decay — float için uint32_t üzerinden atomic işlem
    uint32_t old_raw, new_raw;
    do {
        __atomic_load(score_ptr, (float*)&old_raw, __ATOMIC_ACQUIRE);
        float old_f = *(float*)&old_raw;
        float new_f = old_f * TRUST_DECAY_FACTOR;
        if (new_f < TRUST_MIN_SCORE) new_f = TRUST_MIN_SCORE;
        new_raw = *(uint32_t*)&new_f;
    } while (!__atomic_compare_exchange_n(
        (uint32_t*)score_ptr, &old_raw, new_raw,
        /*weak=*/1, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE));

    (void)obs;
}

// owned<trust<T>> move sonrası — yeni sahip bağlamında güven sıfırla
// (Başka modülden/kaynaktan gelen trust — yeni sahip 0 gözlemden başlar)
void __trust_reset(void* trust_ptr, float initial_score) {
    if (!trust_ptr) return;
    float*   score_ptr = (float*)((uint8_t*)trust_ptr);
    int32_t* obs_ptr   = (int32_t*)((uint8_t*)trust_ptr + sizeof(float));

    __atomic_store_n((uint32_t*)score_ptr,
        *(uint32_t*)&initial_score, __ATOMIC_RELEASE);
    __atomic_store_n(obs_ptr, 0, __ATOMIC_RELEASE);
}
