// irgen_ownership.cpp — CoreLang Ownership + Execution Strategy Layer IRGen
//
// Bu dosya ownership runtime çağrılarını LLVM IR'a dönüştürür:
//   owned<T>  → emitOwnedDrop      (__memory_free + drop flag)
//   shared<T> → emitSharedLock/Unlock (__shared_lock / __shared_unlock)
//   pinned<T> → emitPinnedAlloc/Free  (__dma_alloc / __dma_free)
//
// Execution Strategy Layer (ESL):
//   deterministic → emitOwnedDrop (yukarıdaki)
//   deferred_epoch → emitEpochDeferFree (__epoch_defer_free)
//   rc_atomic      → emitRcDec          (__rc_dec)
//   hazard_epoch   → emitHazardRetire   (__hazard_retire)

#include "irgen_internal.h"
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Constants.h>

namespace corelang::irgen {

// ─────────────────────────────────────────────────────────────────────────────
// Yardımcı: getOrDeclareExtern
// Module'e extern fn ekle veya mevcutu döndür.
// ─────────────────────────────────────────────────────────────────────────────

llvm::Function* IRGenerator::getOrDeclareExtern(IRContext& ic,
                                                  const std::string& name,
                                                  llvm::Type* retTy,
                                                  std::vector<llvm::Type*> paramTys) {
    // Daha önce tanımlandıysa döndür
    if (auto* existing = ic.mod->getFunction(name)) return existing;

    auto* fnTy = llvm::FunctionType::get(retTy, paramTys, /*isVarArg=*/false);
    auto* fn   = llvm::Function::Create(fnTy,
                                         llvm::GlobalValue::ExternalLinkage,
                                         name, ic.mod);
    return fn;
}

// ─────────────────────────────────────────────────────────────────────────────
// owned<T> drop
//
// IR pattern:
//   %drop_flag = alloca i1          ; entry block'ta oluşturulur
//   store false, %drop_flag
//   ...
//   ; scope sonu:
//   %already = load i1, %drop_flag
//   br %already, drop.end, drop.body
// drop.body:
//   call void @__memory_free(ptr %var_ptr)
//   store true, %drop_flag
//   br drop.end
// drop.end:
// ─────────────────────────────────────────────────────────────────────────────

void IRGenerator::emitOwnedDrop(IRContext& ic, llvm::Value* ptr,
                                  const std::string& varName) {
    if (!ptr || !ic.fn) return;

    auto* b     = bld(ic);
    auto& ctx   = *ic.ctx;
    auto* i1Ty  = llvm::Type::getInt1Ty(ctx);
    auto* i8Ty  = llvm::Type::getInt8Ty(ctx);
    auto* i8Ptr = llvm::PointerType::get(i8Ty, 0);

    // drop flag — entry block'ta alloca (daha önce oluşturulmuş olabilir)
    std::string flagName = varName + ".drop_flag";
    llvm::AllocaInst* dropFlag = nullptr;

    // vars map'te flag var mı bak
    auto flagIt = ic.vars.find(flagName);
    if (flagIt != ic.vars.end()) {
        dropFlag = llvm::dyn_cast<llvm::AllocaInst>(flagIt->second);
    }
    if (!dropFlag) {
        // Entry block'ta yeni alloca
        dropFlag = createEntryAlloca(ic, i1Ty, flagName);
        b->CreateStore(llvm::ConstantInt::getFalse(ctx), dropFlag);
        ic.vars[flagName] = dropFlag;
    }

    // Mevcut insert point'ten basic block'ları oluştur
    auto* curBB  = b->GetInsertBlock();
    auto* dropBB = llvm::BasicBlock::Create(ctx, "drop." + varName, ic.fn);
    auto* endBB  = llvm::BasicBlock::Create(ctx, "drop.end." + varName, ic.fn);

    // Zaten drop edildi mi kontrol et
    llvm::Value* alreadyDropped = b->CreateLoad(i1Ty, dropFlag, flagName + ".chk");
    b->CreateCondBr(alreadyDropped, endBB, dropBB);

    // drop.body
    b->SetInsertPoint(dropBB);
    auto* memFree = getOrDeclareExtern(ic, "__memory_free",
        llvm::Type::getVoidTy(ctx), {i8Ptr});
    llvm::Value* castPtr = b->CreateBitCast(ptr, i8Ptr, varName + ".i8");
    b->CreateCall(memFree, {castPtr});
    b->CreateStore(llvm::ConstantInt::getTrue(ctx), dropFlag);
    b->CreateBr(endBB);

    // drop.end
    b->SetInsertPoint(endBB);
}

// ─────────────────────────────────────────────────────────────────────────────
// shared<T> lock / unlock
//
// .lock()   → i32 __shared_lock(void* ptr, i32 order)
// .unlock() → void __shared_unlock(void* ptr)
// ─────────────────────────────────────────────────────────────────────────────

llvm::Value* IRGenerator::emitSharedLock(IRContext& ic, llvm::Value* sharedPtr,
                                           int lockOrder) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* i32Ty = llvm::Type::getInt32Ty(ctx);

    auto* lockFn = getOrDeclareExtern(ic, "__shared_lock",
        i32Ty, {i8Ptr, i32Ty});

    auto* castPtr  = bld(ic)->CreateBitCast(sharedPtr, i8Ptr, "shared.i8");
    auto* orderVal = llvm::ConstantInt::get(i32Ty, lockOrder);
    return bld(ic)->CreateCall(lockFn, {castPtr, orderVal}, "lock.result");
}

void IRGenerator::emitSharedUnlock(IRContext& ic, llvm::Value* sharedPtr) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* voidTy = llvm::Type::getVoidTy(ctx);

    auto* unlockFn = getOrDeclareExtern(ic, "__shared_unlock", voidTy, {i8Ptr});
    auto* castPtr  = bld(ic)->CreateBitCast(sharedPtr, i8Ptr, "shared.i8");
    bld(ic)->CreateCall(unlockFn, {castPtr});
}

// ─────────────────────────────────────────────────────────────────────────────
// pinned<T> alloc / free
//
// alloc → void* __dma_alloc(i64 size, i64 align, i32 direction)
// free  → void  __dma_free(void* ptr, i64 phys)
// ─────────────────────────────────────────────────────────────────────────────

llvm::Value* IRGenerator::emitPinnedAlloc(IRContext& ic, llvm::Value* size,
                                            llvm::Value* align, int direction) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* i64Ty = llvm::Type::getInt64Ty(ctx);
    auto* i32Ty = llvm::Type::getInt32Ty(ctx);

    auto* allocFn = getOrDeclareExtern(ic, "__dma_alloc",
        i8Ptr, {i64Ty, i64Ty, i32Ty});

    auto* dirVal = llvm::ConstantInt::get(i32Ty, direction);
    return bld(ic)->CreateCall(allocFn, {size, align, dirVal}, "dma.virt");
}

void IRGenerator::emitPinnedFree(IRContext& ic, llvm::Value* virtPtr,
                                   llvm::Value* physAddr) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* i64Ty = llvm::Type::getInt64Ty(ctx);
    auto* voidTy = llvm::Type::getVoidTy(ctx);

    auto* freeFn = getOrDeclareExtern(ic, "__dma_free", voidTy, {i8Ptr, i64Ty});
    auto* castPtr = bld(ic)->CreateBitCast(virtPtr, i8Ptr, "dma.i8");
    bld(ic)->CreateCall(freeFn, {castPtr, physAddr});
}

// ─────────────────────────────────────────────────────────────────────────────
// Execution Strategy Layer (ESL) emit
//
// deterministic  → emitOwnedDrop (yukarıda)
// deferred_epoch → __epoch_defer_free(void* ptr)
// rc_atomic      → i32 __rc_dec(void* ptr)  — 0 dönünce defer
// hazard_epoch   → void __hazard_retire(void* ptr, u64 epoch)
// ─────────────────────────────────────────────────────────────────────────────

void IRGenerator::emitEpochDeferFree(IRContext& ic, llvm::Value* ptr) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* voidTy = llvm::Type::getVoidTy(ctx);

    auto* fn = getOrDeclareExtern(ic, "__epoch_defer_free", voidTy, {i8Ptr});
    auto* castPtr = bld(ic)->CreateBitCast(ptr, i8Ptr, "epoch.i8");
    bld(ic)->CreateCall(fn, {castPtr});
}

void IRGenerator::emitRcDec(IRContext& ic, llvm::Value* ptr) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* i32Ty = llvm::Type::getInt32Ty(ctx);

    // i32 __rc_dec(void* ptr) — 0 dönerse defer_free
    auto* fn      = getOrDeclareExtern(ic, "__rc_dec", i32Ty, {i8Ptr});
    auto* castPtr = bld(ic)->CreateBitCast(ptr, i8Ptr, "rc.i8");
    auto* result  = bld(ic)->CreateCall(fn, {castPtr}, "rc.result");

    // rc == 0 → epoch defer
    auto* zero   = llvm::ConstantInt::get(i32Ty, 0);
    auto* isZero = bld(ic)->CreateICmpEQ(result, zero, "rc.zero");
    auto* curBB  = bld(ic)->GetInsertBlock();
    auto* deferBB= llvm::BasicBlock::Create(ctx, "rc.defer", ic.fn);
    auto* endBB  = llvm::BasicBlock::Create(ctx, "rc.end",   ic.fn);

    bld(ic)->CreateCondBr(isZero, deferBB, endBB);

    bld(ic)->SetInsertPoint(deferBB);
    emitEpochDeferFree(ic, ptr);
    bld(ic)->CreateBr(endBB);

    bld(ic)->SetInsertPoint(endBB);
}

void IRGenerator::emitHazardRetire(IRContext& ic, llvm::Value* ptr) {
    auto& ctx   = *ic.ctx;
    auto* i8Ptr = llvm::PointerType::get(llvm::Type::getInt8Ty(ctx), 0);
    auto* i64Ty = llvm::Type::getInt64Ty(ctx);
    auto* voidTy = llvm::Type::getVoidTy(ctx);

    // Global epoch'u oku
    auto* epochGlobal = ic.mod->getOrInsertGlobal("__global_epoch", i64Ty);
    auto* epoch = bld(ic)->CreateLoad(i64Ty, epochGlobal, "cur.epoch");

    // void __hazard_retire(void* ptr, i64 epoch)
    auto* fn      = getOrDeclareExtern(ic, "__hazard_retire", voidTy, {i8Ptr, i64Ty});
    auto* castPtr = bld(ic)->CreateBitCast(ptr, i8Ptr, "hazard.i8");
    bld(ic)->CreateCall(fn, {castPtr, epoch});
}

} // namespace corelang::irgen
