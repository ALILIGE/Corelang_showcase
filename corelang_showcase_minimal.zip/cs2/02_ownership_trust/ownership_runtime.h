#pragma once
// runtime/ownership_runtime.h — CoreLang Ownership + ESL + IPC + Trust Runtime
// IRGen bu başlığa ihtiyaç duymaz (getOrDeclareExtern kullanır),
// ama C test kodları ve runtime kendisi için forward decl gerekir.

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// ── owned<T> ─────────────────────────────────────────────────────────────────
void*    __memory_alloc(uint64_t size);
void     __memory_free(void* ptr);

// ── shared<T> ────────────────────────────────────────────────────────────────
void*    __shared_new(uint64_t data_size, int lock_order);
int      __shared_lock(void* ptr, int order);
void     __shared_unlock(void* ptr);
void     __shared_release_ref(void* ptr);

// ── pinned<T> / DMA ──────────────────────────────────────────────────────────
void*    __dma_alloc(uint64_t size, uint64_t align, int direction);
void     __dma_free(void* ptr, uint64_t phys);
uint64_t __dma_virt_to_phys(void* virt);

// ── Execution Strategy Layer ─────────────────────────────────────────────────
extern volatile uint64_t __global_epoch;
void     __epoch_tick(void);
void     __epoch_defer_free(void* ptr);
void     __epoch_flush(void);

void*    __rc_new(uint64_t data_size);
void     __rc_inc(void* ptr);
int32_t  __rc_dec(void* ptr);
int32_t  __rc_dec_irq_safe(void* ptr);

void     __hazard_retire(void* ptr, uint64_t epoch);
void     __hazard_flush(uint32_t num_cpus);
void     __hazard_cpu_epoch_set(uint32_t cpu_id, uint64_t epoch);

// ── Module Ownership Registry ────────────────────────────────────────────────
void     __module_registry_init(uint32_t module_id);
void     __module_track_alloc(uint32_t module_id, void* ptr, uint8_t kind, uint64_t phys);
void     __module_untrack_alloc(uint32_t module_id, void* ptr);
void     __module_force_drop(uint32_t module_id);

// ── IPC Ownership ────────────────────────────────────────────────────────────
void     __ipc_send_transfer(void* edge_meta, void* data);
void     __ipc_send_borrow(void* edge_meta, void* data, uint32_t max_delay_us);
void*    __ipc_shared_map(void* edge_meta, void* virt_ptr, uint64_t phys_addr);
void     __ipc_send(void* channel, void* data);
void*    __ipc_recv(void* channel);

// ── Trust + Ownership ────────────────────────────────────────────────────────
void     __trust_observe(void* trust_ptr);
void     __trust_reset(void* trust_ptr, float initial_score);

#ifdef __cplusplus
}
#endif
