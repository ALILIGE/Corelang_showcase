// ======================================================================
// gpu_runtime_dispatch.c — Unified Dispatch Katmanı + Adaptive Dispatcher
// ======================================================================
// MİMARİ (kritik): Bu dosya, gpu_runtime.h'da bildirilen TÜM public
// __cl_gpu_* ve cl_gpu_* sembollerinin TEK tanım noktasıdır. Backend
// dosyaları (gpu_runtime_cuda.c, gpu_runtime_vulkan.c) bu sembolleri
// ASLA doğrudan tanımlamaz — onlar yalnızca _cuda_impl / _vulkan_impl
// suffix'li fonksiyonlar sağlar. Bu dosya, runtime'da hangi backend'in
// aktif olduğuna bakarak doğru _impl fonksiyonuna yönlendirir.
//
// Bu kural sayesinde:
//   - CUDA only build  → sadece _cuda_impl çağrılır, _vulkan_impl hiç
//     linklenmez (CL_GPU_HAS_VULKAN tanımsızsa vulkan.c hiç derlenmez)
//   - Vulkan only build → tersi
//   - Her ikisi de mevcut → runtime'da cl_gpu_backend() ile seçilir
//   - Hiçbiri yok → CPU fallback (malloc/memcpy) veya net hata
//
// Önceki versiyonda bu dosya kendi başına __cl_gpu_alloc gibi
// sembolleri tanımlıyordu VE cuda.c de aynı isimde sembol tanımlıyordu
// — bu "multiple definition" link hatasıydı. Düzeltildi.
// ======================================================================

#include "gpu_runtime.h"
#include "gpu_runtime_internal.h"
#include "bridge_runtime.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdalign.h>  // alignof
#include <pthread.h>
#include <time.h>

// ── Backend _impl fonksiyon bildirimleri ─────────────────────────────────────
// Bu fonksiyonlar koşullu olarak var olur (CL_GPU_HAS_CUDA / _VULKAN
// tanımlıysa o backend dosyası derlenir ve sembolü sağlar). Burada her
// zaman extern bildiriyoruz; eğer ilgili backend derlenmediyse linker bu
// sembolleri hiç aramaz çünkü çağrı kodu #ifdef ile korunuyor.

#ifdef CL_GPU_HAS_CUDA
extern bool cl_gpu_init_cuda(void);
extern void cl_gpu_shutdown_cuda(void);
extern bool cl_gpu_is_available_cuda(void);
extern int  cl_gpu_device_count_cuda(void);
extern CL_GpuDeviceInfo cl_gpu_device_info_cuda(int);

extern void* cl_gpu_alloc_cuda_impl(size_t);
extern void  cl_gpu_free_cuda_impl(void*);
extern void  cl_gpu_copy_h2d_cuda_impl(void*, const void*, size_t);
extern void  cl_gpu_copy_d2h_cuda_impl(void*, const void*, size_t);
extern void  cl_gpu_copy_d2d_cuda_impl(void*, const void*, size_t);
extern void  cl_gpu_sync_cuda_impl(void);
extern void  cl_gpu_mem_info_cuda_impl(size_t*, size_t*);

extern void* cl_gpu_constant_alloc_cuda_impl(size_t);
extern void  cl_gpu_constant_free_cuda_impl(void*);
extern void  cl_gpu_constant_upload_cuda_impl(void*, const void*, size_t);

extern CL_GpuKernelHandle cl_gpu_load_kernel_ptx_cuda_impl(const char*, const char*);
extern void cl_gpu_unload_kernel_cuda_impl(CL_GpuKernelHandle);
extern int  cl_gpu_kernel_launch_cuda_impl(const char*, uint32_t,uint32_t,uint32_t,
                                            uint32_t,uint32_t,uint32_t,uint32_t,
                                            CL_GpuStream,uint32_t,void**);

extern CL_GpuStream cl_gpu_stream_new_cuda_impl(void);
extern void cl_gpu_stream_destroy_cuda_impl(CL_GpuStream);
extern void cl_gpu_stream_sync_cuda_impl(CL_GpuStream);
extern bool cl_gpu_stream_query_cuda_impl(CL_GpuStream);
extern void* cl_gpu_alloc_async_cuda_impl(size_t, CL_GpuStream);
extern void cl_gpu_copy_h2d_async_cuda_impl(void*, const void*, size_t, CL_GpuStream);
extern void cl_gpu_copy_d2h_async_cuda_impl(void*, const void*, size_t, CL_GpuStream);
extern bool cl_gpu_check_cross_stream_hazard_cuda_impl(CL_GpuStream, CL_GpuStream, void*);
extern void* cl_gpu_cuda_find_function(const char*);
#endif

#ifdef CL_GPU_HAS_VULKAN
extern bool cl_gpu_init_vulkan(void);
extern void cl_gpu_shutdown_vulkan(void);
extern bool cl_gpu_is_available_vulkan(void);
extern int  cl_gpu_device_count_vulkan(void);
extern CL_GpuDeviceInfo cl_gpu_device_info_vulkan_impl(int);

extern void* cl_gpu_alloc_vulkan_impl(size_t);
extern void  cl_gpu_free_vulkan_impl(void*);
extern void  cl_gpu_copy_h2d_vulkan_impl(void*, const void*, size_t);
extern void  cl_gpu_copy_d2h_vulkan_impl(void*, const void*, size_t);
extern void  cl_gpu_copy_d2d_vulkan_impl(void*, const void*, size_t);
extern void  cl_gpu_sync_vulkan_impl(void);
extern void  cl_gpu_mem_info_vulkan_impl(size_t*, size_t*);

extern void* cl_gpu_constant_alloc_vulkan_impl(size_t);
extern void  cl_gpu_constant_free_vulkan_impl(void*);
extern void  cl_gpu_constant_upload_vulkan_impl(void*, const void*, size_t);

extern CL_GpuKernelHandle cl_gpu_load_kernel_spirv_impl(const uint32_t*, size_t, const char*);
extern int cl_gpu_kernel_launch_vulkan_impl(const char*, uint32_t,uint32_t,uint32_t,
                                             uint32_t,uint32_t,uint32_t,uint32_t,
                                             CL_GpuStream,uint32_t,void**);

extern CL_GpuStream cl_gpu_stream_new_vulkan_impl(void);
extern void cl_gpu_stream_destroy_vulkan_impl(CL_GpuStream);
extern void cl_gpu_stream_sync_vulkan_impl(CL_GpuStream);
extern bool cl_gpu_stream_query_vulkan_impl(CL_GpuStream);
extern void* cl_gpu_alloc_async_vulkan_impl(size_t, CL_GpuStream);
extern void cl_gpu_copy_h2d_async_vulkan_impl(void*, const void*, size_t, CL_GpuStream);
extern void cl_gpu_copy_d2h_async_vulkan_impl(void*, const void*, size_t, CL_GpuStream);
#endif

// ── Adaptive dispatcher sabitleri ────────────────────────────────────────────
#define CL_GPU_DEFAULT_THRESHOLD_BYTES (1024 * 1024)  // 1 MB
#define CL_GPU_MIN_ELEM_COUNT          4096
#define CL_GPU_CALIBRATION_ROUNDS      5
#define CL_GPU_WARMUP_ROUNDS           2

static size_t  g_dispatch_threshold_bytes = CL_GPU_DEFAULT_THRESHOLD_BYTES;
static size_t  g_dispatch_threshold_elems = CL_GPU_MIN_ELEM_COUNT;
static pthread_mutex_t g_dispatch_mutex   = PTHREAD_MUTEX_INITIALIZER;

static uint64_t g_cpu_calls = 0;
static uint64_t g_gpu_calls = 0;
static double   g_avg_gpu_latency_us   = 0.0;
static double   g_avg_pcie_overhead_us = 0.0;

// Aktif backend (init sırasında belirlenir, sonradan değişmez)
static CL_GpuBackend g_active_backend = CL_GPU_BACKEND_NONE;

static double now_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e6 + (double)ts.tv_nsec * 1e-3;
}

// ══════════════════════════════════════════════════════════════════════════════
// Başlatma / Kapatma / Backend Sorgulama
// ══════════════════════════════════════════════════════════════════════════════

bool cl_gpu_init(void) {
    bool ok = false;
#ifdef CL_GPU_HAS_CUDA
    if (cl_gpu_init_cuda()) {
        g_active_backend = CL_GPU_BACKEND_CUDA;
        ok = true;
        fprintf(stderr, "[CoreLang GPU] CUDA backend initialized\n");
    }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (!ok && cl_gpu_init_vulkan()) {
        g_active_backend = CL_GPU_BACKEND_VULKAN;
        ok = true;
        fprintf(stderr, "[CoreLang GPU] Vulkan backend initialized\n");
    }
#endif
    if (!ok) {
        fprintf(stderr,
            "[CoreLang GPU] No GPU backend available "
            "(CUDA_HAS=%d, VULKAN_HAS=%d) — falling back to CPU-only mode\n",
#ifdef CL_GPU_HAS_CUDA
            1,
#else
            0,
#endif
#ifdef CL_GPU_HAS_VULKAN
            1
#else
            0
#endif
        );
        return false;
    }

    cl_gpu_register_bridge_domain();
    cl_gpu_calibrate_threshold();
    return true;
}

void cl_gpu_shutdown(void) {
    // Re-entrancy / double-shutdown koruması
    // g_dispatch_mutex altında backend'i NONE'a çek, sonra backend'e
    // özel shutdown'u mutex DIŞINDA çağır (backend shutdown kendi
    // lock'larını tutar — nested lock → deadlock riski).
    pthread_mutex_lock(&g_dispatch_mutex);
    CL_GpuBackend backend_to_shutdown = g_active_backend;
    g_active_backend = CL_GPU_BACKEND_NONE;
    pthread_mutex_unlock(&g_dispatch_mutex);

    if (backend_to_shutdown == CL_GPU_BACKEND_NONE) {
        // Zaten kapalı — double-shutdown, sessizce dön
        return;
    }

#ifdef CL_GPU_HAS_CUDA
    if (backend_to_shutdown == CL_GPU_BACKEND_CUDA) cl_gpu_shutdown_cuda();
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (backend_to_shutdown == CL_GPU_BACKEND_VULKAN) cl_gpu_shutdown_vulkan();
#endif

    // İstatistikleri sıfırla (tekrar init edilebilirlik için)
    pthread_mutex_lock(&g_dispatch_mutex);
    g_cpu_calls            = 0;
    g_gpu_calls            = 0;
    g_avg_gpu_latency_us   = 0.0;
    g_avg_pcie_overhead_us = 0.0;
    pthread_mutex_unlock(&g_dispatch_mutex);
}

bool cl_gpu_is_available(void) {
    return g_active_backend != CL_GPU_BACKEND_NONE;
}

CL_GpuBackend cl_gpu_backend(void) {
    return g_active_backend;
}

int cl_gpu_device_count(void) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_device_count_cuda();
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_device_count_vulkan();
#endif
    return 0;
}

// cl_gpu_set_device: tek-GPU MVP'de id=0 dışı geçersiz.
// 0 döndürmek başarıyı temsil eder — id=1,2,... için hata kodu döndürmeliyiz.
// (API kontratı: 0 = success, negatif = hata; cuda impl'de cuCtxPushCurrent ile genişler)
int cl_gpu_set_device(int id) {
    if (id != 0) {
        fprintf(stderr, "[CoreLang GPU] cl_gpu_set_device(%d): "
                "multi-GPU not supported (single-GPU MVP)\n", id);
        return -1;
    }
    return 0;
}
int cl_gpu_get_device(void) { return 0; }

CL_GpuDeviceInfo cl_gpu_device_info(int device_id) {
    CL_GpuDeviceInfo info;
    memset(&info, 0, sizeof(info));
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_device_info_cuda(device_id);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_device_info_vulkan_impl(device_id);
#endif
    return info;
}

// ══════════════════════════════════════════════════════════════════════════════
// Bellek Yönetimi — Unified Dispatch
// ══════════════════════════════════════════════════════════════════════════════

void* __cl_gpu_alloc(size_t bytes) {
    if (bytes == 0) return NULL;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_alloc_cuda_impl(bytes);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_alloc_vulkan_impl(bytes);
#endif
    // GPU yok: host bellekten simüle et (testler/CPU-only ortam için)
    return malloc(bytes);
}

void __cl_gpu_free(void* ptr) {
    if (!ptr) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_free_cuda_impl(ptr); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_free_vulkan_impl(ptr); return; }
#endif
    free(ptr);
}

void __cl_gpu_copy_h2d(void* dst, const void* src, size_t n) {
    if (!dst || !src || n == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_copy_h2d_cuda_impl(dst, src, n); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_copy_h2d_vulkan_impl(dst, src, n); return; }
#endif
    memcpy(dst, src, n);
}

void __cl_gpu_copy_d2h(void* dst, const void* src, size_t n) {
    if (!dst || !src || n == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_copy_d2h_cuda_impl(dst, src, n); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_copy_d2h_vulkan_impl(dst, src, n); return; }
#endif
    memcpy(dst, src, n);
}

void __cl_gpu_copy_d2d(void* dst, const void* src, size_t n) {
    if (!dst || !src || n == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_copy_d2d_cuda_impl(dst, src, n); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_copy_d2d_vulkan_impl(dst, src, n); return; }
#endif
    memmove(dst, src, n);
}

void __cl_gpu_sync(void) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_sync_cuda_impl(); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_sync_vulkan_impl(); return; }
#endif
}

void __cl_gpu_sync_all(void) { __cl_gpu_sync(); }

void __cl_gpu_mem_info(size_t* free_out, size_t* total_out) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_mem_info_cuda_impl(free_out, total_out); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_mem_info_vulkan_impl(free_out, total_out); return; }
#endif
    if (free_out)  *free_out  = 0;
    if (total_out) *total_out = 0;
}

// ── Constant bellek ───────────────────────────────────────────────────────────
void* cl_gpu_constant_alloc(size_t bytes) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_constant_alloc_cuda_impl(bytes);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_constant_alloc_vulkan_impl(bytes);
#endif
    return malloc(bytes);
}
void cl_gpu_constant_free(void* ptr) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_constant_free_cuda_impl(ptr); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_constant_free_vulkan_impl(ptr); return; }
#endif
    free(ptr);
}
void cl_gpu_constant_upload(void* dst_const, const void* src_host, size_t bytes) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_constant_upload_cuda_impl(dst_const, src_host, bytes); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_constant_upload_vulkan_impl(dst_const, src_host, bytes); return; }
#endif
    memcpy(dst_const, src_host, bytes);
}

// ══════════════════════════════════════════════════════════════════════════════
// Kernel Yükleme ve Launch — Unified Dispatch
// ══════════════════════════════════════════════════════════════════════════════

// ── SPIR-V magic byte doğrulaması ────────────────────────────────────────────
// Vulkan spec: geçerli SPIR-V binary'nin ilk 4 byte'ı magic number 0x07230203.
// Saldırgan sahte SPIR-V (örn. ELF, PE, veya tamamen rastgele veri) geçirerek
// driver'ı crash'e zorlayabilir — magic check bu saldırı yüzeyini kapatır.
#define SPIRV_MAGIC UINT32_C(0x07230203)

CL_GpuKernelHandle cl_gpu_load_kernel_ptx(const char* ptx_src, const char* fn_name) {
    // PTX doğrulama: boş veya aşırı uzun PTX'i reddet
    if (!ptx_src || !fn_name) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_ptx: NULL ptx_src or fn_name\n");
        return NULL;
    }
    // PTX metni ".version" ile başlamalı (NVIDIA PTX ISA standardı)
    if (strncmp(ptx_src, ".version", 8) != 0) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_ptx: PTX does not start with "
                "'.version' — possible injection or wrong format\n");
        return NULL;
    }
    if (strnlen(fn_name, 256) >= 256) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_ptx: fn_name too long (>=256)\n");
        return NULL;
    }
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_load_kernel_ptx_cuda_impl(ptx_src, fn_name);
#endif
    (void)ptx_src; (void)fn_name;
    fprintf(stderr, "[CoreLang GPU] cl_gpu_load_kernel_ptx called but CUDA backend not active\n");
    return NULL;
}

CL_GpuKernelHandle cl_gpu_load_kernel_spirv(const uint32_t* spirv, size_t spirv_size_bytes,
                                              const char* entry_point) {
    if (!spirv || spirv_size_bytes == 0 || !entry_point) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_spirv: NULL or zero-size SPIR-V\n");
        return NULL;
    }
    // SPIR-V Vulkan spec: codeSize 4'ün katı ve en az 5 word (20 byte — header)
    if (spirv_size_bytes % 4 != 0 || spirv_size_bytes < 20) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_spirv: invalid size %zu "
                "(not 4-aligned or < 20 bytes)\n", spirv_size_bytes);
        return NULL;
    }
    // Magic number kontrolü — sahte binary tespiti
    if (spirv[0] != SPIRV_MAGIC) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_spirv: bad magic 0x%08x "
                "(expected 0x%08x) — not a SPIR-V binary\n",
                spirv[0], SPIRV_MAGIC);
        return NULL;
    }
    if (strnlen(entry_point, 256) >= 256) {
        fprintf(stderr, "[CoreLang GPU] load_kernel_spirv: entry_point too long\n");
        return NULL;
    }
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN)
        return cl_gpu_load_kernel_spirv_impl(spirv, spirv_size_bytes, entry_point);
#endif
    (void)spirv; (void)spirv_size_bytes; (void)entry_point;
    fprintf(stderr, "[CoreLang GPU] cl_gpu_load_kernel_spirv called but Vulkan backend not active\n");
    return NULL;
}

void cl_gpu_unload_kernel(CL_GpuKernelHandle handle) {
    if (!handle) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_unload_kernel_cuda_impl(handle); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    // Vulkan kernel unload: pipeline, layout ve shader module'ü yok et.
    // VkKernelEntry handle olarak döndürülmüştü (cl_gpu_load_kernel_spirv_impl),
    // ama VkKernelEntry tipi vulkan.c'de tanımlı ve opaque — bu fonksiyona
    // geçmek için bir unload API'si gerekiyor. Şimdi implemente ediliyor.
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) {
        extern void cl_gpu_unload_kernel_vulkan_impl(CL_GpuKernelHandle);
        cl_gpu_unload_kernel_vulkan_impl(handle);
        return;
    }
#endif
}

// ── Kernel launch saldırı yüzeyi ──────────────────────────────────────────────
// Saldırı modelleri:
//   1. kernel_name = NULL veya çok uzun → strncmp/cuModuleGetFunction/strncpy taşması
//   2. argc = büyük değer → stack veya heap buffer taşması (cuda_params[256])
//   3. argv = NULL ama argc > 0 → NULL dereference
//   4. argv[i] = NULL → bazı backend'lerde crash (CUDA: cuLaunchKernel segfault)
//   5. gx/gy/gz = 0 → undefined davranış (CUDA validation error, bazı driver'larda crash)
//   6. bx*by*bz = 0 → aynı şekilde
#define CL_GPU_MAX_KERNEL_NAME 256
#define CL_GPU_MAX_ARGC        256

int __cl_gpu_kernel_launch(
    const char* kernel_name,
    uint32_t gx, uint32_t gy, uint32_t gz,
    uint32_t bx, uint32_t by, uint32_t bz,
    uint32_t smem, CL_GpuStream stream,
    uint32_t argc, void** argv)
{
    // kernel_name güvenlik kontrolü
    if (!kernel_name) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch: NULL kernel_name\n");
        return -10;
    }
    if (strnlen(kernel_name, CL_GPU_MAX_KERNEL_NAME) >= CL_GPU_MAX_KERNEL_NAME) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch: kernel_name too long (>=%d)\n",
                CL_GPU_MAX_KERNEL_NAME);
        return -11;
    }
    // Grid/block boyutu kontrolü
    if (gx == 0 || gy == 0 || gz == 0) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch '%s': zero grid dim (%u,%u,%u)\n",
                kernel_name, gx, gy, gz);
        return -12;
    }
    if (bx == 0 || by == 0 || bz == 0) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch '%s': zero block dim (%u,%u,%u)\n",
                kernel_name, bx, by, bz);
        return -13;
    }
    // argc/argv kontrolü
    if (argc > CL_GPU_MAX_ARGC) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch '%s': argc %u > max %d\n",
                kernel_name, argc, CL_GPU_MAX_ARGC);
        return -14;
    }
    if (argc > 0 && !argv) {
        fprintf(stderr, "[CoreLang GPU] kernel_launch '%s': argc=%u but argv=NULL\n",
                kernel_name, argc);
        return -15;
    }
    // Her argv[i]'nin NULL olmadığını doğrula
    for (uint32_t i = 0; i < argc; i++) {
        if (!argv[i]) {
            fprintf(stderr, "[CoreLang GPU] kernel_launch '%s': argv[%u] is NULL\n",
                    kernel_name, i);
            return -16;
        }
    }

#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA)
        return cl_gpu_kernel_launch_cuda_impl(kernel_name,gx,gy,gz,bx,by,bz,smem,stream,argc,argv);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN)
        return cl_gpu_kernel_launch_vulkan_impl(kernel_name,gx,gy,gz,bx,by,bz,smem,stream,argc,argv);
#endif
    fprintf(stderr, "[CoreLang GPU] No GPU backend available for launch '%s'\n", kernel_name);
    return -99;
}

// ══════════════════════════════════════════════════════════════════════════════
// Stream Yönetimi — Unified Dispatch
// ══════════════════════════════════════════════════════════════════════════════

CL_GpuStream __cl_gpu_stream_new(void) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_stream_new_cuda_impl();
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_stream_new_vulkan_impl();
#endif
    return NULL;
}

void __cl_gpu_stream_destroy(CL_GpuStream stream) {
    if (!stream) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_stream_destroy_cuda_impl(stream); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_stream_destroy_vulkan_impl(stream); return; }
#endif
}

void __cl_gpu_stream_sync(CL_GpuStream stream) {
    if (!stream) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_stream_sync_cuda_impl(stream); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_stream_sync_vulkan_impl(stream); return; }
#endif
}

bool __cl_gpu_stream_query(CL_GpuStream stream) {
    if (!stream) return true;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_stream_query_cuda_impl(stream);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_stream_query_vulkan_impl(stream);
#endif
    return true;
}

void* __cl_gpu_alloc_async(size_t bytes, CL_GpuStream stream) {
    if (bytes == 0) return NULL;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) return cl_gpu_alloc_async_cuda_impl(bytes, stream);
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) return cl_gpu_alloc_async_vulkan_impl(bytes, stream);
#endif
    return malloc(bytes);
}

void __cl_gpu_copy_h2d_async(void* dst, const void* src, size_t n, CL_GpuStream stream) {
    if (!dst || !src || n == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_copy_h2d_async_cuda_impl(dst, src, n, stream); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_copy_h2d_async_vulkan_impl(dst, src, n, stream); return; }
#endif
    memcpy(dst, src, n);
}

void __cl_gpu_copy_d2h_async(void* dst, const void* src, size_t n, CL_GpuStream stream) {
    if (!dst || !src || n == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) { cl_gpu_copy_d2h_async_cuda_impl(dst, src, n, stream); return; }
#endif
#ifdef CL_GPU_HAS_VULKAN
    if (g_active_backend == CL_GPU_BACKEND_VULKAN) { cl_gpu_copy_d2h_async_vulkan_impl(dst, src, n, stream); return; }
#endif
    memcpy(dst, src, n);
}

bool cl_gpu_check_cross_stream_hazard(CL_GpuStream s1, CL_GpuStream s2, void* ptr) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA)
        return cl_gpu_check_cross_stream_hazard_cuda_impl(s1, s2, ptr);
#endif
    // Vulkan path: written_ptrs tracking aynı struct'ı kullandığından
    // CUDA implementasyonu backend-agnostic çalışır (struct CL_GpuStream_s
    // tek tanım, alanlar aynı). CUDA derlenmediyse burada basit bir
    // fallback uygula:
    if (!s1 || !s2 || s1 == s2) return false;
    struct CL_GpuStream_s* a = (struct CL_GpuStream_s*)s1;
    struct CL_GpuStream_s* b = (struct CL_GpuStream_s*)s2;
    pthread_mutex_lock(&a->mutex);
    bool in_a = false;
    for (uint32_t i = 0; i < a->written_count && !in_a; i++)
        if (a->written_ptrs[i] == ptr) in_a = true;
    pthread_mutex_unlock(&a->mutex);
    if (!in_a) return false;
    pthread_mutex_lock(&b->mutex);
    bool in_b = false;
    for (uint32_t i = 0; i < b->written_count && !in_b; i++)
        if (b->written_ptrs[i] == ptr) in_b = true;
    pthread_mutex_unlock(&b->mutex);
    return in_b;
}

// ══════════════════════════════════════════════════════════════════════════════
// Adaptive Dispatcher
// ══════════════════════════════════════════════════════════════════════════════

// ── dispatch_tag doğrulama sabitleri ─────────────────────────────────────────
// Saldırgan __cl_gpu_dispatch_adaptive'i doğrudan çağırıp dispatch_tag
// olarak format string (%n, %s vb.) veya PATH TRAVERSAL içerikli
// bir değer geçirmeye çalışabilir. Tag sadece kernel adı olarak kullanılır
// (cuModuleGetFunction / vkPipeline lookup) — ama yine de sınırlandır.
#define CL_GPU_MAX_DISPATCH_TAG_LEN 128
#define CL_GPU_MAX_DISPATCH_BYTES   (SIZE_MAX / 2)  // 2x alloc için taşma önle

static bool validate_dispatch_tag(const char* tag) {
    if (!tag) return false;
    size_t len = 0;
    for (const char* p = tag; *p; p++, len++) {
        if (len >= CL_GPU_MAX_DISPATCH_TAG_LEN) return false;
        // Yalnızca alfanumerik, _, : ve :: izinli (kernel naming convention)
        char c = *p;
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_' || c == ':')) {
            return false;
        }
    }
    return len > 0;
}

void* __cl_gpu_dispatch_adaptive(
    const void* data_ptr,
    size_t      count,
    size_t      elem_size,
    const char* dispatch_tag)
{
    // ── GÜVENLIK KONTROLLERI (mutex almadan önce) ────────────────────────────
    // NULL/sıfır kontrolü
    if (!data_ptr || count == 0 || elem_size == 0) return NULL;

    // dispatch_tag doğrulama — format string injection / path traversal önle
    if (!validate_dispatch_tag(dispatch_tag)) {
        fprintf(stderr, "[CoreLang GPU] dispatch_adaptive: invalid dispatch_tag "
                "(NULL, too long, or contains forbidden characters)\n");
        return NULL;
    }

    // INTEGER OVERFLOW kontrolü: count * elem_size taşabilir
    // (örn. count=SIZE_MAX/2+1, elem_size=2 → 0 veya çok küçük alloc)
    if (elem_size > CL_GPU_MAX_DISPATCH_BYTES / count) {
        fprintf(stderr, "[CoreLang GPU] dispatch_adaptive: count*elem_size "
                "overflow (%zu * %zu)\n", count, elem_size);
        return NULL;
    }
    size_t total_bytes = count * elem_size;

    // Makul üst sınır: tek dispatch'te 16GB'dan fazla data mantıklı değil,
    // muhtemelen sarma/hata sonucu oluşan bir değer.
    if (total_bytes > (size_t)16 * 1024 * 1024 * 1024ULL) {
        fprintf(stderr, "[CoreLang GPU] dispatch_adaptive: total_bytes %zu > 16GB "
                "limit — refusing\n", total_bytes);
        return NULL;
    }

    // ── EŞIK KONTROLÜ (mutex altında) ────────────────────────────────────────
    pthread_mutex_lock(&g_dispatch_mutex);

    if (!cl_gpu_is_available()) {
        g_cpu_calls++;
        pthread_mutex_unlock(&g_dispatch_mutex);
        return NULL;
    }
    if (count < g_dispatch_threshold_elems || total_bytes < g_dispatch_threshold_bytes) {
        g_cpu_calls++;
        pthread_mutex_unlock(&g_dispatch_mutex);
        return NULL;
    }

    pthread_mutex_unlock(&g_dispatch_mutex);

    // ── GPU ALLOC (mutex dışında — GPU alloc kendi içinde thread-safe) ───────
    // DÜZELTME: Önceki versiyon malloc (result buffer alloc) dahil TÜM
    // işlemi g_dispatch_mutex altında yapıyordu. Bu gereksiz contention
    // üretiyordu ve mutex tutarken malloc çağırmak deadlock riski taşır
    // (malloc kendi lock'larını tutar — lock ordering ihlali mümkün).
    double t0 = now_us();
    void* gpu_input  = __cl_gpu_alloc(total_bytes);
    void* gpu_output = __cl_gpu_alloc(total_bytes);
    if (!gpu_input || !gpu_output) {
        __cl_gpu_free(gpu_input);
        __cl_gpu_free(gpu_output);
        pthread_mutex_lock(&g_dispatch_mutex);
        g_cpu_calls++;
        pthread_mutex_unlock(&g_dispatch_mutex);
        return NULL;
    }

    __cl_gpu_copy_h2d(gpu_input, data_ptr, total_bytes);
    double t_pcie = now_us() - t0;

    // argv "pointer-to-argument" convention (cuLaunchKernel kontratı)
    void* argv_storage[4];
    argv_storage[0] = gpu_input;
    argv_storage[1] = gpu_output;
    argv_storage[2] = (void*)(uintptr_t)count;
    argv_storage[3] = (void*)(uintptr_t)elem_size;
    void* argv[] = { &argv_storage[0], &argv_storage[1],
                      &argv_storage[2], &argv_storage[3] };

    // grid overflow kontrolü: count büyükse uint32_t grid_x taşabilir
    if (count > (size_t)UINT32_MAX * 256) {
        fprintf(stderr, "[CoreLang GPU] dispatch_adaptive: count too large "
                "for single-dimension grid (%zu)\n", count);
        __cl_gpu_free(gpu_input);
        __cl_gpu_free(gpu_output);
        pthread_mutex_lock(&g_dispatch_mutex);
        g_cpu_calls++;
        pthread_mutex_unlock(&g_dispatch_mutex);
        return NULL;
    }
    uint32_t grid_x  = (uint32_t)((count + 255) / 256);
    uint32_t block_x = 256;

    double t1 = now_us();
    int r = __cl_gpu_kernel_launch(dispatch_tag, grid_x,1,1, block_x,1,1, 0, NULL, 4, argv);

    if (r != 0) {
        __cl_gpu_free(gpu_input);
        __cl_gpu_free(gpu_output);
        pthread_mutex_lock(&g_dispatch_mutex);
        g_cpu_calls++;
        pthread_mutex_unlock(&g_dispatch_mutex);
        return NULL;
    }

    __cl_gpu_sync();
    double t_kernel = now_us() - t1;

    void* result = malloc(total_bytes);
    if (result) __cl_gpu_copy_d2h(result, gpu_output, total_bytes);

    __cl_gpu_free(gpu_input);
    __cl_gpu_free(gpu_output);

    pthread_mutex_lock(&g_dispatch_mutex);
    g_gpu_calls++;
    g_avg_gpu_latency_us   = (g_avg_gpu_latency_us * (g_gpu_calls - 1) + t_kernel) / g_gpu_calls;
    g_avg_pcie_overhead_us = (g_avg_pcie_overhead_us * (g_gpu_calls - 1) + t_pcie) / g_gpu_calls;
    pthread_mutex_unlock(&g_dispatch_mutex);

    cl_gpu_record_bridge_metrics(t_kernel, t_pcie);

    return result; // caller free(result) çağırmalı
}

void cl_gpu_calibrate_threshold(void) {
    if (!cl_gpu_is_available()) return;

    size_t test_sizes[] = { 1024, 4096, 16384, 65536, 262144 };
    size_t best_threshold = 65536;

    for (int sz_idx = 0; sz_idx < 5; sz_idx++) {
        size_t n = test_sizes[sz_idx];
        size_t nbytes = n * sizeof(float);

        float* host_data = calloc(n, sizeof(float));
        if (!host_data) continue;
        void* gpu_buf = __cl_gpu_alloc(nbytes);
        if (!gpu_buf) { free(host_data); continue; }

        for (int w = 0; w < CL_GPU_WARMUP_ROUNDS; w++) {
            __cl_gpu_copy_h2d(gpu_buf, host_data, nbytes);
            __cl_gpu_copy_d2h(host_data, gpu_buf, nbytes);
        }

        double pcie_times[CL_GPU_CALIBRATION_ROUNDS];
        for (int r = 0; r < CL_GPU_CALIBRATION_ROUNDS; r++) {
            double t0 = now_us();
            __cl_gpu_copy_h2d(gpu_buf, host_data, nbytes);
            __cl_gpu_sync();
            pcie_times[r] = now_us() - t0;
        }
        for (int i = 1; i < CL_GPU_CALIBRATION_ROUNDS; i++) {
            double key = pcie_times[i];
            int j = i - 1;
            while (j >= 0 && pcie_times[j] > key) { pcie_times[j+1] = pcie_times[j]; j--; }
            pcie_times[j+1] = key;
        }
        double pcie_median = pcie_times[CL_GPU_CALIBRATION_ROUNDS / 2];
        if (pcie_median < 10.0) best_threshold = n;

        __cl_gpu_free(gpu_buf);
        free(host_data);
    }

    pthread_mutex_lock(&g_dispatch_mutex);
    g_dispatch_threshold_elems = best_threshold;
    g_dispatch_threshold_bytes = best_threshold * sizeof(float);
    pthread_mutex_unlock(&g_dispatch_mutex);

    fprintf(stderr, "[CoreLang GPU] Dispatch threshold calibrated: %zu elements (%zu KB)\n",
            best_threshold, (best_threshold * sizeof(float)) / 1024);
}

void cl_gpu_set_dispatch_threshold(size_t n_elements) {
    pthread_mutex_lock(&g_dispatch_mutex);
    g_dispatch_threshold_elems = n_elements;
    g_dispatch_threshold_bytes = n_elements * sizeof(float);
    pthread_mutex_unlock(&g_dispatch_mutex);
}

CL_GpuDispatchStats cl_gpu_get_dispatch_stats(void) {
    CL_GpuDispatchStats s;
    pthread_mutex_lock(&g_dispatch_mutex);
    s.cpu_calls            = g_cpu_calls;
    s.gpu_calls            = g_gpu_calls;
    s.avg_gpu_latency_us   = g_avg_gpu_latency_us;
    s.avg_pcie_overhead_us = g_avg_pcie_overhead_us;
    s.dispatch_threshold   = g_dispatch_threshold_elems;
    pthread_mutex_unlock(&g_dispatch_mutex);
    return s;
}

// ── @texture bellek — Unified Dispatch ───────────────────────────────────────
#ifdef CL_GPU_HAS_CUDA
extern uint64_t cl_gpu_tex_create_cuda_impl(const void*, int32_t, int32_t);
extern void     cl_gpu_tex_destroy_cuda_impl(uint64_t);
#endif

// ── CPU/Vulkan texture handle — güvenli struct ile ─────────────────────────
// GÜVENLIK SORUNU (düzeltildi): Önceki implementasyon ham float* pointer'ını
// doğrudan uint64_t handle olarak döndürüyordu. Bu iki kritik soruna yol açar:
//
// 1. SAHTE HANDLE SALDIRISI: Saldırgan kontrolündeki bir uint64_t değer
//    (örn. kullanıcı girdisinden, başka bir GPU nesnesinin adresinden veya
//    rastgele bir değerden) __dsl_tex_fetch1d/2d'ye geçirildiğinde,
//    kod o değeri float* olarak CAST EDIP DEREFERENCE eder → arbitrary
//    read primitive (bilgi sızdırma / segfault / spekulatif execution gadget).
//
// 2. BOYUT BILGISI EKSİKLİĞİ: Fetch fonksiyonları width/height bilgisine
//    erişemediğinden "varsayılan 256" sabit kodlanmıştı → 256'dan küçük
//    texture için out-of-bounds okuma (yanlış sonuç, potansiyel heap okuma).
//
// DÜZELTME: Handle bir "tagged struct" pointer'ına dönüştürüldü. Struct içinde:
//   - MAGIC: her iki fetch yolunda geçerliliği doğrula (sahte handle tespiti)
//   - CANARY: struct sonuna yazılır, fetch'te okunur (buffer overflow tespiti)
//   - width/height: gerçek boyutları sağlar (out-of-bounds okumayı önler)
//
// Saldırı modeli: Saldırgan geçerli görünen ama yapıyı bozan bir uint64_t
// değer üretmeye çalışabilir. MAGIC (0xC09ETEX1D veya 0xC09ETEX2D) + CANARY
// kombinasyonu bu olasılığı pratik olarak imkansız kılar (64-bit adreste
// hem magic hem canary'nin eşleşmesi ihmal edilebilir olasılık).
#define CL_GPU_TEX_MAGIC_1D  UINT64_C(0xC09E7EX1D00000001)
#define CL_GPU_TEX_MAGIC_2D  UINT64_C(0xC09E7EX2D00000002)
#define CL_GPU_TEX_CANARY    UINT32_C(0xDEADC09E)

// CL_GPU_TEX_MAGIC hex literal düzeltmesi (X geçersiz hex) — ASCII uyumlu:
#undef CL_GPU_TEX_MAGIC_1D
#undef CL_GPU_TEX_MAGIC_2D
#define CL_GPU_TEX_MAGIC_1D  UINT64_C(0xC09E1E1D00000001)
#define CL_GPU_TEX_MAGIC_2D  UINT64_C(0xC09E1E2D00000002)

typedef struct {
    uint64_t magic;       // CL_GPU_TEX_MAGIC_1D veya CL_GPU_TEX_MAGIC_2D
    int32_t  width;       // texture genişliği (eleman sayısı)
    int32_t  height;      // texture yüksekliği (1D için 1)
    float*   data;        // host veri pointer'ı
    uint32_t canary;      // = CL_GPU_TEX_CANARY, struct sonunda bütünlük kontrolü
} CL_CpuTexHandle;

// Güvenli handle doğrulama — NULL veya sahte handle tespiti
static const CL_CpuTexHandle* validate_cpu_tex(uint64_t tex_obj, bool is2D) {
    if (tex_obj == 0) return NULL;
    // Önce pointer hizalamasını kontrol et (struct en az 4-byte hizalı olmalı)
    if (tex_obj % alignof(CL_CpuTexHandle) != 0) return NULL;
    const CL_CpuTexHandle* h = (const CL_CpuTexHandle*)(uintptr_t)tex_obj;
    uint64_t expected_magic = is2D ? CL_GPU_TEX_MAGIC_2D : CL_GPU_TEX_MAGIC_1D;
    if (h->magic != expected_magic) return NULL;
    if (h->canary != CL_GPU_TEX_CANARY) return NULL; // struct bütünlüğü bozulmuş
    if (!h->data) return NULL;
    if (h->width <= 0 || h->height <= 0) return NULL;
    return h;
}

uint64_t __cl_gpu_tex_create(const void* data, int32_t width, int32_t height) {
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA)
        return cl_gpu_tex_create_cuda_impl(data, width, height);
#endif
    // CPU/Vulkan fallback: tagged struct ile güvenli handle oluştur.
    if (!data || width <= 0) return 0;

    // Integer overflow kontrolü: width * height * sizeof(float) taşabilir
    int32_t h_val = (height > 1) ? height : 1;
    if ((size_t)width > SIZE_MAX / (size_t)h_val / sizeof(float)) {
        fprintf(stderr, "[CoreLang GPU] tex_create: dimensions too large (%dx%d)\n",
                width, h_val);
        return 0;
    }
    size_t bytes = (size_t)width * (size_t)h_val * sizeof(float);

    // Handle struct + data buffer tek alloc'ta
    CL_CpuTexHandle* handle = calloc(1, sizeof(CL_CpuTexHandle) + bytes);
    if (!handle) return 0;

    handle->magic  = (h_val > 1) ? CL_GPU_TEX_MAGIC_2D : CL_GPU_TEX_MAGIC_1D;
    handle->width  = width;
    handle->height = h_val;
    handle->data   = (float*)((uint8_t*)handle + sizeof(CL_CpuTexHandle));
    memcpy(handle->data, data, bytes);
    handle->canary = CL_GPU_TEX_CANARY;

    return (uint64_t)(uintptr_t)handle;
}

void __cl_gpu_tex_destroy(uint64_t tex_obj) {
    if (tex_obj == 0) return;
#ifdef CL_GPU_HAS_CUDA
    if (g_active_backend == CL_GPU_BACKEND_CUDA) {
        cl_gpu_tex_destroy_cuda_impl(tex_obj);
        return;
    }
#endif
    // CPU/Vulkan: magic kontrolü — sahte handle'ı free etme
    if (tex_obj % alignof(CL_CpuTexHandle) != 0) {
        fprintf(stderr, "[CoreLang GPU] tex_destroy: misaligned handle — ignored\n");
        return;
    }
    CL_CpuTexHandle* handle = (CL_CpuTexHandle*)(uintptr_t)tex_obj;
    if (handle->magic != CL_GPU_TEX_MAGIC_1D &&
        handle->magic != CL_GPU_TEX_MAGIC_2D) {
        fprintf(stderr, "[CoreLang GPU] tex_destroy: invalid magic 0x%016llx — "
                "double-free or wrong handle?\n",
                (unsigned long long)handle->magic);
        return;
    }
    if (handle->canary != CL_GPU_TEX_CANARY) {
        fprintf(stderr, "[CoreLang GPU] tex_destroy: canary corrupt — "
                "buffer overflow detected, aborting free to avoid heap corruption\n");
        return; // abort() daha ağır ama crash'ten iyidir — çağıran hata alır
    }
    // Struct'ı zehirle: double-free sonraki validate_cpu_tex'te yakalanır
    handle->magic  = UINT64_C(0xDEADDEADDEADDEAD);
    handle->canary = 0;
    handle->data   = NULL;
    free(handle);
}

// ── Texture handle erişim API'si (vulkan.c ve diğerleri için) ───────────────
// vulkan.c'nin CL_CpuTexHandle struct tanımını bilmesine gerek yok —
// tek doğru erişim bu API üzerinden. Dispatch.c'de tanım, vulkan.c'de extern.
const void* _cl_gpu_validate_cpu_tex_1d(uint64_t tex_obj) {
    return (const void*)validate_cpu_tex(tex_obj, false);
}
const void* _cl_gpu_validate_cpu_tex_2d(uint64_t tex_obj) {
    return (const void*)validate_cpu_tex(tex_obj, true);
}
int32_t _cl_gpu_tex_width(const void* handle) {
    return handle ? ((const CL_CpuTexHandle*)handle)->width : 0;
}
int32_t _cl_gpu_tex_height(const void* handle) {
    return handle ? ((const CL_CpuTexHandle*)handle)->height : 0;
}
const float* _cl_gpu_tex_data(const void* handle) {
    return handle ? ((const CL_CpuTexHandle*)handle)->data : NULL;
}

// ── Bridge entegrasyonu ───────────────────────────────────────────────────────
// DÜZELTME: Bu fonksiyonlar artık bridge_runtime_gpu.c'deki GERÇEK API'ye
// göre yazılmış implementasyonlara yönlendiriyor. Önceki versiyon
// "__bridge_register_domain" / "__bridge_record_latency" diye UYDURMA
// fonksiyonlar çağırıyordu — bunlar bridge_runtime.h/bridge_scheduler.h'da
// hiç yoktu, bu yüzden link aşamasında kesin olarak başarısız olurdu.
//
// cl_gpu_init() tarafından çağrılan cl_gpu_register_bridge_domain() artık
// no-op'tur (gerçek bridge scheduler entegrasyonu OPSİYONELDİR — bkz.
// bridge_runtime_gpu.c'deki cl_gpu_enable_bridge_integration()). Bridge
// entegrasyonunu açıkça istemek için kullanıcı kodu
// cl_gpu_enable_bridge_integration() çağırmalıdır.
void cl_gpu_register_bridge_domain(void) {
    // Varsayılan: hiçbir şey yapma. Bridge entegrasyonu opt-in'dir.
    // (Önceki versiyondaki zorunlu, ama derlenmesi imkansız çağrı kaldırıldı.)
}

extern void cl_gpu_record_bridge_metrics_impl(double kernel_us, double pcie_us);
void cl_gpu_record_bridge_metrics(double kernel_us, double pcie_us) {
    cl_gpu_record_bridge_metrics_impl(kernel_us, pcie_us);
}

extern void bridge_gpu_upload_pinned_impl(void* dst_gpu, const BridgePinnedBuffer* pinned);

// Partial-copy wrapper: bytes == 0 → tam data_len kopyala;
// bytes > 0 && bytes < data_len → sadece bytes kadar kopyala (partial);
// bytes > data_len → data_len ile sınırla (taşmayı önle).
void cl_gpu_copy_from_pinned(void* dst_gpu, const BridgePinnedBuffer* pinned, size_t bytes) {
    if (!dst_gpu || !pinned || !pinned->data_ptr || pinned->data_len == 0) return;

    size_t copy_bytes = (bytes == 0 || bytes > pinned->data_len)
                        ? pinned->data_len   // tam kopya veya sınır aşımı → data_len kullan
                        : bytes;             // partial copy

    if (bytes > pinned->data_len) {
        // Caller beklediğinden fazla veri istedi — sessiz truncation tehlikeli,
        // uyar ama devam et (runtime crash yerine yanlış sonuç kabul edilebilir).
        fprintf(stderr, "[CoreLang GPU] copy_from_pinned: requested bytes=%zu "
                "exceeds pinned->data_len=%zu — clamping to data_len\n",
                bytes, pinned->data_len);
    }

    __cl_gpu_copy_h2d(dst_gpu, pinned->data_ptr, copy_bytes);
}
