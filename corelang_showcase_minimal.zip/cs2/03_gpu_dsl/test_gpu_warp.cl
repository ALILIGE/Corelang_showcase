// ======================================================================
// tests/faz2/test_gpu_warp.cl — warp:: shuffle/vote + reduction pattern
// ======================================================================
// warp::shuffle_down → llvm.nvvm.shfl.sync.down.f32 intrinsic
// warp::all / warp::any → llvm.nvvm.vote.all/any.sync
// warp::ballot → llvm.nvvm.vote.ballot.sync
// warp::lane_id → llvm.nvvm.read.ptx.sreg.laneid
//
// Bu test, DSL spec'indeki warp reduce sum örneğini doğrular.

// ── Warp içi reduction ────────────────────────────────────────────────────────
kernel fn warp_reduce(
    input:  *const @global f32,
    output: *mut @global f32
) {
    let gid: i32 = block.idx.x * block.dim.x + thread.idx.x;
    let val: f32 = input[gid];

    // warp::shuffle_down ile tree reduction
    var v: f32   = val;
    var off: i32 = warp.size / 2;

    while off > 0 {
        v   = v + warp::shuffle_down(v, off);
        off = off / 2;
    }

    // Sadece lane 0 yazar
    let lane: i32 = warp::lane_id();
    if lane == 0 {
        output[block.idx.x] = v;
    }
}

// ── Warp vote: predicate testi ────────────────────────────────────────────────
kernel fn warp_vote_test(
    data:   *const @global i32,
    flags:  *mut @global i32
) {
    let gid: i32  = block.idx.x * block.dim.x + thread.idx.x;
    let val: i32  = data[gid];
    let pred: bool = val > 0;

    // Tüm warp'ta pozitif mi?
    let all_pos:  bool   = warp::all(pred);
    // En az biri pozitif mi?
    let any_pos:  bool   = warp::any(pred);
    // Hangi lane'ler pozitif?
    let ballot:   u32    = warp::ballot(pred);

    if warp::lane_id() == 0 {
        flags[block.idx.x * 3]     = all_pos;
        flags[block.idx.x * 3 + 1] = any_pos;
        flags[block.idx.x * 3 + 2] = ballot;
    }
}

// ── Warp shuffle: ring shift ──────────────────────────────────────────────────
// Her thread bir sonraki lane'e kendi değerini gönderir (ring shift)
kernel fn warp_ring_shift(
    data: *mut @global f32
) {
    let gid:  i32 = block.idx.x * block.dim.x + thread.idx.x;
    let lane: i32 = warp::lane_id();
    let val:  f32 = data[gid];

    // Shuffle up: lane N, lane N-1'den değer alır
    let received: f32 = warp::shuffle_up(val, 1);

    // lane 0 wrap-around için warp.size - 1'den al
    let from_last: f32 = warp::shuffle(val, warp.size - 1);
    let result:    f32 = if lane == 0 { from_last } else { received };

    data[gid] = result;
}

// ── Host: warp testlerini çalıştır ───────────────────────────────────────────
fn main() -> i32 {
    let n: i64    = 256; // 8 warp
    let bytes: usize = n * 4;

    let d_in:  *mut @global f32 = gpu::alloc(bytes);
    let d_out: *mut @global f32 = gpu::alloc(bytes);

    launch warp_reduce<<<grid(1, 1, 1), block(256, 1, 1)>>>(d_in, d_out);
    gpu::sync();

    let d_flags: *mut @global i32 = gpu::alloc(bytes);
    launch warp_vote_test<<<grid(1, 1, 1), block(256, 1, 1)>>>(d_in, d_flags);
    gpu::sync();

    launch warp_ring_shift<<<grid(1, 1, 1), block(256, 1, 1)>>>(d_in);
    gpu::sync();

    gpu::free(d_in);
    gpu::free(d_out);
    gpu::free(d_flags);
    return 0;
}
