// ======================================================================
// tests/faz2/test_gpu_accelerated.cl — #[gpu_accelerated] + stream
// ======================================================================
// #[gpu_accelerated]:
//   - gpu::parallel_for closure → GpuParallelForPass → kernel + dispatch
//   - __cl_gpu_dispatch_adaptive: CPU/GPU seçimi
//   - Captures → @constant bellek
//
// gpu::stream:
//   - Async copy + kernel overlap
//   - gpu::stream::new() / destroy() / sync()
//   - Cross-stream launch

// ── #[gpu_accelerated]: hash tarama ─────────────────────────────────────────
// CoreLang tip sistemi gerçek generic yapıları destekler;
// test amacıyla i64 hash olarak temsil edilir.

#[gpu_accelerated]
fn scan_hashes(
    file_hashes: *const @global i64,
    count:       i64,
    threat_mask: i64
) -> i64 {
    // gpu::parallel_for: her hash'i threat_mask ile AND alarak tehdit ara
    // GpuParallelForPass bu closure'ı otomatik kernel'e çevirir
    gpu::parallel_reduce(file_hashes, count, 0 as i64, |acc: i64, h: i64| -> i64 {
        acc + ((h & threat_mask) as i64)
    })
}

// ── #[gpu_accelerated]: toplu şifreleme ──────────────────────────────────────
#[gpu_accelerated]
fn encrypt_assets(
    plaintext: *const @global u8,
    ciphertext: *mut @global u8,
    count:  i64,
    key:    u64
) {
    // gpu::parallel_map: her bloğu XOR ile şifrele
    gpu::parallel_map(plaintext, count, |block: u8| -> u8 {
        block ^ (key as u8)
    });
}

// ── Stream testi: iki stream paralel çalışma ──────────────────────────────────
fn parallel_streams_test() -> i32 {
    let n: i64    = 65536;
    let bytes: usize = n * 4;

    // İki stream oluştur
    let s1: GpuStream = gpu::stream::new();
    let s2: GpuStream = gpu::stream::new();

    // Stream 1: vektör A tahsisi + kopyası
    let d_a: *mut @global f32 = gpu::alloc_async(bytes, s1);
    gpu::copy_h2d_async(d_a, d_a, bytes, s1);  // placeholder

    // Stream 2: vektör B tahsisi + kopyası (paralel)
    let d_b: *mut @global f32 = gpu::alloc_async(bytes, s2);
    gpu::copy_h2d_async(d_b, d_b, bytes, s2);

    // Stream 1 üzerinde kernel fırlat
    launch vector_add_stream<<<grid(256, 1, 1), block(256, 1, 1), s1>>>(d_a, d_b, d_a, n);

    // Tüm stream'leri bekle
    gpu::sync_all();

    gpu::free(d_a);
    gpu::free(d_b);
    gpu::stream::destroy(s1);
    gpu::stream::destroy(s2);
    return 0;
}

// ── Akış içinde kernel tanımı ─────────────────────────────────────────────────
kernel fn vector_add_stream(
    a: *const @global f32,
    b: *const @global f32,
    c: *mut @global f32,
    n: i64
) {
    let idx: i32 = block.idx.x * block.dim.x + thread.idx.x;
    if idx < n {
        c[idx] = a[idx] + b[idx];
    }
}

fn main() -> i32 {
    // Adaptive dispatch: 65536 eleman → GPU seçilir
    let d_hashes:  *mut @global i64 = gpu::alloc(65536 * 8);
    let result: i64 = scan_hashes(d_hashes, 65536, 0xFF00FF00FF00FF00);
    gpu::free(d_hashes);

    // Stream testi
    parallel_streams_test();
    return 0;
}
