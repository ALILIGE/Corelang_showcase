// ======================================================================
// dsl_gpu.h — CoreLang GPU DSL: "ZA HANDO: LATENCY ERASE"
// ======================================================================
// GPU programlama için CoreLang DSL frontend sınıfları.
// Her sınıf DSLFrontend'i extend eder ve capability descriptor sistemiyle
// OOP Requiem garantisine uyar.
//
// Sınıflar:
//   GpuMemDSL       — gpu:: namespace: alloc/free/copy/sync (host-side)
//   GpuKernelDSL    — kernel fn bildirimi ve launch<<< >>> lowering
//   GpuBlockDSL     — block:: senkronizasyon (GPUDevice only)
//   GpuWarpDSL      — warp:: shuffle/vote (GPUDevice only, WarpDSL yerini alır)
//   GpuAccelDSL     — #[gpu_accelerated] attribute + gpu::parallel_for/map
//   GpuStreamDSL    — gpu::stream:: async stream yönetimi
//   GpuPolicyDSL    — #[policy(gpu_*)] GPU kernel optimizasyon politikası
//
// Backend seçimi:
//   -target=nvidia_ptx  → LLVM nvptx64-nvidia-cuda
//   -target=spirv_vulkan → SPIR-V (Vulkan compute)
//
// Bellek niteleyicileri (@global, @shared, @constant, @texture)
// CoreLang tip sistemine capability.h aracılığıyla entegre edilir.
//
// Bridge DSL entegrasyonu:
//   BridgeDomain::GPU_COMPUTE kullanılır.
//   BridgePinnedBuffer → gpu::copy_h2d için doğrudan kullanım.
//   BridgeScheduler GPU domain queue üzerinden adaptive dispatch.
// ======================================================================

#pragma once
#include "dsl.h"
#include "../frontend/ast.h"
#include "../frontend/gpu_fwd.h"  // GpuMemQualifier, GpuLaunchConfig forward decls
#include "../../runtime/bridge_runtime.h"
#include <vector>
#include <memory>
#include <string>

namespace corelang::dsl {

// ══════════════════════════════════════════════════════════════════════════════
// 1. GpuMemDSL — gpu:: namespace, host-side bellek ve dispatch
// ══════════════════════════════════════════════════════════════════════════════
// Desteklenen çağrılar:
//   gpu::alloc(size: usize) -> *mut @global u8
//   gpu::alloc_typed<T>(count: usize) -> *mut @global T
//   gpu::free(ptr: *mut @global u8) -> void
//   gpu::copy_h2d(dst: *mut @global u8, src: *const u8, n: usize) -> void
//   gpu::copy_d2h(dst: *mut u8, src: *const @global u8, n: usize) -> void
//   gpu::copy_d2d(dst: *mut @global u8, src: *const @global u8, n: usize) -> void
//   gpu::sync() -> void
//   gpu::sync_all() -> void
//   gpu::device_count() -> i32
//   gpu::set_device(id: i32) -> void
//   gpu::mem_info(free: *mut usize, total: *mut usize) -> void
//   gpu::is_available() -> bool
class GpuMemDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuMemDSL";
        d.namespacePrefix  = "gpu";
        d.effects          = DSLEffect::GPUMemory | DSLEffect::GPUSync |
                             DSLEffect::GPULaunch;
        d.allowedContexts  = DSLContext::Normal | DSLContext::GPUHost |
                             DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "gpu:: memory operations are host-side only; "
            "cannot be called from GPU device kernels (use @shared/@global directly)";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// 2. GpuKernelDSL — kernel fn bildirimi ve launch<<< >>> sözdizimi
// ══════════════════════════════════════════════════════════════════════════════
// Bu DSL iki farklı şeyi yönetir:
//   a) `kernel fn foo(...)` bildirimi: GPUDevice context'te çalışan fonksiyon
//   b) `launch foo<<<grid(...), block(...)>>>(args...)` ifadesi
//
// Bellek niteleyicileri:
//   *const @global T  — VRAM'dan salt okunur
//   *mut @global T    — VRAM'a yazılabilir
//   [@shared T; N]    — Block-local on-chip bellek
//   *const @constant T — Tüm thread'ler için broadcast sabit
//
// Thread indeks sabitleri (builtin, kernel içinde kullanılır):
//   thread.idx.{x,y,z}  — Thread'in blok içi indeksi
//   block.idx.{x,y,z}   — Bloğun grid içi indeksi
//   block.dim.{x,y,z}   — Blok boyutu
//   grid.dim.{x,y,z}    — Grid boyutu
//   warp.size            — Warp boyutu (NVIDIA=32, AMD=64)
class GpuKernelDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuKernelDSL";
        d.namespacePrefix  = "kernel";
        d.effects          = DSLEffect::GPULaunch | DSLEffect::GPUMemory |
                             DSLEffect::GPUSync;
        d.allowedContexts  = DSLContext::GPUHost | DSLContext::Normal;
        d.privilege        = DSLPrivilege::GPU;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "kernel launch requires GPU host context; "
            "kernel fn bodies run in GPUDevice context";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    bool canHandleStmt(const Stmt* s) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
    void lowerStmt(const Stmt* s, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// 3. GpuBlockDSL — block:: senkronizasyon (GPUDevice context only)
// ══════════════════════════════════════════════════════════════════════════════
// Desteklenen çağrılar:
//   block::sync() -> void    — __syncthreads() / work_group_barrier()
//   block::sync_partial(mask: u32) -> void  — NVIDIA Ampere+ için
//
// Derleyici güvencesi:
//   block::sync() sadece kernel fn içinde çağrılabilir.
//   if/else dallanmasının her iki kolunda da çağrılmalı (deadlock analizi).
//   Derleyici, koşullu dallanma + block::sync kombinasyonunu tespit eder.
class GpuBlockDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuBlockDSL";
        d.namespacePrefix  = "block";
        d.effects          = DSLEffect::GPUSync;
        d.allowedContexts  = DSLContext::GPUDevice;
        d.privilege        = DSLPrivilege::GPU;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "block::sync() is only valid inside GPU device kernel functions "
            "(kernel fn); cannot be called from CPU code or GPU host";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// 4. GpuWarpDSL — warp:: shuffle/vote intrinsics (WarpDSL'in tam implementasyonu)
// ══════════════════════════════════════════════════════════════════════════════
// Desteklenen çağrılar:
//   warp::shuffle(val: f32, src_lane: i32) -> f32
//   warp::shuffle_down(val: f32, offset: i32) -> f32
//   warp::shuffle_up(val: f32, offset: i32) -> f32
//   warp::shuffle_xor(val: f32, mask: i32) -> f32
//   warp::all(pred: bool) -> bool
//   warp::any(pred: bool) -> bool
//   warp::ballot(pred: bool) -> u32
//   warp::lane_id() -> i32
//   warp::sync() -> void
//   warp::sync_partial(mask: u32) -> void
//
// Backend mapping:
//   NVIDIA PTX: llvm.nvvm.shfl.sync.down.f32 intrinsic
//   Vulkan SPIR-V: OpGroupNonUniformShuffleDown
//   Her ikisi de __dsl_warp_* → backend-specific runtime çağrısı
class GpuWarpDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuWarpDSL";
        d.namespacePrefix  = "warp";
        d.effects          = DSLEffect::GPUWarp;
        d.allowedContexts  = DSLContext::GPUDevice;
        d.privilege        = DSLPrivilege::GPU;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "warp:: operations are only valid inside GPU device kernel functions; "
            "cannot be called from CPU code";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// 5. GpuAccelDSL — #[gpu_accelerated] + gpu::parallel_for/map
// ══════════════════════════════════════════════════════════════════════════════
// #[gpu_accelerated] attribute'u:
//   - Fonksiyon gövdesini analiz eder (GpuParallelForPass)
//   - gpu::parallel_for / gpu::parallel_map closure'larını kernel'e dönüştürür
//   - Adaptive dispatcher (CPU fallback) ekler
//   - side-effect analizi: sadece PureCompute geçer
//
// Desteklenen çağrılar:
//   gpu::parallel_for(slice: &[T], closure: |T| -> Option<R>) -> Vec<R>
//   gpu::parallel_map(slice: &[T], closure: |T| -> R) -> Vec<R>
//   gpu::parallel_reduce(slice: &[T], init: T, closure: |T,T| -> T) -> T
//
// Closure kısıtlamaları:
//   - Closure sadece capture-by-value kullanabilir
//   - Capture edilen değerler @constant belleğe gönderilir
//   - Global state okuma/yazma yasak (side-effect free)
class GpuAccelDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuAccelDSL";
        d.namespacePrefix  = "gpu_parallel";
        d.effects          = DSLEffect::GPULaunch | DSLEffect::GPUMemory |
                             DSLEffect::GPUSync;
        d.allowedContexts  = DSLContext::Normal | DSLContext::GPUHost |
                             DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "gpu::parallel_for/map requires host context; "
            "use gpu::parallel_* only from CPU-side functions";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// 6. GpuStreamDSL — gpu::stream:: async stream yönetimi
// ══════════════════════════════════════════════════════════════════════════════
// Desteklenen çağrılar:
//   gpu::stream::new() -> GpuStream
//   gpu::stream::destroy(s: GpuStream) -> void
//   gpu::stream::sync(s: GpuStream) -> void
//   gpu::stream::query(s: GpuStream) -> bool   — tamamlandı mı?
//   gpu::alloc_async(size: usize, s: GpuStream) -> *mut @global u8
//   gpu::copy_h2d_async(dst, src, n, s: GpuStream) -> void
//   gpu::copy_d2h_async(dst, src, n, s: GpuStream) -> void
//
// Bridge entegrasyonu:
//   GpuStream = BridgeDomain::GPU_COMPUTE domain queue handle
//   Bridge Scheduler'ın domain queue sistemi üzerine oturur.
//   Race condition analizi: cross-stream bağımlılık derleyici tarafından tespit edilir.
class GpuStreamDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GpuStreamDSL";
        d.namespacePrefix  = "gpu_stream";
        d.effects          = DSLEffect::GPUMemory | DSLEffect::GPULaunch |
                             DSLEffect::GPUSync;
        d.allowedContexts  = DSLContext::Normal | DSLContext::GPUHost |
                             DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::AnyGPU;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "gpu::stream:: operations are host-side only";
        return d;
    }
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* irCtx) override;
};

// ══════════════════════════════════════════════════════════════════════════════
// GPU AST Düğümleri — GpuMemQualifier ve GpuLaunchConfig gpu_fwd.h'da tanımlı
// ══════════════════════════════════════════════════════════════════════════════
// Bu header gpu_fwd.h'ı include ettiğinden (satır 33) bu tipler zaten mevcut.
// dsl:: namespace'i için using alias'lar:
using ::GpuMemQualifier;
using ::GpuLaunchConfig;

// DSLDispatcher'a tüm GPU DSL'lerini kaydet
void registerGpuDSLs(class DSLRegistry& reg);

// Tip-aware warp shuffle yardımcısı — dsl_gpu.cpp'de tanımlı
// GpuWarpDSL::lowerExpr ve irgen_gpu_texture.cpp tarafından kullanılır
llvm::Value* emitWarpShuffleTyped(
    void*              irCtx,
    llvm::Value*       val,
    llvm::Value*       offsetOrLane,
    llvm::Value*       mask,
    llvm::Value*       width,
    const std::string& variant,   // "down" | "up" | "xor" | "idx"
    llvm::Module*      mod);

} // namespace corelang::dsl
