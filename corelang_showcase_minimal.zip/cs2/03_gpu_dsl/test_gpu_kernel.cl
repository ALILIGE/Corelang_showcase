// ======================================================================
// tests/faz2/test_gpu_kernel.cl — kernel fn + launch temel testi
// ======================================================================
// CoreLang GPU DSL smoke test.
// Beklenen davranış:
//   1. @global niteleyicili parametreler doğru adres uzayına map edilir
//   2. thread.idx.x / block.idx.x builtinleri NVVM intrinsic'e çevrilir
//   3. launch<<<grid, block>>> doğru cuLaunchKernel çağrısı üretir
//   4. gpu::alloc / gpu::free / gpu::sync host-side wrapper çağrıları

// ── Kernel fonksiyonu ─────────────────────────────────────────────────────────
kernel fn vector_add(
    a: *const @global f32,
    b: *const @global f32,
    c: *mut @global f32,
    n: i64
) {
    let idx: i32 = block.idx.x * block.dim.x + thread.idx.x;
    if idx < n {
        c[idx] = a[idx] + b[idx];
    }
}

// ── Shared bellek kullanan kernel ─────────────────────────────────────────────
kernel fn reduce_sum(
    input:  *const @global f32,
    output: *mut @global f32,
    n: i64
) {
    let shared_tile: [@shared f32; 256] = @shared [0.0; 256];
    let tid: i32   = thread.idx.x;
    let gid: i32   = block.idx.x * block.dim.x + tid;

    // Global bellekten shared'e yükle
    if gid < n {
        shared_tile[tid] = input[gid];
    } else {
        shared_tile[tid] = 0.0;
    }
    block::sync();

    // Tree reduction
    var stride: i32 = block.dim.x / 2;
    while stride > 0 {
        if tid < stride {
            shared_tile[tid] = shared_tile[tid] + shared_tile[tid + stride];
        }
        block::sync();
        stride = stride / 2;
    }

    if tid == 0 {
        output[block.idx.x] = shared_tile[0];
    }
}

// ── Host (CPU) tarafı ─────────────────────────────────────────────────────────
fn main() -> i32 {
    let n: i64 = 1024;
    let bytes: usize = n * 4;  // f32 = 4 byte

    // GPU bellek tahsisi
    let d_a: *mut @global f32 = gpu::alloc(bytes);
    let d_b: *mut @global f32 = gpu::alloc(bytes);
    let d_c: *mut @global f32 = gpu::alloc(bytes);

    // Host veriyi GPU'ya kopyala (host tarafı — test için)
    // (gerçek testte host_a/host_b doldurulur)
    gpu::copy_h2d(d_a, d_b, bytes);

    // Kernel launch
    let grid_size:  i32 = (n + 255) / 256;
    let block_size: i32 = 256;
    launch vector_add<<<grid(4, 1, 1), block(256, 1, 1)>>>(d_a, d_b, d_c, n);

    // Senkronizasyon
    gpu::sync();

    // Sonucu CPU'ya al
    gpu::copy_d2h(d_c, d_a, bytes);

    // Temizlik
    gpu::free(d_a);
    gpu::free(d_b);
    gpu::free(d_c);
    return 0;
}
