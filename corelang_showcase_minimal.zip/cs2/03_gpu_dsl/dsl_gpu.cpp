// ======================================================================
// dsl_gpu.cpp — GPU DSL Frontend Implementasyonu
// ======================================================================
// GpuMemDSL, GpuKernelDSL, GpuBlockDSL, GpuWarpDSL,
// GpuAccelDSL, GpuStreamDSL lowerExpr implementasyonları.
//
// Adlandırma kuralı (dsl_lowering.cpp ile tutarlı):
//   __dsl_gpu_<method>    — host-side GPU çağrıları
//   __dsl_block_<method>  — GPU device block senkronizasyon
//   __dsl_warp_<method>   — GPU device warp intrinsics
//
// NVIDIA PTX path:
//   warp::shuffle_down → llvm.nvvm.shfl.sync.down.f32 intrinsic
//   block::sync        → llvm.nvvm.barrier0 intrinsic
//
// Vulkan/SPIR-V path:
//   warp::shuffle_down → __dsl_spirv_group_shuffle_down (runtime dispatch)
//   block::sync        → __dsl_spirv_control_barrier (runtime dispatch)
//
// Backend seçimi compile-time: __CORELANG_GPU_BACKEND_CUDA /
//                               __CORELANG_GPU_BACKEND_VULKAN
// Runtime dispatch: cl_gpu_backend() → CL_GPU_CUDA / CL_GPU_VULKAN
// ======================================================================

#include "dsl_gpu.h"
#include "dsl_registry.h"
#include "../frontend/ast.h"
#include "../core/diagnostics.h"
#include "../core/types.h"   // corelang::PtrType, ArrayType — elem_size hesabı için
#include "../irgen/irgen.h"

#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Constants.h>
// NOT: <llvm/IR/IntrinsicsNVPTX.h> KASITLI OLARAK INCLUDE EDİLMİYOR.
//
// KRİTİK TASARIM KARARI (gerçek derleme testleri sonucu alındı):
// llvm::Intrinsic::nvvm_* enum değerleri LLVM_VERSION'a göre değişebilir
// ve bu enum isimlerinin tam doğruluğu, gerçek LLVM header'ı olmadan
// %100 garanti edilemez. Eğer bu kod llvm::Intrinsic::getDeclaration(mod,
// llvm::Intrinsic::nvvm_X) şeklinde enum-tabanlı çağrı yapsaydı VE enum
// adlarından biri o LLVM sürümünde yanlış/değişmiş olsaydı, TÜM DOSYA
// DERLENMEZ ve "runtime fallback" mantığı hiç devreye giremezdi (çünkü
// hata derleme zamanında oluşur, çalışma zamanı if-kontrolünden önce).
//
// Bunun yerine NVPTX intrinsic'leri DOĞRUDAN LLVM IR SEMBOL İSİMLERİYLE
// (örn. "llvm.nvvm.barrier0", "llvm.nvvm.shfl.sync.down.f32") declare
// edilir — bu isimler LLVM IR Language Reference'ın bir parçasıdır ve
// enum'dan TAMAMEN BAĞIMSIZDIR. Bu yaklaşım LLVM'in intrinsic sistemi
// için tasarım gereği DESTEKLENEN bir kullanım şeklidir (declare edilen
// her "llvm.*" isimli fonksiyon, LLVM backend'i tarafından otomatik
// olarak intrinsic olarak tanınır — IntrinsicsNVPTX.h sadece enum
// SABİTLERİ sağlar, intrinsic'in KENDİSİNİ değil).
//
// Sonuç: enum ismi yanlış olma riski TAMAMEN ORTADAN KALKAR. İsim
// string'inde bir yazım hatası olsa bile, bu sadece çalışma zamanında
// "tanınmayan intrinsic" hatasına yol açar (LLVM verifier yakalar),
// derleme zamanında DEĞİL — ve zaten kodun NVVM-bulamazsa Vulkan
// fallback'ine düşme mantığı buna göre tasarlanmıştır.

using namespace corelang;
using namespace corelang::dsl;
using namespace corelang::irgen;

// ── Yardımcı: irCtx (void*) → IRBuilder + mod ───────────────────────────────
static llvm::IRBuilder<>* bldFromCtx(void* irCtx) {
    auto* ic = static_cast<IRContext*>(irCtx);
    return static_cast<llvm::IRBuilder<>*>(ic->bld);
}
static llvm::Module* modFromCtx(void* irCtx) {
    return bldFromCtx(irCtx)->GetInsertBlock()->getModule();
}
static IRContext::LowerExprFn getLowerCb(void* irCtx) {
    return static_cast<IRContext*>(irCtx)->lowerExprCallback;
}
static void* getLowerSelf(void* irCtx) {
    return static_cast<IRContext*>(irCtx)->lowerExprSelf;
}

// ── Yardımcı tipler ──────────────────────────────────────────────────────────
static llvm::Type* i32Ty(llvm::Module* m) { return llvm::Type::getInt32Ty(m->getContext()); }
static llvm::Type* i64Ty(llvm::Module* m) { return llvm::Type::getInt64Ty(m->getContext()); }
static llvm::Type* f32Ty(llvm::Module* m) { return llvm::Type::getFloatTy(m->getContext()); }
static llvm::Type* voidTy(llvm::Module* m) { return llvm::Type::getVoidTy(m->getContext()); }
static llvm::Type* ptrTy(llvm::Module* m) { return llvm::PointerType::getUnqual(m->getContext()); }
static llvm::Type* boolTy(llvm::Module* m) { return llvm::Type::getInt1Ty(m->getContext()); }

// ── Yardımcı: External fonksiyon declare et ve çağır ────────────────────────
static llvm::Value* emitExternCall(
    void* irCtx,
    llvm::Module* mod,
    const std::string& fnName,
    llvm::Type* retType,
    const std::vector<llvm::Value*>& args,
    bool readNone = false,
    bool noThrow = true)
{
    auto* b   = bldFromCtx(irCtx);
    auto& ctx = mod->getContext();
    if (!retType) retType = i32Ty(mod);

    std::vector<llvm::Type*> argTys;
    for (auto* a : args) argTys.push_back(a->getType());

    auto* fnTy = llvm::FunctionType::get(retType, argTys, false);
    auto* callee = mod->getOrInsertFunction(fnName, fnTy).getCallee();
    auto* fn = llvm::cast<llvm::Function>(callee);
    if (readNone) fn->setDoesNotAccessMemory();
    if (noThrow)  fn->setDoesNotThrow();

    if (retType->isVoidTy()) {
        b->CreateCall(fn, args);
        return nullptr;
    }
    return b->CreateCall(fn, args, fnName + ".ret");
}

// ── Yardımcı: CallExpr argümanlarını evaluate et ────────────────────────────
static std::vector<llvm::Value*> evalArgs(
    const CallExpr* call,
    void* irCtx,
    llvm::Module* mod,
    llvm::Type* defaultArgTy = nullptr)
{
    auto& ctx = mod->getContext();
    if (!defaultArgTy) defaultArgTy = i32Ty(mod);
    auto lowerCb   = getLowerCb(irCtx);
    auto lowerSelf = getLowerSelf(irCtx);

    std::vector<llvm::Value*> vals;
    for (auto& argExpr : call->args) {
        llvm::Value* v = nullptr;
        if (lowerCb && lowerSelf)
            v = lowerCb(lowerSelf, argExpr.get());
        if (!v)
            v = llvm::ConstantInt::get(defaultArgTy, 0);
        vals.push_back(v);
    }
    return vals;
}

// ── Yardımcı: DSL çağrı parçalarını ayrıştır ────────────────────────────────
struct DSLCallParts {
    std::string ns;
    std::string method;
    bool valid = false;
};
static DSLCallParts parseDSLCall(const Expr* e) {
    if (!e || e->kind != Expr::Kind::Call) return {};
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee || call->callee->kind != Expr::Kind::Field) return {};
    auto* field = static_cast<const FieldExpr*>(call->callee.get());
    if (!field->base || field->base->kind != Expr::Kind::Ident) return {};
    auto* id = static_cast<const IdentExpr*>(field->base.get());
    return { id->name, field->field, true };
}

// ── Yardımcı: isCallTo ───────────────────────────────────────────────────────
static bool isCallTo(const Expr* e, const std::string& ns) {
    auto p = parseDSLCall(e);
    return p.valid && p.ns == ns;
}

// ── Yardımcı: NVVM intrinsic emit (STRING-TABANLI, enum'a bağımlı DEĞİL) ────
// llvmIntrinsicName: LLVM IR'daki tam sembol ismi, örn. "llvm.nvvm.barrier0"
//                     veya "llvm.nvvm.shfl.sync.down.f32"
// Bu isimler declare edildiğinde LLVM backend'i onları otomatik olarak
// intrinsic olarak tanır (isim "llvm." ile başladığından) — enum ID'sine
// hiç ihtiyaç yoktur. Bkz. dosya başındaki tasarım notu.
static llvm::Value* emitNvvmIntrinsicByName(
    void* irCtx,
    llvm::Module* mod,
    const std::string& llvmIntrinsicName,
    llvm::Type* retTy,
    const std::vector<llvm::Value*>& args,
    const std::string& fallbackName)
{
    auto* b = bldFromCtx(irCtx);
    bool isCuda = mod->getTargetTriple().find("nvptx") != std::string::npos;

    if (isCuda) {
        // Intrinsic'i isim+tip imzasıyla declare et. LLVM, "llvm." ile
        // başlayan fonksiyon isimlerini otomatik intrinsic olarak tanır.
        std::vector<llvm::Type*> argTys;
        for (auto* a : args) argTys.push_back(a->getType());
        auto* fnTy = llvm::FunctionType::get(retTy, argTys, false);
        auto* fn = llvm::cast<llvm::Function>(
            mod->getOrInsertFunction(llvmIntrinsicName, fnTy).getCallee());
        fn->setDoesNotThrow();
        if (retTy->isVoidTy()) {
            b->CreateCall(fn, args);
            return nullptr;
        }
        return b->CreateCall(fn, args, "nvvm.ret");
    }
    // Vulkan veya non-CUDA hedef: runtime fallback çağrısı
    return emitExternCall(irCtx, mod, fallbackName, retTy, args);
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuMemDSL — gpu:: namespace host-side
// ══════════════════════════════════════════════════════════════════════════════

bool GpuMemDSL::canHandle(const Expr* e) const {
    auto p = parseDSLCall(e);
    if (!p.valid || p.ns != "gpu") return false;
    // stream:: alt-namespace GpuStreamDSL'e ait
    if (p.method == "stream") return false;
    // parallel_for/map GpuAccelDSL'e ait
    if (p.method == "parallel_for" || p.method == "parallel_map" ||
        p.method == "parallel_reduce") return false;
    return true;
}

llvm::Value* GpuMemDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;

    auto* call = static_cast<const CallExpr*>(e);
    auto* mod  = modFromCtx(irCtx);
    auto args  = evalArgs(call, irCtx, mod, ptrTy(mod));
    const auto& m = parts.method;

    // ── gpu::alloc(size: usize) -> *mut u8 ──────────────────────────────────
    if (m == "alloc") {
        std::vector<llvm::Value*> a = evalArgs(call, irCtx, mod, i64Ty(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_alloc", ptrTy(mod), a);
    }
    // ── gpu::free(ptr) ────────────────────────────────────────────────────────
    if (m == "free") {
        std::vector<llvm::Value*> a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_free", voidTy(mod), a);
    }
    // ── gpu::copy_h2d(dst, src, n) ───────────────────────────────────────────
    if (m == "copy_h2d") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_copy_h2d", voidTy(mod), a);
    }
    // ── gpu::copy_d2h(dst, src, n) ───────────────────────────────────────────
    if (m == "copy_d2h") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_copy_d2h", voidTy(mod), a);
    }
    // ── gpu::copy_d2d(dst, src, n) ───────────────────────────────────────────
    if (m == "copy_d2d") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_copy_d2d", voidTy(mod), a);
    }
    // ── gpu::sync() ──────────────────────────────────────────────────────────
    if (m == "sync") {
        return emitExternCall(irCtx, mod, "__cl_gpu_sync", voidTy(mod), {});
    }
    // ── gpu::sync_all() ──────────────────────────────────────────────────────
    if (m == "sync_all") {
        return emitExternCall(irCtx, mod, "__cl_gpu_sync_all", voidTy(mod), {});
    }
    // ── gpu::device_count() -> i32 ───────────────────────────────────────────
    if (m == "device_count") {
        // DÜZELTME: gerçek runtime sembolü "cl_gpu_device_count" (çift alt
        // çizgisiz) — host-query fonksiyonları __cl_gpu_ önekini KULLANMAZ,
        // sadece bellek/launch/stream operasyonları kullanır (gpu_runtime.h'a
        // bakın: cl_gpu_device_count, cl_gpu_is_available, cl_gpu_set_device
        // hepsi tek alt çizgili). Önceki versiyon yanlışlıkla çift alt çizgi
        // emit ediyordu — bu çalışma zamanında "undefined symbol" hatası
        // verirdi (link başarılı olur çünkü extern fonksiyon decl'i derleyici
        // tarafından kabul edilir, ama runtime'da sembol bulunamaz).
        return emitExternCall(irCtx, mod, "cl_gpu_device_count", i32Ty(mod), {});
    }
    // ── gpu::set_device(id: i32) ─────────────────────────────────────────────
    if (m == "set_device") {
        auto a = evalArgs(call, irCtx, mod, i32Ty(mod));
        // DÜZELTME: gerçek sembol "cl_gpu_set_device" (tek alt çizgili) VE
        // dönüş tipi i32 (int), void değil — dispatch.c'de
        // "int cl_gpu_set_device(int id)" olarak tanımlı.
        return emitExternCall(irCtx, mod, "cl_gpu_set_device", i32Ty(mod), a);
    }
    // ── gpu::is_available() -> bool ──────────────────────────────────────────
    if (m == "is_available") {
        // DÜZELTME: gerçek sembol "cl_gpu_is_available" (tek alt çizgili).
        return emitExternCall(irCtx, mod, "cl_gpu_is_available", boolTy(mod), {});
    }
    // ── gpu::mem_info(free_out, total_out) ───────────────────────────────────
    if (m == "mem_info") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_mem_info", voidTy(mod), a);
    }
    // ── gpu::alloc_async(size, stream) ───────────────────────────────────────
    if (m == "alloc_async") {
        auto a = evalArgs(call, irCtx, mod, i64Ty(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_alloc_async", ptrTy(mod), a);
    }
    // ── gpu::copy_h2d_async / copy_d2h_async ─────────────────────────────────
    if (m == "copy_h2d_async") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_copy_h2d_async", voidTy(mod), a);
    }
    if (m == "copy_d2h_async") {
        auto a = evalArgs(call, irCtx, mod, ptrTy(mod));
        return emitExternCall(irCtx, mod, "__cl_gpu_copy_d2h_async", voidTy(mod), a);
    }

    Diagnostics::get().error("<source>", 0, 0,
        "unknown gpu:: method '" + m + "'");
    return nullptr;
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuKernelDSL — kernel launch ifadesi lowering
// ══════════════════════════════════════════════════════════════════════════════

bool GpuKernelDSL::canHandle(const Expr* e) const {
    // launch ifadesi CallExpr olarak temsil edilir: launch_kernel(name, grid, block, args...)
    if (!e || e->kind != Expr::Kind::Call) return false;
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee || call->callee->kind != Expr::Kind::Ident) return false;
    auto* id = static_cast<const IdentExpr*>(call->callee.get());
    return id->name == "__gpu_launch";
}

bool GpuKernelDSL::canHandleStmt(const Stmt* s) const {
    if (!s) return false;
    return s->kind == kStmtLaunch;
}

llvm::Value* GpuKernelDSL::lowerExpr(const Expr* e, void* irCtx) {
    // __gpu_launch(kernel_name_ptr, gridX, gridY, gridZ, blockX, blockY, blockZ,
    //              shared_mem, stream_ptr, argc, argv_ptr)
    auto* call = static_cast<const CallExpr*>(e);
    auto* mod  = modFromCtx(irCtx);
    auto args  = evalArgs(call, irCtx, mod, ptrTy(mod));
    return emitExternCall(irCtx, mod, "__cl_gpu_kernel_launch", i32Ty(mod), args);
}

void GpuKernelDSL::lowerStmt(const Stmt* s, void* irCtx) {
    if (s->kind != kStmtLaunch) return;
    auto* ls  = static_cast<const LaunchStmt*>(s);
    auto* mod = modFromCtx(irCtx);
    auto* b   = bldFromCtx(irCtx);
    auto& ctx = mod->getContext();

    auto lowerCb   = getLowerCb(irCtx);
    auto lowerSelf = getLowerSelf(irCtx);

    // Kernel adını global string olarak emit et
    auto* kernelNameStr = llvm::ConstantDataArray::getString(ctx, ls->kernelName, true);
    auto* nameGV = new llvm::GlobalVariable(
        *mod, kernelNameStr->getType(), true,
        llvm::GlobalValue::PrivateLinkage, kernelNameStr,
        "__gpu_kernel_name_" + ls->kernelName);
    nameGV->setUnnamedAddr(llvm::GlobalValue::UnnamedAddr::Global);
    llvm::Value* namePtr = nameGV;

    // Grid/Block boyutlarını emit et
    auto mkI32 = [&](uint32_t v) -> llvm::Value* {
        return llvm::ConstantInt::get(i32Ty(mod), v);
    };
    auto mkI64 = [&](uint64_t v) -> llvm::Value* {
        return llvm::ConstantInt::get(i64Ty(mod), v);
    };

    // Her eksen bağımsız olarak statik ya da dinamik olabilir
    // (örn. grid(n/16, 4, 1) → x dinamik, y/z statik).
    // ls->gridExprX/Y/Z, parser_gpu.cpp::parseLaunchAxisList tarafından
    // yalnızca o eksen literal DEĞİLSE doldurulur; nullptr ise statik
    // ls->config.gridX/Y/Z değeri kullanılır.
    auto resolveAxis = [&](std::unique_ptr<Expr>& expr, uint32_t staticVal) -> llvm::Value* {
        if (expr && lowerCb && lowerSelf) {
            llvm::Value* v = lowerCb(lowerSelf, expr.get());
            if (v) return bldFromCtx(irCtx)->CreateZExtOrTrunc(v, i32Ty(mod), "axis.dyn");
        }
        return mkI32(staticVal);
    };

    llvm::Value* gridX  = resolveAxis(ls->gridExprX,  ls->config.gridX);
    llvm::Value* gridY  = resolveAxis(ls->gridExprY,  ls->config.gridY);
    llvm::Value* gridZ  = resolveAxis(ls->gridExprZ,  ls->config.gridZ);
    llvm::Value* blockX = resolveAxis(ls->blockExprX, ls->config.blockX);
    llvm::Value* blockY = resolveAxis(ls->blockExprY, ls->config.blockY);
    llvm::Value* blockZ = resolveAxis(ls->blockExprZ, ls->config.blockZ);

    // Shared memory boyutu
    llvm::Value* sharedMem = mkI32(ls->config.dynamicSharedMem);

    // Stream pointer (null = default stream)
    llvm::Value* streamPtr = llvm::ConstantPointerNull::get(
        llvm::PointerType::getUnqual(ctx));
    if (!ls->config.streamName.empty()) {
        // Stream değişkenine referans — IRContext vars'tan al
        auto* ic = static_cast<IRContext*>(irCtx);
        auto it = ic->vars.find(ls->config.streamName);
        if (it != ic->vars.end()) streamPtr = it->second;
    }

    // Kernel argümanlarını void* dizisine pack et
    // Her argüman alloca'ya kopyalanır, adres argv[] array'ine yazılır
    llvm::Value* argc = mkI32((uint32_t)ls->args.size());

    llvm::Value* argvArr = nullptr;
    if (!ls->args.empty()) {
        auto* arrTy = llvm::ArrayType::get(ptrTy(mod), ls->args.size());
        argvArr = b->CreateAlloca(arrTy, nullptr, "kernel_argv");
        for (size_t i = 0; i < ls->args.size(); i++) {
            llvm::Value* argVal = nullptr;
            if (lowerCb && lowerSelf)
                argVal = lowerCb(lowerSelf, ls->args[i].get());
            if (!argVal)
                argVal = llvm::ConstantInt::get(i32Ty(mod), 0);
            // Argümanı alloca'ya kopyala, adresi argv'ye yaz
            auto* argAlloca = b->CreateAlloca(argVal->getType(), nullptr,
                                               "karg_" + std::to_string(i));
            b->CreateStore(argVal, argAlloca);
            auto* slot = b->CreateGEP(arrTy, argvArr,
                { llvm::ConstantInt::get(i32Ty(mod), 0),
                  llvm::ConstantInt::get(i32Ty(mod), (uint32_t)i) });
            b->CreateStore(argAlloca, slot);
        }
    } else {
        argvArr = llvm::ConstantPointerNull::get(llvm::PointerType::getUnqual(ctx));
    }

    // __cl_gpu_kernel_launch(name, gx, gy, gz, bx, by, bz, smem, stream, argc, argv)
    std::vector<llvm::Value*> launchArgs = {
        namePtr, gridX, gridY, gridZ, blockX, blockY, blockZ,
        sharedMem, streamPtr, argc, argvArr
    };

    // Fonksiyon tipi
    std::vector<llvm::Type*> paramTys = {
        ptrTy(mod), i32Ty(mod), i32Ty(mod), i32Ty(mod),
        i32Ty(mod), i32Ty(mod), i32Ty(mod),
        i32Ty(mod), ptrTy(mod), i32Ty(mod), ptrTy(mod)
    };
    auto* launchTy = llvm::FunctionType::get(i32Ty(mod), paramTys, false);
    auto* launchFn = llvm::cast<llvm::Function>(
        mod->getOrInsertFunction("__cl_gpu_kernel_launch", launchTy).getCallee());
    launchFn->setDoesNotThrow();
    b->CreateCall(launchFn, launchArgs);
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuBlockDSL — block:: senkronizasyon
// ══════════════════════════════════════════════════════════════════════════════

bool GpuBlockDSL::canHandle(const Expr* e) const {
    return isCallTo(e, "block");
}

llvm::Value* GpuBlockDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;
    auto* call = static_cast<const CallExpr*>(e);
    auto* mod  = modFromCtx(irCtx);
    const auto& m = parts.method;

    // block::sync() → llvm.nvvm.barrier0 (CUDA) veya __dsl_spirv_control_barrier (Vulkan)
    if (m == "sync") {
        // "llvm.nvvm.barrier0" — LLVM IR'da NVPTX __syncthreads() karşılığı.
        // Bu isim enum'a bağımlı DEĞİL (bkz. dosya başı tasarım notu).
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.barrier0",
                                        voidTy(mod), {}, "__dsl_block_sync");
    }
    // block::sync_partial(mask: u32)
    if (m == "sync_partial") {
        auto a = evalArgs(call, irCtx, mod, i32Ty(mod));
        return emitExternCall(irCtx, mod, "__dsl_block_sync_partial", voidTy(mod), a);
    }

    Diagnostics::get().error("<source>", 0, 0,
        "unknown block:: method '" + m + "'");
    return nullptr;
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuWarpDSL — warp:: shuffle/vote (WarpDSL'in yerini alan tam impl)
// ══════════════════════════════════════════════════════════════════════════════

bool GpuWarpDSL::canHandle(const Expr* e) const {
    return isCallTo(e, "warp");
}

llvm::Value* GpuWarpDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;
    auto* call = static_cast<const CallExpr*>(e);
    auto* mod  = modFromCtx(irCtx);
    auto* b    = bldFromCtx(irCtx);
    const auto& m = parts.method;

    // warp::shuffle_down(val: f32, offset: i32) -> f32
    // CUDA: llvm.nvvm.shfl.sync.down.f32
    // Vulkan: OpGroupNonUniformShuffleDown → __dsl_spirv_shuffle_down_f32
    if (m == "shuffle_down") {
        auto rawArgs = evalArgs(call, irCtx, mod, f32Ty(mod));
        llvm::Value* val    = rawArgs.size() > 0 ? rawArgs[0]
                              : llvm::ConstantFP::get(f32Ty(mod), 0.0);
        llvm::Value* offset = rawArgs.size() > 1 ? rawArgs[1]
                              : llvm::ConstantInt::get(i32Ty(mod), 1);
        llvm::Value* mask   = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        llvm::Value* width  = llvm::ConstantInt::get(i32Ty(mod), 31); // warp=32
        // "llvm.nvvm.shfl.sync.down.f32" — LLVM IR Language Reference'taki
        // tam sembol ismi. mask/val/offset/width imza sırası NVVM ISA
        // semantiğiyle eşleşir.
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.shfl.sync.down.f32",
            f32Ty(mod), { mask, val, offset, width }, "__dsl_warp_shuffle_down");
    }

    // warp::shuffle_up(val: f32, offset: i32) -> f32
    if (m == "shuffle_up") {
        auto rawArgs = evalArgs(call, irCtx, mod, f32Ty(mod));
        llvm::Value* val    = rawArgs.size() > 0 ? rawArgs[0]
                              : llvm::ConstantFP::get(f32Ty(mod), 0.0);
        llvm::Value* offset = rawArgs.size() > 1 ? rawArgs[1]
                              : llvm::ConstantInt::get(i32Ty(mod), 1);
        llvm::Value* mask   = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        llvm::Value* width  = llvm::ConstantInt::get(i32Ty(mod), 31);
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.shfl.sync.up.f32",
            f32Ty(mod), { mask, val, offset, width }, "__dsl_warp_shuffle_up");
    }

    // warp::shuffle_xor(val: f32, mask: i32) -> f32
    if (m == "shuffle_xor") {
        auto rawArgs = evalArgs(call, irCtx, mod, f32Ty(mod));
        llvm::Value* val  = rawArgs.size() > 0 ? rawArgs[0]
                            : llvm::ConstantFP::get(f32Ty(mod), 0.0);
        llvm::Value* xorM = rawArgs.size() > 1 ? rawArgs[1]
                            : llvm::ConstantInt::get(i32Ty(mod), 1);
        llvm::Value* mask  = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        llvm::Value* width = llvm::ConstantInt::get(i32Ty(mod), 31);
        // "bfly" (butterfly) = XOR shuffle varyantının NVPTX ISA'daki adı
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.shfl.sync.bfly.f32",
            f32Ty(mod), { mask, val, xorM, width }, "__dsl_warp_shuffle_xor");
    }

    // warp::shuffle(val: f32, src_lane: i32) -> f32
    if (m == "shuffle") {
        auto rawArgs = evalArgs(call, irCtx, mod, f32Ty(mod));
        llvm::Value* val  = rawArgs.size() > 0 ? rawArgs[0]
                            : llvm::ConstantFP::get(f32Ty(mod), 0.0);
        llvm::Value* lane = rawArgs.size() > 1 ? rawArgs[1]
                            : llvm::ConstantInt::get(i32Ty(mod), 0);
        llvm::Value* mask  = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        llvm::Value* width = llvm::ConstantInt::get(i32Ty(mod), 31);
        // "idx" = doğrudan lane indeksleme varyantı
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.shfl.sync.idx.f32",
            f32Ty(mod), { mask, val, lane, width }, "__dsl_warp_shuffle");
    }

    // warp::all(pred: bool) -> bool
    if (m == "all") {
        auto rawArgs = evalArgs(call, irCtx, mod, boolTy(mod));
        llvm::Value* pred = rawArgs.size() > 0 ? rawArgs[0]
                            : llvm::ConstantInt::get(boolTy(mod), 0);
        bool isCuda = mod->getTargetTriple().find("nvptx") != std::string::npos;
        if (isCuda) {
            // "llvm.nvvm.vote.all.sync" — dönüş tipi i1 (NVPTX ISA'da
            // vote.all.sync.pred her zaman tek bitlik predikat döner;
            // i32'ye genişletip sonra trunc etmek GEREKSİZ ve YANLIŞTI
            // — önceki versiyon bu hatayı içeriyordu).
            llvm::Value* mask = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
            return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.vote.all.sync",
                boolTy(mod), { mask, pred }, "__dsl_warp_vote_all_i1_unused");
        }
        // Vulkan fallback: runtime i32 döner (0/1), bool'a daralt
        llvm::Value* predI32 = b->CreateZExt(pred, i32Ty(mod));
        llvm::Value* res = emitExternCall(irCtx, mod, "__dsl_warp_vote_all",
                                          i32Ty(mod), { predI32 });
        return b->CreateTrunc(res, boolTy(mod));
    }

    // warp::any(pred: bool) -> bool
    if (m == "any") {
        auto rawArgs = evalArgs(call, irCtx, mod, boolTy(mod));
        llvm::Value* pred = rawArgs.size() > 0 ? rawArgs[0]
                            : llvm::ConstantInt::get(boolTy(mod), 0);
        bool isCuda = mod->getTargetTriple().find("nvptx") != std::string::npos;
        if (isCuda) {
            llvm::Value* mask = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
            return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.vote.any.sync",
                boolTy(mod), { mask, pred }, "__dsl_warp_vote_any_i1_unused");
        }
        llvm::Value* predI32 = b->CreateZExt(pred, i32Ty(mod));
        llvm::Value* res = emitExternCall(irCtx, mod, "__dsl_warp_vote_any",
                                          i32Ty(mod), { predI32 });
        return b->CreateTrunc(res, boolTy(mod));
    }

    // warp::ballot(pred: bool) -> u32
    if (m == "ballot") {
        auto rawArgs = evalArgs(call, irCtx, mod, boolTy(mod));
        llvm::Value* pred = rawArgs.size() > 0 ? rawArgs[0]
                            : llvm::ConstantInt::get(boolTy(mod), 0);
        bool isCuda = mod->getTargetTriple().find("nvptx") != std::string::npos;
        if (isCuda) {
            // "llvm.nvvm.vote.ballot.sync" — dönüş i32 (32-bit bitmask,
            // bu doğru — ballot her lane için 1 bit taşıyan gerçek bir
            // integer döndürür, vote.all/any'nin aksine).
            llvm::Value* mask = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
            return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.vote.ballot.sync",
                i32Ty(mod), { mask, pred }, "__dsl_warp_ballot_unused");
        }
        llvm::Value* predI32 = b->CreateZExt(pred, i32Ty(mod));
        return emitExternCall(irCtx, mod, "__dsl_warp_ballot",
                              i32Ty(mod), { predI32 });
    }

    // warp::lane_id() -> i32
    if (m == "lane_id") {
        // "llvm.nvvm.read.ptx.sreg.laneid" — sabit/özel kayıt okuma,
        // argüman almaz.
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.read.ptx.sreg.laneid",
            i32Ty(mod), {}, "__dsl_warp_lane_id");
    }

    // warp::sync() → full warp sync (mask = 0xFFFFFFFF)
    if (m == "sync") {
        llvm::Value* mask = llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.bar.warp.sync",
            voidTy(mod), { mask }, "__dsl_warp_sync");
    }

    // warp::sync_partial(mask: u32)
    if (m == "sync_partial") {
        auto a = evalArgs(call, irCtx, mod, i32Ty(mod));
        llvm::Value* maskArg = !a.empty() ? a[0]
                              : llvm::ConstantInt::get(i32Ty(mod), 0xFFFFFFFF);
        return emitNvvmIntrinsicByName(irCtx, mod, "llvm.nvvm.bar.warp.sync",
            voidTy(mod), { maskArg }, "__dsl_warp_sync_partial");
    }

    Diagnostics::get().error("<source>", 0, 0,
        "unknown warp:: method '" + m + "'");
    return nullptr;
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuAccelDSL — gpu::parallel_for / parallel_map / parallel_reduce
// ══════════════════════════════════════════════════════════════════════════════

bool GpuAccelDSL::canHandle(const Expr* e) const {
    auto p = parseDSLCall(e);
    if (!p.valid || p.ns != "gpu") return false;
    return p.method == "parallel_for" ||
           p.method == "parallel_map" ||
           p.method == "parallel_reduce";
}

llvm::Value* GpuAccelDSL::lowerExpr(const Expr* e, void* irCtx) {
    auto parts = parseDSLCall(e);
    if (!parts.valid) return nullptr;
    auto* call = static_cast<const CallExpr*>(e);
    auto* mod  = modFromCtx(irCtx);
    const auto& m = parts.method;

    // gpu::parallel_for, gpu::parallel_map, gpu::parallel_reduce
    // Bu çağrılar GpuParallelForPass tarafından kernel'e dönüştürülür.
    // Eğer pass çalışmadıysa (veya iş yükü küçükse), adaptive dispatcher
    // CPU fallback'i seçer.
    //
    // Emit: __cl_gpu_dispatch_adaptive(cpu_fn, gpu_fn, data_ptr, count, elem_size)
    // Pass, gpu_fn'i ayrı bir kernel fn olarak emit eder ve buraya pointer geçirir.
    // cpu_fn = orijinal CPU closure pointer

    // Argümanlar: (data_slice_ptr, count, cpu_fn_ptr, gpu_fn_ptr)
    // GpuParallelForPass bu argümanları doldurur; burada sadece çerçeveyi kuruyoruz.
    auto rawArgs = evalArgs(call, irCtx, mod, ptrTy(mod));

    std::vector<llvm::Value*> dispatchArgs;
    // data_ptr
    dispatchArgs.push_back(rawArgs.size() > 0 ? rawArgs[0]
                           : llvm::ConstantPointerNull::get(llvm::PointerType::getUnqual(mod->getContext())));
    // count (eleman sayısı) — ikinci argüman &[T]'nin uzunluğu
    auto* bld2 = bldFromCtx(irCtx);
    llvm::Value* countVal = llvm::ConstantInt::get(i64Ty(mod), 0);
    if (rawArgs.size() > 1 && rawArgs[1]) {
        // Eğer i64/i32 ise doğrudan kullan; pointer ise ptrToInt
        if (rawArgs[1]->getType()->isIntegerTy()) {
            countVal = bld2->CreateZExtOrTrunc(rawArgs[1], i64Ty(mod), "elem.count");
        } else if (rawArgs[1]->getType()->isPointerTy()) {
            countVal = bld2->CreatePtrToInt(rawArgs[1], i64Ty(mod), "elem.count");
        }
    }
    dispatchArgs.push_back(countVal);

    // elem_size: CallExpr'ın ilk argümanının AST seviyesindeki resolvedType'ından
    // GERÇEK boyutu hesapla. Opaque pointer'lardan (LLVM Value*) eleman boyutu
    // çıkarılamaz (LLVM 17 temel kısıtlaması — bu bir tasarım stub'ı değil,
    // opaque pointer modelinin doğası) — bu yüzden kaynak AST'taki tip bilgisi
    // (TypeChecker tarafından zaten doldurulmuş corelang::Type*) kullanılır.
    //
    // call->args[0] → &[T] (slice) veya *const T (raw pointer) → T->sizeOf()
    llvm::Value* elemSizeVal = nullptr;
    if (!call->args.empty() && call->args[0]->resolvedType) {
        const corelang::Type* argType = call->args[0]->resolvedType;

        // PtrType veya slice/array sarmalayıcısından iç tipi çöz
        size_t resolvedSize = 0;
        if (auto* pt = dynamic_cast<const corelang::PtrType*>(argType)) {
            resolvedSize = pt->inner()->sizeOf();
        } else if (auto* at = dynamic_cast<const corelang::ArrayType*>(argType)) {
            resolvedSize = at->elemType()->sizeOf();
        } else {
            // Slice/diğer sarmalayıcı tipler için doğrudan sizeOf() iç elemanı
            // temsil ediyor olabilir (projenin SliceType'ı varsa oraya da
            // dynamic_cast eklenebilir — bkz. Merge Guide Adım 24).
            resolvedSize = argType->sizeOf();
        }
        if (resolvedSize > 0 && resolvedSize < 4096) { // sanity bound
            elemSizeVal = llvm::ConstantInt::get(i64Ty(mod), resolvedSize);
        }
    }
    if (!elemSizeVal) {
        // resolvedType yoksa (type checker bu ifadeyi işlememiş/hata durumu) —
        // derleme zamanı uyarısı ver ve f32 (4 byte) güvenli varsayılana düş.
        // Bu durum normal akışta OLUŞMAMALI; type checker her zaman
        // resolvedType'ı doldurmuş olmalı. Oluşuyorsa type checker'da
        // gpu::parallel_for/map/reduce için tip çıkarımı eksik demektir.
        Diagnostics::get().error("<source>", 0, 0,
            "gpu::" + m + "(): could not resolve element type/size from "
            "AST (resolvedType is null) — type checker must run before "
            "GPU DSL lowering; falling back to 4-byte (f32) assumption, "
            "this WILL produce incorrect results for non-f32 element types");
        elemSizeVal = llvm::ConstantInt::get(i64Ty(mod), 4);
    }
    dispatchArgs.push_back(elemSizeVal);
    // kernel_tag: hangi kernel → string constant
    auto* tagStr = llvm::ConstantDataArray::getString(mod->getContext(),
                       "__cl_" + m, true);
    auto* tagGV  = new llvm::GlobalVariable(*mod, tagStr->getType(), true,
                       llvm::GlobalValue::PrivateLinkage, tagStr, ".gpu_tag");
    dispatchArgs.push_back(tagGV);

    return emitExternCall(irCtx, mod,
        "__cl_gpu_dispatch_adaptive",
        ptrTy(mod),
        dispatchArgs,
        /*readNone=*/false, /*noThrow=*/true);
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuStreamDSL — gpu::stream:: async stream API
// ══════════════════════════════════════════════════════════════════════════════

bool GpuStreamDSL::canHandle(const Expr* e) const {
    if (!e || e->kind != Expr::Kind::Call) return false;
    auto* call = static_cast<const CallExpr*>(e);
    if (!call->callee || call->callee->kind != Expr::Kind::Field) return false;
    auto* outer = static_cast<const FieldExpr*>(call->callee.get());
    // gpu::stream::method → FieldExpr { base: FieldExpr{ base:"gpu", field:"stream" }, field:"method" }
    if (!outer->base || outer->base->kind != Expr::Kind::Field) return false;
    auto* inner = static_cast<const FieldExpr*>(outer->base.get());
    if (!inner->base || inner->base->kind != Expr::Kind::Ident) return false;
    auto* id = static_cast<const IdentExpr*>(inner->base.get());
    return id->name == "gpu" && inner->field == "stream";
}

llvm::Value* GpuStreamDSL::lowerExpr(const Expr* e, void* irCtx) {
    if (!e || e->kind != Expr::Kind::Call) return nullptr;
    auto* call    = static_cast<const CallExpr*>(e);
    auto* outer   = static_cast<const FieldExpr*>(call->callee.get());
    const std::string& method = outer->field;
    auto* mod  = modFromCtx(irCtx);
    auto  args = evalArgs(call, irCtx, mod, ptrTy(mod));

    // gpu::stream::new() -> GpuStream (opaque ptr)
    if (method == "new") {
        return emitExternCall(irCtx, mod, "__cl_gpu_stream_new", ptrTy(mod), {});
    }
    // gpu::stream::destroy(s)
    if (method == "destroy") {
        return emitExternCall(irCtx, mod, "__cl_gpu_stream_destroy", voidTy(mod), args);
    }
    // gpu::stream::sync(s)
    if (method == "sync") {
        return emitExternCall(irCtx, mod, "__cl_gpu_stream_sync", voidTy(mod), args);
    }
    // gpu::stream::query(s) -> bool
    if (method == "query") {
        return emitExternCall(irCtx, mod, "__cl_gpu_stream_query", boolTy(mod), args);
    }

    Diagnostics::get().error("<source>", 0, 0,
        "unknown gpu::stream:: method '" + method + "'");
    return nullptr;
}

// ══════════════════════════════════════════════════════════════════════════════
// registerGpuDSLs — DSLDispatcher constructor'ından çağrılır
// ══════════════════════════════════════════════════════════════════════════════

void corelang::dsl::registerGpuDSLs(DSLRegistry& reg) {
    reg.add(std::make_unique<GpuMemDSL>());
    reg.add(std::make_unique<GpuKernelDSL>());
    reg.add(std::make_unique<GpuBlockDSL>());
    reg.add(std::make_unique<GpuWarpDSL>());
    reg.add(std::make_unique<GpuAccelDSL>());
    reg.add(std::make_unique<GpuStreamDSL>());
    // GpuTextureDSL: irgen_gpu_texture.cpp'de tanımlı — tex:: namespace'ini aktive et.
    // Önceki versiyonda bu kayıt comment'te bırakılmıştı → tex::fetch1d/fetch2d/create/destroy
    // kullanılan her program "unknown DSL namespace 'tex'" hatası alırdı.
    // registerGpuTextureDSL ayrı bir kayıt fonksiyonu yerine doğrudan burada yapılıyor —
    // tek doğru konum bu (registerGpuDSLs tek giriş noktası, birden fazla
    // kayıt zinciri yönetim karmaşıklığı yaratır).
    extern void registerGpuTextureDSL(corelang::dsl::DSLRegistry&);
    registerGpuTextureDSL(reg);
}

// ══════════════════════════════════════════════════════════════════════════════
// GpuWarpDSL — i32 / i64 shuffle varyantları ek implementasyon
// ══════════════════════════════════════════════════════════════════════════════
// Ana GpuWarpDSL::lowerExpr f32 varyantlarını ele alır.
// Bu yardımcı, tip bilgisine göre doğru intrinsic'i seçer.
// IRGen'de CallExpr'ın tip bilgisine bakarak dispatch yapılır.

namespace corelang::dsl {

llvm::Value* emitWarpShuffleTyped(
    void* irCtx,
    llvm::Value* val,
    llvm::Value* offsetOrLane,
    llvm::Value* mask,
    llvm::Value* width,
    const std::string& variant, // "down", "up", "xor", "idx"
    llvm::Module* mod)
{
    auto* b   = static_cast<llvm::IRBuilder<>*>(
                    static_cast<IRContext*>(irCtx)->bld);
    auto& ctx = mod->getContext();
    auto* vTy = val->getType();
    bool isCuda = mod->getTargetTriple().find("nvptx") != std::string::npos;

    // i32 varyant
    if (vTy->isIntegerTy(32)) {
        // DÜZELTME: önceki versiyonda enum bulunamadığında (id ==
        // not_intrinsic) HER ZAMAN "down" f32 intrinsic'ine düşüyordu —
        // bu "up"/"xor"/"idx" varyantları için YANLIŞ SONUÇ üretirdi
        // (örn. warp::shuffle_up çağrısı sessizce shuffle_down çalıştırırdı).
        // String-tabanlı yaklaşımda artık variant'a göre DOĞRU intrinsic
        // ismi seçiliyor, hiçbir varyant için yanlış intrinsic'e düşme
        // riski yok.
        std::string intrName;
        if      (variant == "down") intrName = "llvm.nvvm.shfl.sync.down.i32";
        else if (variant == "up")   intrName = "llvm.nvvm.shfl.sync.up.i32";
        else if (variant == "xor")  intrName = "llvm.nvvm.shfl.sync.bfly.i32";
        else if (variant == "idx")  intrName = "llvm.nvvm.shfl.sync.idx.i32";

        if (!intrName.empty()) {
            return emitNvvmIntrinsicByName(irCtx, mod, intrName,
                llvm::Type::getInt32Ty(ctx), {mask, val, offsetOrLane, width},
                "__dsl_warp_shuffle_" + variant + "_i32_unused");
        }
        // Bilinmeyen variant string'i — Vulkan/CPU fallback'e düş
        // (aşağıdaki "Bilinmeyen tip" bloğuna devam eder)
    }

    // i64 varyant — NVPTX'te doğrudan i64 shuffle yok; iki i32'ye böl
    if (vTy->isIntegerTy(64)) {
        auto* i32Ty = llvm::Type::getInt32Ty(ctx);
        llvm::Value* lo = b->CreateTrunc(val, i32Ty);
        llvm::Value* hi = b->CreateTrunc(
            b->CreateLShr(val, llvm::ConstantInt::get(vTy, 32)), i32Ty);
        llvm::Value* shfl_lo = emitWarpShuffleTyped(
            irCtx, lo, offsetOrLane, mask, width, variant, mod);
        llvm::Value* shfl_hi = emitWarpShuffleTyped(
            irCtx, hi, offsetOrLane, mask, width, variant, mod);
        if (!shfl_lo || !shfl_hi) return nullptr;
        llvm::Value* lo64 = b->CreateZExt(shfl_lo, vTy);
        llvm::Value* hi64 = b->CreateZExt(shfl_hi, vTy);
        return b->CreateOr(lo64, b->CreateShl(hi64,
            llvm::ConstantInt::get(vTy, 32)), "shfl." + variant + ".i64");
    }

    // f64 varyant — f64'ü iki i32'ye böl
    if (vTy->isDoubleTy()) {
        auto* i64Ty = llvm::Type::getInt64Ty(ctx);
        llvm::Value* asI64 = b->CreateBitCast(val, i64Ty);
        llvm::Value* res   = emitWarpShuffleTyped(
            irCtx, asI64, offsetOrLane, mask, width, variant, mod);
        if (!res) return nullptr;
        return b->CreateBitCast(res, vTy);
    }

    // Bilinmeyen tip — Vulkan runtime fallback
    std::string rtName = "__dsl_warp_shuffle_" + variant;
    auto* fnTy  = llvm::FunctionType::get(vTy, {vTy, offsetOrLane->getType()}, false);
    auto* fn    = llvm::cast<llvm::Function>(
        mod->getOrInsertFunction(rtName, fnTy).getCallee());
    fn->setDoesNotThrow();
    return b->CreateCall(fn, {val, offsetOrLane}, "shfl." + variant);
}

} // namespace corelang::dsl
