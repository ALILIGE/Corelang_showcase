// ======================================================================
// gpu_runtime.h — CoreLang GPU Runtime: ZA HANDO LATENCY ERASE
// ======================================================================
// CUDA Driver API + Vulkan Compute ortak soyutlama katmanı.
// Derleme zamanında backend seçimi:
//   CL_GPU_HAS_CUDA   — CUDA Driver API (libcuda.so)
//   CL_GPU_HAS_VULKAN — Vulkan Compute (libvulkan.so)
//
// Bridge DSL entegrasyonu:
//   BridgeDomain::GPU_COMPUTE domain queue üzerinden çalışır.
//   BridgePinnedBuffer → cl_gpu_copy_h2d için doğrudan kullanılır.
//   BridgeScheduler adaptive dispatch kararını verir.
//   BridgeExecRecord GPU kernel latency metriklerini kaydeder.
//
// Thread safety: tüm fonksiyonlar thread-safe'dir.
//   cl_gpu_stream_ fonksiyonları per-stream senkronize çalışır.
//   cl_gpu_alloc/free global mutex ile korunur.
//
// Bellek modeli:
//   cl_gpu_alloc → GPU VRAM (@global bellek, addrspace(1))
//   cl_gpu_constant_alloc → GPU constant bellek (@constant, addrspace(4))
//   cl_gpu_shared bellek → kernel parametresi ile yönetilir
// ======================================================================

#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "bridge_runtime.h"

#ifdef __cplusplus
extern "C" {
#endif

// ══════════════════════════════════════════════════════════════════════════════
// Backend türleri
// ══════════════════════════════════════════════════════════════════════════════
typedef enum {
    CL_GPU_BACKEND_NONE   = 0,
    CL_GPU_BACKEND_CUDA   = 1,
    CL_GPU_BACKEND_VULKAN = 2,
} CL_GpuBackend;

// GPU stream handle — hem CUDA stream hem Vulkan queue soyutlar
// Ayrıca Bridge domain queue handle olarak da kullanılır.
typedef struct CL_GpuStream_s* CL_GpuStream;

// GPU cihaz bilgisi
typedef struct {
    int         device_id;
    char        name[256];
    size_t      vram_total;        // toplam VRAM (byte)
    size_t      vram_free;         // kullanılabilir VRAM (byte)
    uint32_t    compute_major;     // CUDA compute capability major
    uint32_t    compute_minor;
    uint32_t    max_threads_per_block;
    uint32_t    max_block_dim[3];
    uint32_t    max_grid_dim[3];
    uint32_t    warp_size;         // NVIDIA=32, AMD=64
    uint32_t    multiprocessor_count;
    bool        unified_memory;    // CPU+GPU paylaşımlı bellek desteği
    CL_GpuBackend backend;
} CL_GpuDeviceInfo;

// Adaptive dispatcher için istatistik
typedef struct {
    uint64_t cpu_calls;            // CPU'da çalıştırılan dispatch sayısı
    uint64_t gpu_calls;            // GPU'da çalıştırılan dispatch sayısı
    double   avg_gpu_latency_us;   // Ortalama GPU kernel gecikmesi (mikrosaniye)
    double   avg_pcie_overhead_us; // Ortalama PCIe transfer gecikmesi
    size_t   dispatch_threshold;   // Mevcut kalibrasyon eşiği (eleman sayısı)
} CL_GpuDispatchStats;

// ══════════════════════════════════════════════════════════════════════════════
// 1. Başlatma ve cihaz yönetimi
// ══════════════════════════════════════════════════════════════════════════════

// GPU runtime'ı başlat. Birden fazla çağrı güvenli (idempotent).
// Dönüş: true = en az bir GPU mevcut ve kullanılabilir
bool cl_gpu_init(void);

// GPU runtime'ı kapat ve tüm kaynakları serbest bırak.
void cl_gpu_shutdown(void);

// Kullanılabilir GPU sayısı
int cl_gpu_device_count(void);

// Mevcut thread için aktif GPU'yu seç
// id: 0-based device index
int cl_gpu_set_device(int id);

// Mevcut cihazın ID'si
int cl_gpu_get_device(void);

// Cihaz bilgisi
CL_GpuDeviceInfo cl_gpu_device_info(int device_id);

// GPU var mı? (init başarılıysa true)
bool cl_gpu_is_available(void);

// Aktif backend
CL_GpuBackend cl_gpu_backend(void);

// ══════════════════════════════════════════════════════════════════════════════
// 2. Bellek yönetimi — global (@global / addrspace(1))
// ══════════════════════════════════════════════════════════════════════════════

// VRAM tahsisi (sync)
void* __cl_gpu_alloc(size_t bytes);

// VRAM serbest bırakma
void __cl_gpu_free(void* ptr);

// Host → Device (senkron)
void __cl_gpu_copy_h2d(void* dst_gpu, const void* src_host, size_t bytes);

// Device → Host (senkron)
void __cl_gpu_copy_d2h(void* dst_host, const void* src_gpu, size_t bytes);

// Device → Device (senkron, aynı GPU)
void __cl_gpu_copy_d2d(void* dst_gpu, const void* src_gpu, size_t bytes);

// Senkronizasyon — aktif GPU'nun tüm operasyonlarını bekle
void __cl_gpu_sync(void);

// Tüm GPU'ların tüm operasyonlarını bekle
void __cl_gpu_sync_all(void);

// Bellek bilgisi
void __cl_gpu_mem_info(size_t* free_out, size_t* total_out);

// ══════════════════════════════════════════════════════════════════════════════
// 3. Constant bellek — @constant / addrspace(4)
// ══════════════════════════════════════════════════════════════════════════════

// Constant bellek tahsisi (CUDA: cudaMemcpyToSymbol wrapper)
// Vulkan: uniform buffer olarak map edilir
void* cl_gpu_constant_alloc(size_t bytes);
void  cl_gpu_constant_free(void* ptr);
void  cl_gpu_constant_upload(void* dst_const, const void* src_host, size_t bytes);

// ══════════════════════════════════════════════════════════════════════════════
// 4. Kernel yükleme ve launch
// ══════════════════════════════════════════════════════════════════════════════
// Bu runtime çalışma zamanında PTX / SPIR-V modüllerini yükler.
// CUDA path: cuModuleLoadData + cuModuleGetFunction
// Vulkan path: vkCreateShaderModule + vkCreateComputePipelines

typedef struct CL_GpuKernelHandle_s* CL_GpuKernelHandle;

// PTX binary'den kernel yükle (CUDA)
CL_GpuKernelHandle cl_gpu_load_kernel_ptx(const char* ptx_src, const char* fn_name);

// SPIR-V binary'den kernel yükle (Vulkan)
CL_GpuKernelHandle cl_gpu_load_kernel_spirv(const uint32_t* spirv, size_t spirv_size_bytes,
                                              const char* entry_point);

// Kernel handle'ı serbest bırak
void cl_gpu_unload_kernel(CL_GpuKernelHandle handle);

// Kernel launch — IRGen bu fonksiyonu çağıran IR üretir
// argv: kernel argümanlarına pointer array (void*[argc])
// stream: NULL = default stream
int __cl_gpu_kernel_launch(
    const char* kernel_name,
    uint32_t grid_x, uint32_t grid_y, uint32_t grid_z,
    uint32_t block_x, uint32_t block_y, uint32_t block_z,
    uint32_t dynamic_shared_mem_bytes,
    CL_GpuStream stream,
    uint32_t argc,
    void** argv
);

// ══════════════════════════════════════════════════════════════════════════════
// 5. Stream yönetimi — async ops
// ══════════════════════════════════════════════════════════════════════════════

// Yeni stream oluştur
// Bridge domain queue olarak kayıt edilir (BridgeDomain::GPU_COMPUTE)
CL_GpuStream __cl_gpu_stream_new(void);

// Stream'i kapat
void __cl_gpu_stream_destroy(CL_GpuStream stream);

// Stream'in tüm operasyonlarının bitmesini bekle
void __cl_gpu_stream_sync(CL_GpuStream stream);

// Stream tamamlandı mı? (non-blocking sorgu)
bool __cl_gpu_stream_query(CL_GpuStream stream);

// Async bellek tahsisi (CUDA 11.2+ memory pool)
void* __cl_gpu_alloc_async(size_t bytes, CL_GpuStream stream);

// Async host→device kopyası
void __cl_gpu_copy_h2d_async(void* dst_gpu, const void* src_host,
                               size_t bytes, CL_GpuStream stream);

// Async device→host kopyası
void __cl_gpu_copy_d2h_async(void* dst_host, const void* src_gpu,
                               size_t bytes, CL_GpuStream stream);

// İki stream arasında aynı pointer'a yazma/okuma çakışması var mı?
// (cross-stream race condition runtime doğrulaması — IRGen statik
// uyarılarını tamamlar). true = potansiyel hazard tespit edildi.
bool cl_gpu_check_cross_stream_hazard(CL_GpuStream s1, CL_GpuStream s2, void* ptr);

// ── @texture bellek desteği ──────────────────────────────────────────────────
// CUDA: cudaTextureObject_t (uint64_t handle) — cudaCreateTextureObject ile.
// Vulkan: VkImage + VkImageView + VkSampler kombinasyonu, aynı uint64_t
//         handle alanına opak bir index olarak map edilir.
uint64_t __cl_gpu_tex_create(const void* data, int32_t width, int32_t height);
void     __cl_gpu_tex_destroy(uint64_t tex_obj);

// ══════════════════════════════════════════════════════════════════════════════
// 6. Adaptive Dispatcher — GpuParallelForPass ile entegrasyon
// ══════════════════════════════════════════════════════════════════════════════
// gpu::parallel_for closures için CPU/GPU seçim mantığı.
// Bridge Scheduler üzerinden çalışır.
//
// Karar algoritması:
//   1. GPU mevcut değilse: CPU fallback
//   2. n < DISPATCH_THRESHOLD ise: CPU (PCIe overhead > GPU kazanımı)
//   3. n * elem_size < CL_GPU_PCIE_MIN_BYTES ise: CPU
//   4. GPU memory kuyruğu doluysa: CPU
//   5. Aksi halde: GPU

typedef void (*CL_GpuCpuFn)(const void* data, size_t n, size_t elem_size,
                               void* output, const void* captures);
typedef void (*CL_GpuGpuDispatchFn)(const void* data, size_t n, size_t elem_size,
                                     void* output, const void* captures,
                                     CL_GpuStream stream);

// dispatch_tag: "__cl_parallel_for" vb. — hangi kernel'i yükleyeceğini belirler
void* __cl_gpu_dispatch_adaptive(
    const void*       data_ptr,
    size_t            count,
    size_t            elem_size,
    const char*       dispatch_tag
);

// Dispatcher kalibrasyonu — ilk çalıştırmada otomatik, manuel de çağrılabilir
void cl_gpu_calibrate_threshold(void);

// Mevcut dispatch istatistikleri
CL_GpuDispatchStats cl_gpu_get_dispatch_stats(void);

// Dispatch eşiğini manuel ayarla (kalibrasyon sonucu geçersiz kılar)
void cl_gpu_set_dispatch_threshold(size_t n_elements);

// ══════════════════════════════════════════════════════════════════════════════
// 7. Bridge DSL entegrasyon API'si
// ══════════════════════════════════════════════════════════════════════════════

// GPU domain queue'sunu Bridge Scheduler'a kaydet
// cl_gpu_init() tarafından otomatik çağrılır.
void cl_gpu_register_bridge_domain(void);

// BridgePinnedBuffer'dan GPU'ya veri gönder
// (bridge_runtime.h'daki BridgePinnedBuffer kullanılır)
void cl_gpu_copy_from_pinned(void* dst_gpu, const BridgePinnedBuffer* pinned,
                              size_t bytes);

// GPU latency metriklerini Bridge ExecRecord'a yaz
void cl_gpu_record_bridge_metrics(double kernel_us, double pcie_us);

// ── Bridge Scheduler Entegrasyonu (Opsiyonel) ────────────────────────────────
// Varsayılan: KAPALI. GPU runtime'ın temel işlevselliği (alloc/copy/launch/
// sync) bu entegrasyona bağımlı DEĞİLDİR. Açıkça etkinleştirilmek istenirse
// (gözlemlenebilirlik/profiling amaçlı) bu fonksiyonlar kullanılır.
//
// CL_GPU_ENABLE_BRIDGE_SCHEDULER derleme bayrağı tanımlı DEĞİLSE, bu
// fonksiyonlar no-op'tur (cl_gpu_enable_bridge_integration bir uyarı
// basar ama crash etmez).
void cl_gpu_enable_bridge_integration(void);
void cl_gpu_disable_bridge_integration(void);

// Bridge scheduler'a submit edilen GPU iş kayıtlarının istatistiklerini
// sorgula. Dönüş: false = bridge entegrasyonu aktif değil/kullanılamıyor.
bool cl_gpu_get_bridge_stats(uint64_t* out_avg_latency_us, uint64_t* out_total_submitted);

// ══════════════════════════════════════════════════════════════════════════════
// 8. Device-side builtin yardımcıları (Vulkan/SPIR-V fallback)
// ══════════════════════════════════════════════════════════════════════════════
// CUDA path'te bu fonksiyonlar LLVM NVPTX intrinsic'lerine çevrilir
// ve asla çağrılmaz. Vulkan path için runtime implementasyonu gerekir.

int  __dsl_gpu_tid_x(void);
int  __dsl_gpu_tid_y(void);
int  __dsl_gpu_tid_z(void);
int  __dsl_gpu_ctaid_x(void);
int  __dsl_gpu_ctaid_y(void);
int  __dsl_gpu_ctaid_z(void);
int  __dsl_gpu_ntid_x(void);
int  __dsl_gpu_ntid_y(void);
int  __dsl_gpu_ntid_z(void);
int  __dsl_gpu_nctaid_x(void);
int  __dsl_gpu_nctaid_y(void);
int  __dsl_gpu_nctaid_z(void);
int  __dsl_gpu_warpsize(void);

// block::sync() Vulkan fallback
void __dsl_block_sync(void);
void __dsl_block_sync_partial(uint32_t mask);

// warp:: Vulkan fallback
float    __dsl_warp_shuffle_down(float val, int offset);
float    __dsl_warp_shuffle_up(float val, int offset);
float    __dsl_warp_shuffle_xor(float val, int mask);
float    __dsl_warp_shuffle(float val, int src_lane);
// DÜZELTME: _Bool dönüş tipi — IRGen CreateTrunc ile i1'e daraltıyor,
// Vulkan fallback'in ABI uyumlu olması için _Bool (C99) kullanılmalı.
_Bool    __dsl_warp_vote_all(int pred);
_Bool    __dsl_warp_vote_any(int pred);
uint32_t __dsl_warp_ballot(int pred);
int      __dsl_warp_lane_id(void);
void     __dsl_warp_sync(void);
void     __dsl_warp_sync_partial(uint32_t mask);

// SPIR-V group ops fallback
float __dsl_spirv_group_shuffle_down(float val, uint32_t offset);
void  __dsl_spirv_control_barrier(void);

// Texture fetch fallback (CPU/Vulkan path — CUDA NVVM intrinsic kullanır,
// bu fonksiyonları hiç çağırmaz)
float __dsl_tex_fetch1d(uint64_t tex_obj, float coord);
float __dsl_tex_fetch2d(uint64_t tex_obj, float u, float v);

// ── GPU Policy uygulama (gpu_runtime_policy.c'de implement edilir) ──────────
// #[policy(...)] attribute'u ile launch edilen kernel'lar için, kernel
// launch'tan ÖNCE çağrılır; CUDA occupancy calculator veya Vulkan workgroup
// limitlerine göre optimal block boyutunu hesaplar.
void __cl_gpu_policy_apply(
    const char* kernel_name,
    uint32_t    preferred_blockX,
    uint32_t    preferred_blockY,
    uint32_t    preferred_blockZ);

// Hesaplanan policy sonucunu sorgula (kernel launch sırasında override için)
bool cl_gpu_get_policy_block(
    const char* kernel_name,
    uint32_t*   out_blockX,
    uint32_t*   out_blockY,
    uint32_t*   out_blockZ);

#ifdef __cplusplus
} // extern "C"
#endif
