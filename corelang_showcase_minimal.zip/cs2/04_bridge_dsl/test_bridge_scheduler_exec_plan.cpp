#include "../src/dsl/bridge_scheduler.h"
#include "../src/dsl/bridge_graph.h"
#include <cstdio>
#include <cstring>
using namespace corelang::bridge;

int main() {
    BridgeGraph* g = __bridge_graph_create("plan_test");

    BridgeNode n1; memset(&n1, 0, sizeof(n1));
    n1.name = "load";
    n1.kind = BRIDGE_NODE_IO;
    n1.domain = BRIDGE_DOMAIN_NATIVE_CPU;
    n1.sched_hints.max_latency_us = 500;
    n1.sched_hints.parallel_ok = true;
    __bridge_graph_add_node(g, &n1);

    BridgeNode n2; memset(&n2, 0, sizeof(n2));
    n2.name = "process";
    n2.kind = BRIDGE_NODE_COMPUTE;
    n2.domain = BRIDGE_DOMAIN_NATIVE_CPU;
    n2.sched_hints.max_latency_us = 1000;
    __bridge_graph_add_node(g, &n2);

    BridgeEdge e; memset(&e, 0, sizeof(e));
    e.src_node = "load";
    e.dst_node = "process";
    __bridge_graph_add_edge(g, &e);

    BridgeSchedulerConfig cfg; memset(&cfg, 0, sizeof(cfg));
    BridgeScheduler* sched = __bridge_scheduler_create(&cfg);

    BridgeExecPlan* plan = __bridge_scheduler_generate_plan(sched, g);
    int t1 = (plan != nullptr) && (plan->plan_node_count == 2);
    printf("plan_node_count=%u (expected 2)\n", plan ? plan->plan_node_count : 0);

    int t2 = 0, t3 = 0;
    if (plan) {
        for (uint32_t i = 0; i < plan->plan_node_count; ++i) {
            BridgeExecPlanNode* pn = &plan->plan_nodes[i];
            printf("  [%u] name=%s domain=%d latency=%u parallel=%d depends_count=%u\n",
                   i, pn->node_name, pn->domain, pn->latency_budget_us, pn->parallel_ok, pn->depends_count);
            if (strcmp(pn->node_name, "load") == 0) {
                t2 = (pn->latency_budget_us == 500) && (pn->depends_count == 0);
            }
            if (strcmp(pn->node_name, "process") == 0) {
                t3 = (pn->latency_budget_us == 1000) && (pn->depends_count == 1) &&
                     (strcmp(pn->depends_on[0], "load") == 0);
            }
        }
        __bridge_exec_plan_print(plan, stdout);
    }

    // [BRIDGE-DEV] estimated_total_us/thread_count fix doğrulaması:
    // load (parallel_ok=true, 500us), process (parallel_ok=false, 1000us)
    // sequential_sum = 1000 (process), parallel_max = 500 (load)
    // expected estimated_total_us = 1000 + 500 = 1500
    // expected thread_count = 1 (sadece 1 paralel node var)
    int t_total = plan && (plan->estimated_total_us == 1500);
    int t_threads = plan && (plan->thread_count == 1);
    printf("estimated_total_us=%u (expected 1500), thread_count=%u (expected 1)\n",
           plan ? plan->estimated_total_us : 0, plan ? plan->thread_count : 0);

    // Boş graf testi — node_count=0, kırma denemesi
    BridgeGraph* empty_g = __bridge_graph_create("empty");
    BridgeExecPlan* empty_plan = __bridge_scheduler_generate_plan(sched, empty_g);
    int t4 = (empty_plan != nullptr) && (empty_plan->plan_node_count == 0);
    printf("empty graph plan_node_count=%u (expected 0)\n", empty_plan ? empty_plan->plan_node_count : 999);

    // NULL graf testi
    BridgeExecPlan* null_plan = __bridge_scheduler_generate_plan(sched, nullptr);
    int t5 = (null_plan == nullptr);
    printf("NULL graph plan: %s (expected nullptr)\n", null_plan ? "non-null (BUG)" : "nullptr (correct)");

    int pass = t1 && t2 && t3 && t4 && t5 && t_total && t_threads;
    printf("\n%s\n", pass ? "EXEC PLAN TEST PASSED" : "TEST FAILED");

    if (plan) __bridge_exec_plan_destroy(plan);
    if (empty_plan) __bridge_exec_plan_destroy(empty_plan);
    __bridge_scheduler_destroy(sched);
    __bridge_graph_destroy(g);
    __bridge_graph_destroy(empty_g);
    return pass ? 0 : 1;
}
