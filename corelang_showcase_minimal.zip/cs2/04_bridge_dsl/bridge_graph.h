/*
 * bridge_graph.h — Unified Execution Graph Data Structures
 *
 * [koprudsl.md §1, §3] Graph modeli:
 *   - Node, Port, Edge, Policy — 4 parça
 *   - Hierarchical graph (composite node)
 *   - Semantic layer + Execution layer ayrımı
 *   - Content-addressed node/edge kimlikleri
 */

#ifndef BRIDGE_GRAPH_H_INCLUDED
#define BRIDGE_GRAPH_H_INCLUDED

#include "capability.h"
#include "../runtime/bridge_runtime.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* ════════════════════════════════════════════════════════════════════════════
 * PART 1 — Graph Core Types
 * ════════════════════════════════════════════════════════════════════════════ */

// Node kind — iş sınıfı (dil değil, iş tipi)
// [koprudsl.md §1] "Python node", "Rust node" değil — iş sınıfı
typedef enum BridgeNodeKind {
    BRIDGE_NODE_COMPUTE    = 0,  // Hesap yapar: parsing, transform, inference
    BRIDGE_NODE_IO         = 1,  // Dış dünya ile konuşur: file, socket, device
    BRIDGE_NODE_CONTROL    = 2,  // Akışı değiştirir: if, match, branch, retry
    BRIDGE_NODE_POLICY     = 3,  // Kural uygular: security, policy check
    BRIDGE_NODE_BRIDGE     = 4,  // Dil/runtime sınırı geçer: FFI, bridge call
    BRIDGE_NODE_DESCRIPTOR = 5,  // Çalışmayı tanımlar, iş yapmaz: meta, config
    BRIDGE_NODE_COMPOSITE  = 6,  // Alt graph içeren composite node
} BridgeNodeKind;

// Port kind — node'un giriş/çıkış yüzü tipleri
// [koprudsl.md §1] Tek tip "function call" yetmez
typedef enum BridgePortKind {
    BRIDGE_PORT_INPUT   = 0,  // Veri girişi
    BRIDGE_PORT_OUTPUT  = 1,  // Veri çıkışı
    BRIDGE_PORT_EVENT   = 2,  // Event/notification
    BRIDGE_PORT_ERROR  = 3,  // Hata çıkışı
    BRIDGE_PORT_CONTROL = 4, // Kontrol akışı
} BridgePortKind;

// Edge dependency type — edge'in taşıdığı bağımlılık türü
// [koprudsl.md §1] Sadece "sonra bu çalışsın" değil
typedef enum BridgeEdgeKind {
    BRIDGE_EDGE_DATA       = 0, // Data dependency
    BRIDGE_EDGE_CONTROL    = 1, // Control dependency
    BRIDGE_EDGE_MEMORY    = 2, // Memory dependency (ownership transfer)
    BRIDGE_EDGE_PERMISSION = 3, // Permission/Trust dependency
    BRIDGE_EDGE_TIMING     = 4, // Timing/latency constraint
    BRIDGE_EDGE_TRUST      = 5, // Trust chain (trust<T> annotation)
} BridgeEdgeKind;

// ── Port Descriptor ────────────────────────────────────────────────────────────
typedef struct BridgePort {
    const char*          name;        // Port adı: "data_in", "result_out"
    BridgePortKind       kind;        // Port tipi
    const char*          type_hint;  // Tip annotation: "ndarray<f32>", "Result<...>"
    BridgeOwnership      ownership;   // Bu port üzerinden gelen verinin sahipliği
    bool                 optional;    // Zorunlu mu?
    uint32_t             capacity;   // Buffer capacity (0 = unbounded)
} BridgePort;

// ── Effect Set Descriptor ───────────────────────────────────────────────────────
typedef struct BridgeEffectSet {
    uint32_t             effects;     // DSLEffect bitmask
    uint32_t             conditional_count; // Conditional effect sayısı
    const BridgeConditionalEffect* conditional_effects; // Conditional rules
} BridgeEffectSet;

// ── Scheduling Hints ────────────────────────────────────────────────────────────
// [koprudsl.md §1] Scheduler bu bilgiyi kullanarak execution plan kurar
typedef struct BridgeSchedHints {
    uint32_t             max_latency_us;    // Maksimum çalışma süresi
    uint32_t             min_latency_us;    // Minimum beklenen süre (optimization)
    uint8_t              priority;          // Priority (0-255, higher = first)
    bool                 parallel_ok;       // Başka node'larla paralel çalışabilir mi?
    bool                 cacheable;         // Sonuç cache'lenebilir mi?
    bool                 preemptible;        // Preempt edilebilir mi?
    const char*          fallback_node;      // Hata durumunda alternatif node
    BridgeRetryConfig    retry_config;       // Retry politikası
} BridgeSchedHints;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 2 — Node Descriptor
 * ════════════════════════════════════════════════════════════════════════════ */

// Node descriptor — execution node (iş yapan parça)
// [koprudsl.md §1] function değil, execution entity
typedef struct BridgeNode {
    // Identity
    const char*          name;         // Node adı: "load_data", "inference"
    uint64_t             node_id;      // Content-addressed ID (FNV-1a hash)
    BridgeNodeKind       kind;         // İş sınıfı
    BridgeDomain         domain;       // Çalışma domain'i
    const char*          source_loc;   // Source location: "file:line"

    // Contract
    BridgeEffectSet      effects;      // Effect set
    BridgeErrorModel     error_model;  // Hata modeli
    BridgeAsyncModel     async_model;  // Async model
    corelang::dsl::DeterminismLevel determinism;  // Belirlenimcilik seviyesi
    corelang::dsl::OwnershipCategory ownership;    // Varsayılan ownership

    // Ports
    uint32_t             input_count;
    BridgePort*          inputs;
    uint32_t             output_count;
    BridgePort*          outputs;

    // Scheduling
    BridgeSchedHints     sched_hints;  // Scheduler hints

    // Metadata
    uint32_t             version;      // Node sürümü (cache invalidation için)
    const char*          contract_ref; // İlişkili kontrat adı
    const char*          policy_ref;   // İlişkili policy adı
    const char*          backend_ref;  // Hangi backend'e indirildi
    const char*          subgraph_ref; // Alt graph reference (composite node)
} BridgeNode;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 3 — Edge Descriptor
 * ════════════════════════════════════════════════════════════════════════════ */

// Edge descriptor — node'lar arasındaki bağ
// [koprudsl.md §1] Sadece "çağrı" değil, dependency türü var
typedef struct BridgeEdge {
    const char*          name;         // Edge adı (optional)
    uint64_t             edge_id;      // Content-addressed ID
    const char*          src_node;     // Kaynak node adı
    const char*          dst_node;     // Hedef node adı
    const char*          src_port;     // Kaynak port adı (nullable)
    const char*          dst_port;     // Hedef port adı (nullable)
    BridgeEdgeKind       kind;         // Bağımlılık türü
    BridgeOwnership      ownership;     // Data transfer ownership

    // Latency constraint
    uint32_t             latency_budget_us; // Bu edge için max latency

    // Policy
    bool                 required;    // Zorunlu mu? (false = optional fallback)
    const char*          condition;   // Koşul ifadesi (nullable = her zaman)
} BridgeEdge;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 4 — Policy Descriptor
 * ════════════════════════════════════════════════════════════════════════════ */

// Policy rule — akışın kuralları
// [koprudsl.md §1] "şu node kernel ister", "bu node sadece pure olabilir"
typedef struct BridgePolicy {
    const char*          name;         // Policy adı
    const char*          description;  // Human-readable açıklama
    BridgeDomain         required_domain;   // Zorunlu domain
    BridgeDomain         forbidden_domain;  // Yasak domain
    uint32_t             effects_allowed; // İzin verilen effect bitmask
    uint32_t             effects_forbidden; // Yasak effect bitmask
    bool                 deterministic_required; // Belirlenimcilik zorunlu mu?
    bool                 async_required;      // Async zorunlu mu?
    corelang::dsl::DeterminismLevel min_determinism;   // Minimum determinism seviyesi
} BridgePolicy;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 5 — Contract Descriptor (Foreign Runtime Contract)
 * ════════════════════════════════════════════════════════════════════════════ */

// Contract descriptor — node'un ne beklediği ve ne verdiği
// [koprudsl.md §1] "contract-first" tasarım — önce neyi garanti ettiğini yaz
typedef struct BridgeContract {
    const char*          name;         // Kontrat adı: "numpy", "rust_lib"
    const char*          origin;       // Runtime origin: "python", "rust", "c"
    const char*          abi_version; // ABI versiyonu: "CPython_3_11", "Rust_1.70"
    const char*          version_min;  // Minimum versiyon: ">=1.24"
    const char*          version_max;  // Maksimum versiyon: "<3.0"

    // Effect ve context constraints
    uint32_t             effects;     // Effect bitmask
    uint32_t             context_allowed;  // İzin verilen context bitmask
    uint32_t             context_forbidden; // Yasak context bitmask

    // Ownership ve error model
    corelang::dsl::OwnershipCategory ownership;    // Varsayılan ownership
    BridgeErrorModel    error_model;  // Hata modeli
    BridgeAsyncModel     async_model;  // Async model

    // Thread safety
    BridgeThreadSafety  thread_safety; // Thread safety garantisi
    BridgeGCMode        gc_mode;      // GC mode

    // Retry ve failure
    BridgeRetryConfig   retry;       // Retry politikası (sıfır = yok)
    BridgeFailureStrategy failure_strategy; // Hata stratejisi
    const char*         fallback_fn; // Alternatif fonksiyon adı

    // Trust
    bool                 trusted;    // Kontrat doğrulanmış mı?
    const char*          author;     // Kontrat yazarı
    const char*          verified_by; // Nasıl doğrulandı: "static_analysis", "runtime_test"
} BridgeContract;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 6 — Hierarchical Graph (Composite Node)
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §4] Graph explosion engellemek için:
//   - 10k node'lu graph debug edilemez
//   - Graph recursively compose edilmeli
//   - "Pipeline Node" → alt graph'lar içeren composite node
 */

// Subgraph reference — alt graph'a referans
typedef struct BridgeSubgraphRef {
    const char*          subgraph_name; // Alt graph adı
    const char*          entry_port;   // Giriş portu
    const char*          exit_port;   // Çıkış portu
} BridgeSubgraphRef;

// Composite node — alt graph içeren node
// [koprudsl.md §4] "graph içeren graph node'u" — şart
typedef struct BridgeCompositeNode {
    BridgeNode           base;        // Temel node bilgileri

    // Alt graph referansları
    uint32_t             subgraph_count;
    BridgeSubgraphRef*   subgraphs;

    // Port mapping (dış port → iç port)
    uint32_t             port_mapping_count;
    const char**         port_mappings; // "ext_in" → "sub1_in1" eşleşmesi
} BridgeCompositeNode;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 7 — Full Graph Descriptor (Semantic + Execution Layer)
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §3] Graph serialization iki katmanlı:
//   - Semantic layer: node'un anlamı (değişmez)
//   - Execution layer: node'un nasıl çalıştığı (backend'e göre değişir)
 */

// Graph serialization version
#define BRIDGE_GRAPH_VERSION 1

// Graph descriptor — tam graph tanımı
typedef struct BridgeGraph {
    // Graph metadata
    const char*          name;         // Graph adı
    const char*          version;     // Graph versiyonu
    uint64_t             graph_id;    // Content-addressed ID
    uint32_t             schema_version; // Schema versiyonu

    // Nodes
    uint32_t             node_count;
    BridgeNode*          nodes;

    // Edges
    uint32_t             edge_count;
    BridgeEdge*          edges;

    // Policies
    uint32_t             policy_count;
    BridgePolicy*        policies;

    // Contracts
    uint32_t             contract_count;
    BridgeContract*      contracts;

    // Hierarchical structure (composite nodes)
    uint32_t             composite_count;
    BridgeCompositeNode* composites;

    // Semantic metadata (execution layer'da korunan)
    uint64_t             semantic_hash;    // Semantic layer hash (cache invalidation)
    uint64_t             execution_hash;   // Execution layer hash
    const char*          lowering_target;  // Backend hedefi: "native", "cuda", "python"
    uint32_t             lowering_pass;     // Kaçıncı lowering pass
} BridgeGraph;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 8 — Graph Analysis API (BridgeChecker entegrasyonu)
 * ════════════════════════════════════════════════════════════════════════════ */

// Analysis result — compile-time analiz sonuçları
typedef struct BridgeAnalysisResult {
    bool                 valid;           // Graph geçerli mi?
    uint32_t             error_count;
    const char**        errors;          // Hata mesajları (array)
    uint32_t             warning_count;
    const char**        warnings;        // Uyarı mesajları (array)

    // Detected issues
    bool                 has_cycles;      // Cycle tespit edildi mi?
    bool                 has_domain_conflict; // Domain uyumsuzluğu var mı?
    bool                 has_effect_violation; // Effect algebra ihlali var mı?
    bool                 has_async_conflict;  // Async model çakışması var mı?
    bool                 has_determinism_conflict; // Determinism çakışması var mı?
} BridgeAnalysisResult;

// ── API: Graph construction ──────────────────────────────────────────────────────
// [BRIDGE-DEV] KRİTİK FIX: Bu API bloğu önceden global scope'ta declare
// ediliyordu, ama bridge_graph.cpp'deki TÜM implementasyonlar
// `namespace corelang::bridge { ... }` içinde tanımlı. Bu, link-time'da
// "undefined reference" hatasına yol açan gerçek bir bug — global scope'tan
// çağrılan __bridge_cache_hit/__bridge_cache_lookup gibi semboller asla
// bulunamıyordu (mangled isimler tamamen farklı: _Z18__bridge_cache_hit...
// vs _ZN8corelang6bridge18__bridge_cache_hit...). Bu, bridge_incident.cpp'de
// düzeltilen namespace sorunuyla AYNI KALIP — burada da aynı düzeltmeyi
// uyguluyoruz: header deklarasyonlarını .cpp'deki gerçek namespace'le eşitliyoruz.
namespace corelang::bridge {

BridgeGraph* __bridge_graph_create(const char* name);
void         __bridge_graph_destroy(BridgeGraph* g);
void         __bridge_graph_add_node(BridgeGraph* g, const BridgeNode* node);
void         __bridge_graph_add_edge(BridgeGraph* g, const BridgeEdge* edge);
void         __bridge_graph_add_policy(BridgeGraph* g, const BridgePolicy* policy);
void         __bridge_graph_add_contract(BridgeGraph* g, const BridgeContract* contract);

// ── API: Content-addressed ID generation (FNV-1a) ───────────────────────────────
// Implemented in bridge_graph.cpp
uint64_t __bridge_fnv1a(const void* data, size_t len);
uint64_t __bridge_node_hash(const BridgeNode* node);
uint64_t __bridge_edge_hash(const BridgeEdge* edge);
uint64_t __bridge_graph_hash(const BridgeGraph* g);

// ── API: Graph analysis ──────────────────────────────────────────────────────────
BridgeAnalysisResult* __bridge_analyze_graph(const BridgeGraph* g);
void                  __bridge_analysis_destroy(BridgeAnalysisResult* r);

// ── API: Semantic layer operations ─────────────────────────────────────────────
uint64_t __bridge_graph_semantic_hash(const BridgeGraph* g);
void     __bridge_graph_clone_semantic(const BridgeGraph* src, BridgeGraph* dst);

// ── API: Execution layer operations ─────────────────────────────────────────────
// [BRIDGE-DEV] FIX: imza const BridgeGraph*'tan BridgeGraph*'a değişti —
// fonksiyon artık her node'un backend_ref'ini gerçekten yazıyor (önceden
// hiçbir şey yapmıyordu, const olması da bu yüzden sorun değildi; şimdi
// gerçek bir mutasyon var, imza bunu yansıtmalı).
void __bridge_graph_lower(BridgeGraph* g, const char* target);
void __bridge_graph_schedule(const BridgeGraph* g, BridgeGraph* scheduled_out);

} // namespace corelang::bridge

/* ════════════════════════════════════════════════════════════════════════════
 * PART 9 — Cached Execution State (VEE Entegrasyonu)
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §3] VEE snapshot — her execution state commit olarak saklanır
// Incremental computation: değişmeyen node'lar yeniden çalışmıyor
 */

// Cached node result — önceki run'dan cache'lenmiş sonuç
typedef struct BridgeCachedResult {
    uint64_t             node_id;      // Node ID
    uint64_t             content_hash; // Output content hash
    void*                output_ptr;   // Cached output pointer
    uint32_t             output_size;   // Output size
    uint64_t             timestamp;    // Cache timestamp
} BridgeCachedResult;

// Execution snapshot — VEE snapshot formatı
typedef struct BridgeExecutionSnapshot {
    const char*          graph_name;
    uint64_t             run_id;        // Unique run ID
    uint64_t             graph_hash;    // Graph hash at execution time
    uint32_t             node_count;
    BridgeNodeState*     node_states;   // Node state array
    BridgeCachedResult*  cached_results; // Cache entries
    uint32_t             cache_count;
    uint64_t             start_time;    // Execution start timestamp
    uint64_t             end_time;     // Execution end timestamp
} BridgeExecutionSnapshot;

// ── API: Cached execution ───────────────────────────────────────────────────────
// [BRIDGE-DEV] Aynı namespace düzeltmesi burada da gerekli — bu API'ler
// bridge_incident.cpp'deki replay engine tarafından doğrudan kullanılıyor.
namespace corelang::bridge {

BridgeCachedResult* __bridge_cache_lookup(const char* graph_name,
                                          uint64_t node_id,
                                          uint64_t content_hash);
// [BRIDGE-DEV] YENİ — replay engine'in "no_baseline" ile "gerçek
// divergence"ı ayırt edebilmesi için. __bridge_cache_lookup yalnızca TAM
// (node_id, content_hash) eşleşmesi arıyor; bu fonksiyon "bu node_id için
// cache'te HERHANGİ bir kayıt var mı" sorusuna cevap verir (content_hash'e
// bakmaksızın, en son timestamp'li olanı döner). Hiç kayıt yoksa nullptr —
// bu, replay'in "bu node hiç çalışmamış, baseline yok" durumunu güvenle
// tespit etmesini sağlar; kayıt var ama content_hash farklıysa, bu gerçek
// bir divergence'tır.
BridgeCachedResult* __bridge_cache_lookup_any(const char* graph_name,
                                               uint64_t node_id);
void __bridge_cache_store(const char* graph_name,
                         const char* node_name,
                         uint64_t content_hash,
                         void* output_ptr,
                         uint32_t output_size);
bool __bridge_cache_hit(const char* graph_name, uint64_t node_id, uint64_t content_hash);

} // namespace corelang::bridge

#endif /* BRIDGE_GRAPH_H_INCLUDED */