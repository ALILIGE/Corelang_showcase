/*
 * bridge_scheduler.cpp — Semantic Execution Scheduler Implementation
 *
 * [koprudsl.md §3] İki katmanlı scheduler:
 *   - Statik: compile-time graph analizi
 *   - Dinamik: runtime execution, work stealing queue
 *
 * Thread pool, GIL queue, cache, retry, timeout management.
 */

#include "bridge_scheduler.h"
#include "bridge_graph.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <chrono>   // [FIX 3.4] monotonic timestamp
#include <vector>
#include <deque>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <mutex>
#include <time.h>  // FIX (sorun 8): POSIX clock_gettime for timestamps
#include <atomic>
#include <thread>
#include <condition_variable>
#include <functional>


// FIX (sorun 8): timestamp = 0 was used everywhere, breaking replay ordering,
// latency analysis, and causality traces. Use POSIX CLOCK_MONOTONIC.
static inline uint64_t get_time_us() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000ULL + (uint64_t)ts.tv_nsec / 1000ULL;
}

namespace corelang::bridge {

/* ════════════════════════════════════════════════════════════════════════════
 * Domain Queue Implementation (Work Stealing Pattern)
 * ════════════════════════════════════════════════════════════════════════════ */

struct DomainQueueImpl {
    BridgeDomain         domain;
    std::vector<BridgeWorkItem*> queue;
    std::mutex            mutex;
    std::condition_variable cv;
    bool                  shutdown = false;
    uint32_t              thread_count;
    std::vector<std::thread> workers;

    DomainQueueImpl(BridgeDomain d, const BridgeQueueConfig* cfg)
        : domain(d), thread_count(cfg ? cfg->thread_count : 1) {}

    ~DomainQueueImpl() {
        shutdown = true;
        cv.notify_all();
        for (auto& t : workers) {
            if (t.joinable()) t.join();
        }
    }
};

// [BRIDGE-DEV] NOT: __bridge_scheduler_get_queue burada DEĞİL —
// SchedulerImpl struct tanımından SONRA olması gerekiyor (impl içindeki
// domain_queues/domain_queues_mutex alanlarına erişiyor). Bkz. aşağıda,
// SchedulerImpl tanımının hemen sonrası.

int __bridge_domain_queue_push(BridgeDomainQueue* q, BridgeWorkItem* item) {
    if (!q || !item) return -1;
    auto* impl = reinterpret_cast<DomainQueueImpl*>(q);
    std::lock_guard<std::mutex> lock(impl->mutex);
    impl->queue.push_back(item);
    impl->cv.notify_one();
    return 0;
}

int __bridge_domain_queue_pop(BridgeDomainQueue* q, BridgeWorkItem* item_out) {
    if (!q || !item_out) return -1;
    auto* impl = reinterpret_cast<DomainQueueImpl*>(q);
    std::unique_lock<std::mutex> lock(impl->mutex);
    impl->cv.wait(lock, [&] { return !impl->queue.empty() || impl->shutdown; });
    if (impl->shutdown && impl->queue.empty()) return -1;
    *item_out = *impl->queue.front();
    impl->queue.erase(impl->queue.begin());
    return 0;
}

uint32_t __bridge_domain_queue_size(BridgeDomainQueue* q) {
    if (!q) return 0;
    auto* impl = reinterpret_cast<DomainQueueImpl*>(q);
    std::lock_guard<std::mutex> lock(impl->mutex);
    return static_cast<uint32_t>(impl->queue.size());
}

bool __bridge_domain_queue_is_empty(BridgeDomainQueue* q) {
    if (!q) return true;
    auto* impl = reinterpret_cast<DomainQueueImpl*>(q);
    std::lock_guard<std::mutex> lock(impl->mutex);
    return impl->queue.empty();
}

/* ════════════════════════════════════════════════════════════════════════════
 * Scheduler Implementation
 * ════════════════════════════════════════════════════════════════════════════ */

struct SchedulerImpl {
    BridgeSchedulerConfig config;
    BridgeSchedulerState   state;
    std::mutex             state_mutex;

    // Work stealing queues per domain
    std::unordered_map<int, DomainQueueImpl*> domain_queues;
    // [BRIDGE-DEV] YENİ — get_queue artık gerçekten domain_queues map'ini
    // dolduruyor (lazy-init), bu yüzden eşzamanlı erişime karşı korunması
    // gerekiyor. Önceden map hiç değiştirilmediği için (sadece destructor'da
    // okunuyordu) bir mutex'e ihtiyaç yoktu.
    std::mutex domain_queues_mutex;

    // GIL queue (single-threaded for Python)
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (dış incelemede bulundu):
    // std::vector idi, queue.erase(queue.begin()) ile pop yapılıyordu —
    // bu, std::vector'da O(N) bir işlem (başından silme, kalan TÜM
    // elemanları bir pozisyon kaydırır). Yüksek throughput'lu bir
    // scheduler'da, her pop işleminde kuyruktaki TÜM elemanları kaydırmak
    // ciddi bir performans kaybı — N elemanlı bir kuyruğu boşaltmak O(N²)
    // toplam işlem gerektirir. std::deque, başından silmeyi O(1) yapar
    // (push_back/pop_front ring-buffer benzeri segment yapısı kullanır),
    // front()/erase(begin()) aynı kullanım kalıbıyla, sadece doğru
    // complexity garantisiyle çalışır.
    std::deque<BridgeWorkItem*> gil_queue;
    std::mutex                   gil_mutex;
    std::condition_variable      gil_cv;

    // Global work queue
    std::deque<BridgeWorkItem*> global_queue;
    std::mutex                   global_mutex;
    std::condition_variable      global_cv;

    // Thread pool
    std::vector<std::thread>     worker_threads;
    std::atomic<bool>            running{false};
    std::atomic<bool>            shutdown{false};

    // Cache
    struct CacheEntry {
        void* data;
        uint32_t size;
        uint64_t timestamp;
    };
    std::unordered_map<std::string, CacheEntry> cache;
    std::mutex                               cache_mutex;

    // Execution records
    std::vector<BridgeExecRecord> records;
    std::mutex                             records_mutex;
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (dış incelemede bulundu):
    // wait_node/wait_all önceden std::this_thread::sleep_for(10ms) ile
    // busy-poll yapıyordu — her bekleme döngüsünde mutex alıp queue/records
    // kontrolü yapıp 10ms uyuyordu. Bu, (a) gereksiz CPU tüketimi, (b) en
    // kötü durumda 10ms'e kadar gecikme (bir item tamamlandığı anda haberdar
    // olunmuyor, sonraki 10ms penceresinde fark ediliyor) anlamına geliyordu.
    // completion_cv, her item tamamlandığında (records_mutex altında)
    // notify_all ile sinyal veriyor — wait_node/wait_all artık gerçek
    // koşullu bekleme yapıyor, polling yok.
    std::condition_variable                completion_cv;

    // Statistics
    std::atomic<uint64_t> total_submitted{0};
    std::atomic<uint64_t> total_completed{0};
    std::atomic<uint64_t> total_failed{0};
    std::atomic<uint64_t> total_cached{0};
    std::atomic<uint64_t> total_retried{0};
    std::atomic<uint64_t> total_timeout{0};

    SchedulerImpl(const BridgeSchedulerConfig* cfg) : state(BRIDGE_SCHED_IDLE) {
        if (cfg) config = *cfg;
    }

    ~SchedulerImpl() {
        stop();
        for (auto& kv : domain_queues) {
            delete kv.second;
        }
        // Clear cache
        std::lock_guard<std::mutex> lock(cache_mutex);
        for (auto& kv : cache) {
            free(kv.second.data);
        }
    }

    int start() {
        std::lock_guard<std::mutex> lock(state_mutex);
        if (state == BRIDGE_SCHED_RUNNING) return 0;
        running = true;
        shutdown = false;
        uint32_t thread_count = config.native_threads > 0 ? config.native_threads : 4;
        for (uint32_t i = 0; i < thread_count; ++i) {
            worker_threads.emplace_back([this] { worker_loop(); });
        }
        state = BRIDGE_SCHED_RUNNING;
        return 0;
    }

    int stop() {
        std::lock_guard<std::mutex> lock(state_mutex);
        if (state == BRIDGE_SCHED_STOPPED) return 0;
        running = false;
        shutdown = true;
        global_cv.notify_all();
        gil_cv.notify_all();
        for (auto& t : worker_threads) {
            if (t.joinable()) t.join();
        }
        worker_threads.clear();
        state = BRIDGE_SCHED_STOPPED;
        return 0;
    }

    void worker_loop() {
        while (!shutdown) {
            BridgeWorkItem* item = nullptr;
            {
                std::unique_lock<std::mutex> lock(global_mutex);
                global_cv.wait_for(lock, std::chrono::milliseconds(100),
                    [&] { return !global_queue.empty() || shutdown || !running; });
                if (shutdown || !running) break;
                if (!global_queue.empty()) {
                    item = global_queue.front();
                    global_queue.erase(global_queue.begin());
                }
            }
            if (item) {
                execute_item(item);
            }
        }
    }

    void execute_item(BridgeWorkItem* item) {
        if (!item) return;

        uint64_t start_us = get_time_us();
        bool cache_hit = false;

        // Check cache first
        if (config.enable_cache) {
            char key[256];
            snprintf(key, sizeof(key), "%s:%llu", item->node_name,
                    (unsigned long long)item->content_hash);
            std::lock_guard<std::mutex> lock(cache_mutex);
            auto it = cache.find(key);
            if (it != cache.end()) {
                item->output_ptr = it->second.data;
                cache_hit = true;
            }
        }

        // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (dış incelemede bulundu, gerçek
        // testle kanıtlandı): Önceden cache hit olduğunda SADECE
        // `item->execute == nullptr` ise erken return ediliyordu — eğer
        // node'un bir execute callback'i varsa (ki gerçek node'ların hepsinde
        // vardır), cache hit TAMAMEN YOK SAYILIYORDU ve execute yine de
        // çağrılıyordu. Sonuç: cache mekanizması pratikte hiçbir zaman
        // gerçek bir hesaplama tasarrufu sağlamıyordu — her node, content
        // hash'i değişmemiş olsa bile, her seferinde yeniden execute
        // ediliyordu. Test edilip kanıtlandı: aynı (node, content_hash)
        // çiftiyle iki kez submit edilince execute iki kez de çağrılıyordu.
        //
        // Fix: cache_hit true ise execute'u ATLA — output_ptr zaten doğru
        // değere sahip (cache'ten). Sadece cache_hit false ise (gerçekten
        // hesaplanması gerekiyorsa) execute çağrılıyor.
        if (!cache_hit) {
            if (item->execute) {
                item->execute(item);
            } else {
                // No executor — just mark as completed
            }
            // [BRIDGE-DEV] NOT: execute_item BURADA sonucu otomatik cache'e
            // YAZMIYOR — bu bilinçli bir tasarım kararı, eksiklik değil.
            // İlk denemede (bu yorumun önceki hali) item->output_ptr'ı
            // doğrudan cache'e koymaya çalıştık, ama bu YANLIŞ bir varsayım
            // taşıyordu: output_ptr'ın her zaman malloc/new ile alınmış,
            // free() edilebilir bellek olduğunu varsaydı. Gerçek node'lar
            // output_ptr'ı statik bir değişkene, stack'e, ya da başka bir
            // veri yapısının içine işaret eden bir pointer'a set edebilir
            // — cache destructor'ı bu pointer'ları free() etmeye çalışınca
            // "free(): invalid size" ile GERÇEK BİR CRASH oluştu (gerçek
            // bir test ile yakalandı, bkz. BRIDGE_DSL_MERGE_GUIDE.md).
            //
            // Doğru tasarım — zaten var olan __bridge_scheduler_cache_store
            // API'sinde: bu fonksiyon malloc(output_size)+memcpy ile KENDİ
            // KOPYASINI alıyor, kullanıcının output_ptr'ını çalmıyor. Yani
            // cache'lemek isteyen bir execute callback'i KENDİSİ
            // __bridge_scheduler_cache_store'u çağırmalı (kendi output_size
            // bilgisiyle) — scheduler'ın bunu "tahmin ederek" otomatik
            // yapması güvenli değil, çünkü output_size bilgisi
            // BridgeWorkItem'da hiç taşınmıyor.
        } else {
            total_cached++;
        }

        uint64_t end_us = get_time_us();

        // Record
        BridgeExecRecord rec = {};
        rec.node_name = item->node_name;
        rec.node_id = item->node_id;
        rec.input_hash = item->content_hash;
        rec.duration_us = static_cast<uint32_t>(end_us - start_us);
        rec.result = BRIDGE_EXEC_OK;
        rec.final_state = BRIDGE_NODE_COMPLETED;
        rec.timestamp = end_us;

        {
            std::lock_guard<std::mutex> lock(records_mutex);
            records.push_back(rec);
            total_completed++;
        }
        completion_cv.notify_all();
    }
};

BridgeScheduler* __bridge_scheduler_create(const BridgeSchedulerConfig* config) {
    SchedulerImpl* impl = new SchedulerImpl(config);
    return reinterpret_cast<BridgeScheduler*>(impl);
}

BridgeDomainQueue* __bridge_scheduler_get_queue(BridgeScheduler* sched, BridgeDomain domain) {
    if (!sched) return nullptr;
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (dış incelemede bulundu): Önceden
    // bu fonksiyon HER ZAMAN nullptr döndürüyordu ("Implementation: return
    // domain-specific queue" yorumuyla, ama gerçek kod yoktu).
    // domain_queues map'i SchedulerImpl'de tanımlıydı, destructor'da
    // temizleniyordu, ama HİÇBİR YERDE doldurulmuyordu — domain-bazlı queue
    // routing (örn. GPU node'ları GPU domain queue'sunda, kernel-mode
    // node'ları kendi queue'sunda çalıştırma) tamamen devre dışıydı, tüm
    // node'lar tek bir global_queue üzerinden, domain ayrımı olmadan
    // işleniyordu.
    //
    // Fix: lazy-init deseni — bir domain için ilk kez get_queue çağrıldığında
    // gerçek bir DomainQueueImpl oluşturulup map'e ekleniyor; sonraki
    // çağrılar var olan instance'ı döndürüyor. Varsayılan config (1 thread)
    // kullanılıyor — eğer çağıran taraf farklı bir thread_count istiyorsa,
    // bunu BridgeQueueConfig parametresi ekleyen bir overload ile
    // sağlanması ileride değerlendirilmeli (header imzası şu an sadece
    // domain alıyor, bu pakette header'a yeni parametre eklenmedi —
    // geriye dönük uyumluluk için).
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->domain_queues_mutex);
    int key = static_cast<int>(domain);
    auto it = impl->domain_queues.find(key);
    if (it != impl->domain_queues.end()) {
        return reinterpret_cast<BridgeDomainQueue*>(it->second);
    }
    BridgeQueueConfig default_cfg = {};
    default_cfg.thread_count = 1;
    DomainQueueImpl* dq = new DomainQueueImpl(domain, &default_cfg);
    impl->domain_queues[key] = dq;
    return reinterpret_cast<BridgeDomainQueue*>(dq);
}

void __bridge_scheduler_destroy(BridgeScheduler* sched) {
    if (!sched) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    delete impl;
}

BridgeSchedulerState __bridge_scheduler_get_state(BridgeScheduler* sched) {
    if (!sched) return BRIDGE_SCHED_IDLE;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->state_mutex);
    return impl->state;
}

int __bridge_scheduler_start(BridgeScheduler* sched) {
    if (!sched) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    return impl->start();
}

int __bridge_scheduler_stop(BridgeScheduler* sched) {
    if (!sched) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    return impl->stop();
}

int __bridge_scheduler_pause(BridgeScheduler* sched) {
    if (!sched) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->state_mutex);
    impl->state = BRIDGE_SCHED_PAUSED;
    return 0;
}

int __bridge_scheduler_resume(BridgeScheduler* sched) {
    if (!sched) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->state_mutex);
    impl->state = BRIDGE_SCHED_RUNNING;
    return 0;
}

int __bridge_scheduler_submit(BridgeScheduler* sched, BridgeWorkItem* item) {
    if (!sched || !item) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    {
        std::lock_guard<std::mutex> lock(impl->global_mutex);
        impl->global_queue.push_back(item);
    }
    impl->global_cv.notify_one();
    impl->total_submitted++;
    return 0;
}

int __bridge_scheduler_submit_batch(BridgeScheduler* sched, BridgeWorkItem** items, uint32_t count) {
    if (!sched || !items || count == 0) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    {
        std::lock_guard<std::mutex> lock(impl->global_mutex);
        for (uint32_t i = 0; i < count; ++i) {
            impl->global_queue.push_back(items[i]);
        }
    }
    for (uint32_t i = 0; i < count; ++i) {
        impl->global_cv.notify_one();
    }
    impl->total_submitted += count;
    return 0;
}

void __bridge_scheduler_cancel(BridgeScheduler* sched, const char* node_name) {
    if (!sched || !node_name) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->global_mutex);
    // Remove all items for this node
    impl->global_queue.erase(
        std::remove_if(impl->global_queue.begin(), impl->global_queue.end(),
            [&](BridgeWorkItem* item) {
                return item && strcmp(item->node_name, node_name) == 0;
            }),
        impl->global_queue.end()
    );
}

int __bridge_scheduler_wait_node(BridgeScheduler* sched, const char* node_name, uint32_t timeout_ms) {
    if (!sched || !node_name) return -1;
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (dış incelemede bulundu, gerçek
    // testle kanıtlandı): Önceden bu fonksiyon std::this_thread::sleep_for
    // (10ms) ile busy-poll yapıyordu — her 10ms'de bir mutex alıp records
    // listesini tarıyordu. Bu hem gereksiz CPU tüketimi hem de en kötü
    // durumda 10ms'e kadar gecikme demekti (bir node tamamlandığı anda
    // haberdar olunmuyordu). Artık completion_cv ile gerçek koşullu
    // bekleme yapılıyor — bir item tamamlandığında execute_item içindeki
    // notify_all() bu bekleyişi anında uyandırıyor.
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);

    auto node_completed = [&]() {
        for (auto& rec : impl->records) {
            if (strcmp(rec.node_name, node_name) == 0 &&
                (rec.result == BRIDGE_EXEC_OK || rec.result == BRIDGE_EXEC_FAILED)) {
                return true;
            }
        }
        return false;
    };

    std::unique_lock<std::mutex> lock(impl->records_mutex);
    if (timeout_ms == 0) {
        // Süresiz bekleme — gerçek tamamlanana kadar uyu, hiç poll yok.
        impl->completion_cv.wait(lock, node_completed);
        return 0;
    }
    bool ok = impl->completion_cv.wait_for(lock,
        std::chrono::milliseconds(timeout_ms), node_completed);
    return ok ? 0 : -1; // Timeout
}

int __bridge_scheduler_wait_all(BridgeScheduler* sched, uint32_t timeout_ms) {
    if (!sched) return -1;
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX: Aynı düzeltme — busy-poll
    // (sleep_for 10ms) yerine completion_cv ile gerçek koşullu bekleme.
    // "Hepsi tamamlandı mı" sorusu hem global_queue boş hem submitted==
    // completed olduğunda doğru — bu kontrolü her notify_all'da yeniden
    // değerlendiriyoruz, 10ms'lik bir pencere içinde değil.
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);

    auto all_completed = [&]() {
        // global_queue'yu ayrı bir mutex (global_mutex) koruyor — burada
        // records_mutex altındayız, bu yüzden global_mutex'i de almamız
        // gerekiyor. Lock sıralaması: records_mutex önce alınmış (dıştaki
        // unique_lock), global_mutex burada try_lock ile değil, doğrudan
        // lock_guard ile alınıyor — bu sıralama execute_item'ın aldığı
        // sırayla TUTARLI OLMALI, aksi halde deadlock riski oluşur (bkz.
        // BRIDGE_DSL_MERGE_GUIDE.md'deki lock-ordering notu). execute_item
        // önce global_mutex'i (queue pop için) sonra records_mutex'i
        // (sonuç yazmak için) alıyor — burada TERS sırada (records_mutex
        // dıştan, global_mutex içten) almak klasik bir lock-ordering
        // ihlali olurdu. Bu yüzden global_queue.empty() kontrolünü
        // records_mutex DIŞINDA, ayrı bir global_mutex lock_guard'ı ile
        // yapıyoruz — ikisini iç içe almıyoruz.
        bool queue_empty;
        {
            std::lock_guard<std::mutex> qlock(impl->global_mutex);
            queue_empty = impl->global_queue.empty();
        }
        if (!queue_empty) return false;
        uint64_t submitted = impl->total_submitted.load();
        uint64_t completed = impl->total_completed.load();
        return submitted > 0 && submitted == completed;
    };

    std::unique_lock<std::mutex> lock(impl->records_mutex);
    if (timeout_ms == 0) {
        impl->completion_cv.wait(lock, all_completed);
        return 0;
    }
    bool ok = impl->completion_cv.wait_for(lock,
        std::chrono::milliseconds(timeout_ms), all_completed);
    return ok ? 0 : -1; // Timeout
}

/* ════════════════════════════════════════════════════════════════════════════
 * GIL Queue Operations
 * ════════════════════════════════════════════════════════════════════════════ */

int __bridge_scheduler_push_gil(BridgeScheduler* sched, BridgeWorkItem* item) {
    if (!sched || !item) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    {
        std::lock_guard<std::mutex> lock(impl->gil_mutex);
        impl->gil_queue.push_back(item);
    }
    impl->gil_cv.notify_one();
    return 0;
}

int __bridge_scheduler_pop_gil(BridgeScheduler* sched, BridgeWorkItem* item_out) {
    if (!sched || !item_out) return -1;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::unique_lock<std::mutex> lock(impl->gil_mutex);
    impl->gil_cv.wait(lock, [&] { return !impl->gil_queue.empty() || impl->shutdown; });
    if (impl->shutdown && impl->gil_queue.empty()) return -1;
    *item_out = *impl->gil_queue.front();
    impl->gil_queue.erase(impl->gil_queue.begin());
    return 0;
}

uint32_t __bridge_gil_queue_size(BridgeScheduler* sched) {
    if (!sched) return 0;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->gil_mutex);
    return static_cast<uint32_t>(impl->gil_queue.size());
}

/* ════════════════════════════════════════════════════════════════════════════
 * Cache Operations
 * ════════════════════════════════════════════════════════════════════════════ */

bool __bridge_scheduler_cache_hit(BridgeScheduler* sched, const char* node_name, uint64_t content_hash) {
    if (!sched || !node_name) return false;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    char key[256];
    snprintf(key, sizeof(key), "%s:%llu", node_name, (unsigned long long)content_hash);
    std::lock_guard<std::mutex> lock(impl->cache_mutex);
    return impl->cache.find(key) != impl->cache.end();
}

void __bridge_scheduler_cache_store(BridgeScheduler* sched, const char* node_name,
                                     uint64_t content_hash, void* output, uint32_t output_size) {
    if (!sched || !node_name || !output) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    char key[256];
    snprintf(key, sizeof(key), "%s:%llu", node_name, (unsigned long long)content_hash);
    std::lock_guard<std::mutex> lock(impl->cache_mutex);
    SchedulerImpl::CacheEntry entry;
    entry.data = malloc(output_size);
    memcpy(entry.data, output, output_size);
    entry.size = output_size;
    entry.timestamp = (uint64_t)std::chrono::steady_clock::now().time_since_epoch().count(); // [FIX 3.4]
    impl->cache[key] = entry;
}

void* __bridge_scheduler_cache_lookup(BridgeScheduler* sched, const char* node_name,
                                       uint64_t content_hash, uint32_t* output_size) {
    if (!sched || !node_name) return nullptr;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    char key[256];
    snprintf(key, sizeof(key), "%s:%llu", node_name, (unsigned long long)content_hash);
    std::lock_guard<std::mutex> lock(impl->cache_mutex);
    auto it = impl->cache.find(key);
    if (it != impl->cache.end()) {
        if (output_size) *output_size = it->second.size;
        return it->second.data;
    }
    return nullptr;
}

void __bridge_scheduler_cache_clear(BridgeScheduler* sched) {
    if (!sched) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->cache_mutex);
    for (auto& kv : impl->cache) {
        free(kv.second.data);
    }
    impl->cache.clear();
}

void __bridge_scheduler_cache_invalidate(BridgeScheduler* sched, const char* graph_name) {
    if (!sched) return;
    // Invalidate all cache entries for this graph
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->cache_mutex);
    for (auto& kv : impl->cache) {
        free(kv.second.data);
    }
    impl->cache.clear();
}

/* ════════════════════════════════════════════════════════════════════════════
 * Execution Records
 * ════════════════════════════════════════════════════════════════════════════ */

uint32_t __bridge_scheduler_get_record_count(BridgeScheduler* sched) {
    if (!sched) return 0;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->records_mutex);
    return static_cast<uint32_t>(impl->records.size());
}

BridgeExecRecord* __bridge_scheduler_get_records(BridgeScheduler* sched, uint32_t* out_count) {
    if (!sched || !out_count) return nullptr;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->records_mutex);
    *out_count = static_cast<uint32_t>(impl->records.size());
    return impl->records.data();
}

void __bridge_scheduler_clear_records(BridgeScheduler* sched) {
    if (!sched) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    std::lock_guard<std::mutex> lock(impl->records_mutex);
    impl->records.clear();
}

/* ════════════════════════════════════════════════════════════════════════════
 * Statistics
 * ════════════════════════════════════════════════════════════════════════════ */

void __bridge_scheduler_get_stats(BridgeScheduler* sched, BridgeSchedulerStats* out_stats) {
    if (!sched || !out_stats) return;
    auto* impl = reinterpret_cast<SchedulerImpl*>(sched);
    memset(out_stats, 0, sizeof(BridgeSchedulerStats));
    out_stats->total_submitted = impl->total_submitted.load();
    out_stats->total_completed = impl->total_completed.load();
    out_stats->total_failed = impl->total_failed.load();
    out_stats->total_cached = impl->total_cached.load();
    out_stats->total_retried = impl->total_retried.load();
    out_stats->total_timeout = impl->total_timeout.load();
    {
        std::lock_guard<std::mutex> lock(impl->global_mutex);
        out_stats->queued_count = static_cast<uint64_t>(impl->global_queue.size());
    }
    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (unused-code taraması ile bulundu —
    // get_stats hiçbir testte doğrudan çağrılmadığı için bu eksiklik fark
    // edilmemişti): active_count/avg_latency_us/max_latency_us/
    // total_wait_time_us önceden HİÇ hesaplanmıyordu, memset(0) ile sıfır
    // kalıyordu — bir monitoring/dashboard sistemi bu stats'a bakarsa
    // "ortalama gecikme 0us" gibi tamamen yanlış bir görüntü alırdı.
    //
    // active_count: submitted - completed - failed (şu an "uçuşta" olan iş
    // sayısı — kuyrukta bekleyen + şu an execute edilmekte olan).
    // avg_latency_us/max_latency_us: records listesindeki gerçek
    // duration_us değerlerinden hesaplanıyor (execute_item zaten her
    // tamamlanmada bunu kaydediyor).
    {
        uint64_t submitted = out_stats->total_submitted;
        uint64_t completed = out_stats->total_completed;
        uint64_t failed = out_stats->total_failed;
        out_stats->active_count = (submitted > completed + failed)
            ? (submitted - completed - failed) : 0;

        std::lock_guard<std::mutex> lock(impl->records_mutex);
        uint64_t sum_latency = 0;
        uint64_t max_latency = 0;
        uint64_t count = 0;
        for (auto& rec : impl->records) {
            sum_latency += rec.duration_us;
            if (rec.duration_us > max_latency) max_latency = rec.duration_us;
            count++;
        }
        out_stats->avg_latency_us = (count > 0) ? (sum_latency / count) : 0;
        out_stats->max_latency_us = max_latency;
        // [BRIDGE-DEV] total_wait_time_us KASITLI OLARAK 0 bırakılıyor —
        // bu alanın gerçek anlamı "submit'ten execute başlangıcına kadar
        // kuyrukta geçen süre" olmalı, ama BridgeWorkItem/BridgeExecRecord
        // hiçbir yerde "submit_time" damgası tutmuyor, sadece execute
        // başlangıcı (start_us) ve bitişi (end_us) ölçülüyor. Bu süreyi
        // sum_latency (işlenmiş süre) ile doldurmak YANLIŞ bir proxy olurdu
        // — "wait time" ile "execute time" farklı şeyler, birini diğeriyle
        // doldurmak gerçek veri yokken sahte bir sayı üretmekten farksız.
        // Doğru çözüm BridgeWorkItem'a bir submit_timestamp alanı eklemek
        // ve __bridge_scheduler_submit'te bunu doldurmak — bu, header'a
        // yeni alan eklemeyi gerektirdiği için bu pakette yapılmadı (bkz.
        // BRIDGE_DSL_MERGE_GUIDE.md bilinen sınırlamalar).
        out_stats->total_wait_time_us = 0;
    }
}

/* ════════════════════════════════════════════════════════════════════════════
 * Execution Plan Generation
 * ════════════════════════════════════════════════════════════════════════════ */

BridgeExecPlan* __bridge_scheduler_generate_plan(BridgeScheduler* sched, const BridgeGraph* g) {
    if (!g) return nullptr;

    BridgeExecPlan* plan = new BridgeExecPlan();
    memset(plan, 0, sizeof(BridgeExecPlan));
    plan->graph_name = g->name;

    // Analyze graph and generate execution plan
    plan->plan_node_count = g->node_count;
    plan->plan_nodes = new BridgeExecPlanNode[g->node_count];

    for (uint32_t i = 0; i < g->node_count; ++i) {
        const BridgeNode* n = &g->nodes[i];
        BridgeExecPlanNode* pn = &plan->plan_nodes[i];
        pn->node_name = n->name;
        pn->domain = n->domain;
        pn->priority = n->sched_hints.priority > 0 ?
            static_cast<BridgeSchedulerPriority>(n->sched_hints.priority) :
            BRIDGE_PRIORITY_NORMAL;
        pn->parallel_ok = n->sched_hints.parallel_ok;
        pn->latency_budget_us = n->sched_hints.max_latency_us;
        pn->estimated_duration_us = n->sched_hints.max_latency_us; // Estimate = budget
        pn->thread_id = 0; // Assigned during scheduling
        pn->depends_count = 0;

        // Find dependencies (incoming edges)
        for (uint32_t ei = 0; ei < g->edge_count && pn->depends_count < 8; ++ei) {
            if (strcmp(g->edges[ei].dst_node, n->name) == 0) {
                pn->depends_on[pn->depends_count++] = g->edges[ei].src_node;
            }
        }
    }

    // [BRIDGE-DEV] KRİTİK PRODUCTION FIX (unused-code taraması ile bulundu —
    // generate_plan hiçbir testte doğrudan çağrılmadığı için bu eksiklik
    // fark edilmemişti): plan->estimated_total_us ve plan->thread_count
    // önceden HİÇ hesaplanmıyordu, memset(0) ile sıfır kalıyordu.
    // __bridge_exec_plan_print bu alanları okuyup raporluyordu — yani
    // gerçek bir plan için (latency_budget'ları 500us/1000us olan 2 node)
    // rapor "Estimated Total: 0 us, Thread Count: 0" yazıyordu, tamamen
    // yanlış ve yanıltıcı bir özet.
    //
    // Hesaplama: estimated_total_us = paralel OLMAYAN node'ların
    // latency'lerinin toplamı + paralel olanların İÇİNDEKİ EN BÜYÜK latency
    // (basit bir "kritik yol" yaklaşımı — gerçek bir topological-sort/wave
    // analizi __bridge_graph_schedule'da zaten var, burada generate_plan
    // kendi bağımsız, daha basit bir tahmin üretiyor, bu bilinçli bir
    // tasarım kararı: exec plan'ın amacı hızlı bir özet vermek, tam bir
    // scheduling simülasyonu değil).
    // thread_count = en az 1, ve paralel çalışabilen node sayısına göre
    // (basit bir üst sınır — gerçek thread tahsisi scheduler'ın runtime
    // kararı, burada sadece "en az kaç thread gerekebilir" tahmini).
    {
        uint32_t sequential_sum = 0;
        uint32_t parallel_max = 0;
        uint32_t parallel_count = 0;
        for (uint32_t i = 0; i < plan->plan_node_count; ++i) {
            BridgeExecPlanNode* pn = &plan->plan_nodes[i];
            if (pn->parallel_ok) {
                parallel_count++;
                if (pn->estimated_duration_us > parallel_max) {
                    parallel_max = pn->estimated_duration_us;
                }
            } else {
                sequential_sum += pn->estimated_duration_us;
            }
        }
        plan->estimated_total_us = sequential_sum + parallel_max;
        plan->thread_count = parallel_count > 0 ? parallel_count : 1;
    }

    return plan;
}

void __bridge_exec_plan_destroy(BridgeExecPlan* plan) {
    if (!plan) return;
    delete[] plan->plan_nodes;
    delete plan;
}

void __bridge_exec_plan_print(const BridgeExecPlan* plan, FILE* out) {
    if (!plan || !out) return;
    fprintf(out, "Execution Plan: %s\n", plan->graph_name ? plan->graph_name : "(unnamed)");
    fprintf(out, "Estimated Total: %u us\n", plan->estimated_total_us);
    fprintf(out, "Thread Count: %u\n\n", plan->thread_count);

    for (uint32_t i = 0; i < plan->plan_node_count; ++i) {
        const BridgeExecPlanNode* pn = &plan->plan_nodes[i];
        fprintf(out, "  [%u] %s (domain=%u, priority=%u, parallel=%s)\n",
                i, pn->node_name ? pn->node_name : "(unnamed)",
                pn->domain, pn->priority, pn->parallel_ok ? "yes" : "no");
        fprintf(out, "      latency_budget=%u us, estimated=%u us, thread=%u\n",
                pn->latency_budget_us, pn->estimated_duration_us, pn->thread_id);
        if (pn->depends_count > 0) {
            fprintf(out, "      depends_on: ");
            for (uint32_t j = 0; j < pn->depends_count; ++j) {
                fprintf(out, "%s ", pn->depends_on[j] ? pn->depends_on[j] : "?");
            }
            fprintf(out, "\n");
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════════
 * Latency Constraint Solver (Bellman-Ford)
 * ════════════════════════════════════════════════════════════════════════════ */

BridgeLatencyAnalysis* __bridge_analyze_latency(const BridgeGraph* g) {
    if (!g) return nullptr;

    BridgeLatencyAnalysis* a = new BridgeLatencyAnalysis();
    memset(a, 0, sizeof(BridgeLatencyAnalysis));
    a->feasible = true;
    a->violation_count = 0;

    // Build adjacency list
    std::unordered_map<std::string, std::vector<std::pair<std::string, uint32_t>>> adj;
    std::unordered_map<std::string, uint32_t> node_latency;
    for (uint32_t ni = 0; ni < g->node_count; ++ni) {
        node_latency[g->nodes[ni].name] = g->nodes[ni].sched_hints.max_latency_us;
    }
    for (uint32_t ei = 0; ei < g->edge_count; ++ei) {
        const BridgeEdge* e = &g->edges[ei];
        uint32_t edge_latency = e->latency_budget_us > 0 ? e->latency_budget_us : 0;
        adj[e->src_node].push_back({e->dst_node, edge_latency});
    }

    // Bellman-Ford
    std::unordered_map<std::string, uint64_t> dist;
    for (uint32_t ni = 0; ni < g->node_count; ++ni) {
        dist[g->nodes[ni].name] = UINT64_MAX;
    }
    // Find source nodes (no incoming edges)
    for (uint32_t ni = 0; ni < g->node_count; ++ni) {
        bool is_source = true;
        for (uint32_t ei = 0; ei < g->edge_count; ++ei) {
            if (strcmp(g->edges[ei].dst_node, g->nodes[ni].name) == 0) {
                is_source = false;
                break;
            }
        }
        if (is_source) {
            dist[g->nodes[ni].name] = 0;
        }
    }

    // V-1 iterations
    for (uint32_t iter = 0; iter < g->node_count - 1; ++iter) {
        for (uint32_t ei = 0; ei < g->edge_count; ++ei) {
            const BridgeEdge* e = &g->edges[ei];
            uint32_t src_latency = node_latency[e->src_node];
            uint32_t edge_lat = e->latency_budget_us;
            uint64_t total_latency = src_latency + edge_lat;

            if (dist[e->src_node] != UINT64_MAX &&
                dist[e->src_node] + total_latency < dist[e->dst_node]) {
                dist[e->dst_node] = dist[e->src_node] + total_latency;
            }
        }
    }

    // Find longest and shortest paths
    a->longest_path_us = 0;
    a->shortest_path_us = UINT64_MAX;
    for (auto& kv : dist) {
        if (kv.second != UINT64_MAX) {
            if (kv.second > a->longest_path_us) a->longest_path_us = kv.second;
            if (kv.second < a->shortest_path_us) a->shortest_path_us = kv.second;
        }
    }
    if (a->shortest_path_us == UINT64_MAX) a->shortest_path_us = 0;

    return a;
}

void __bridge_latency_analysis_destroy(BridgeLatencyAnalysis* a) {
    if (!a) return;
    if (a->paths) delete[] a->paths;
    if (a->violations) delete[] a->violations;
    delete a;
}

/* ════════════════════════════════════════════════════════════════════════════
 * Determinism Analysis
 * ════════════════════════════════════════════════════════════════════════════ */

BridgeDeterminismTracker* __bridge_check_determinism(const BridgeGraph* g) {
    if (!g) return nullptr;

    BridgeDeterminismTracker* t = new BridgeDeterminismTracker();
    memset(t, 0, sizeof(BridgeDeterminismTracker));
    t->entire_graph_deterministic = true;

    for (uint32_t ni = 0; ni < g->node_count; ++ni) {
        const BridgeNode* n = &g->nodes[ni];
        int dl = static_cast<int>(n->determinism);

        if (dl <= 2) {
            t->deterministic_count++;
        } else {
            t->nondeterministic_count++;
            if (dl >= 4) t->entire_graph_deterministic = false;
        }

        // Check for mixed chains
        for (uint32_t ei = 0; ei < g->edge_count; ++ei) {
            if (strcmp(g->edges[ei].dst_node, n->name) == 0) {
                // Has upstream nodes — check for determinism conflict
            }
        }
    }

    return t;
}

void __bridge_determinism_destroy(BridgeDeterminismTracker* t) {
    if (!t) return;
    delete t;
}

} // namespace corelang::bridge