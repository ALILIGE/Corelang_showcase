/*
 * bridge_scheduler.h — Semantic Execution Scheduler
 *
 * [koprudsl.md §3] İki katmanlı scheduler:
 *   - Statik katman: compile-time graph analizi
 *   - Dinamik katman: runtime execution
 *
 * Work stealing queue, timeout/watchdog, retry policy, GIL queue management.
 */

#ifndef BRIDGE_SCHEDULER_H_INCLUDED
#define BRIDGE_SCHEDULER_H_INCLUDED

#include "bridge_graph.h"
#include "../runtime/bridge_runtime.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* ════════════════════════════════════════════════════════════════════════════
 * PART 1 — Scheduler Core Types
 * ════════════════════════════════════════════════════════════════════════════ */

// Scheduler state
typedef enum BridgeSchedulerState {
    BRIDGE_SCHED_IDLE      = 0,  // Başlatılmadı
    BRIDGE_SCHED_RUNNING   = 1,  // Çalışıyor
    BRIDGE_SCHED_PAUSED    = 2,  // Duraklatıldı
    BRIDGE_SCHED_STOPPING  = 3,  // Durduruluyor
    BRIDGE_SCHED_STOPPED   = 4,  // Durduruldu
} BridgeSchedulerState;

// Execution priority
typedef enum BridgeSchedulerPriority {
    BRIDGE_PRIORITY_LOW    = 0,
    BRIDGE_PRIORITY_NORMAL = 128,
    BRIDGE_PRIORITY_HIGH   = 200,
    BRIDGE_PRIORITY_CRITICAL = 255,
} BridgeSchedulerPriority;

// Work item — scheduler'a verilen görev
typedef struct BridgeWorkItem {
    const char*        node_name;     // Node adı
    uint64_t           node_id;       // Node ID (content-addressed)
    uint64_t           content_hash;  // Input content hash
    void*              input_ptr;     // Input data pointer
    uint32_t           input_size;    // Input data size
    void*              output_ptr;    // Output data pointer (nullable)
    void*              output_hint;   // Output allocation hint
    BridgeSchedulerPriority priority; // Çalışma önceliği
    uint64_t           deadline_us;   // Deadline (microsecond, 0 = no deadline)
    void*              user_data;     // User callback data
    void (*execute)(struct BridgeWorkItem*); // Execute callback
    void (*cleanup)(struct BridgeWorkItem*);  // Cleanup callback
} BridgeWorkItem;

// Execution result
typedef enum BridgeExecResult {
    BRIDGE_EXEC_OK       = 0,   // Başarılı
    BRIDGE_EXEC_FAILED   = 1,   // Hata verdi
    BRIDGE_EXEC_TIMEOUT  = 2,   // Süre aşıldı
    BRIDGE_EXEC_CANCELLED= 3,   // İptal edildi
    BRIDGE_EXEC_RETRY    = 4,   // Yeniden denenmeli
    BRIDGE_EXEC_CACHE_HIT= 5,   // Cache'den geldi
} BridgeExecResult;

// Execution record — bir node'un çalışma kaydı
typedef struct BridgeExecRecord {
    const char*         node_name;
    uint64_t            node_id;
    uint64_t            input_hash;
    uint64_t            output_hash;
    BridgeExecResult    result;
    uint32_t            duration_us;
    uint32_t            attempt_count;
    BridgeNodeState      final_state;
    BridgeForeignError   error;
    uint64_t             timestamp;
} BridgeExecRecord;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 2 — Domain Execution Queue (Work Stealing Pattern)
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §3] Her execution domain kendi queue'su:
//   - Kernel domain queue → IRQ thread (özel)
//   - Scripting domain queue → 1 thread (GIL sebebiyle)
//   - Native domain queue → N thread (paralel)
 */

// Domain queue handle
typedef struct BridgeDomainQueue BridgeDomainQueue;

// Domain queue configuration
typedef struct BridgeQueueConfig {
    BridgeDomain         domain;        // Hangi domain için
    uint32_t             thread_count; // Thread sayısı (0 = auto)
    uint32_t             queue_capacity; // Maksimum queue boyutu
    bool                  gil_ordered;  // GIL sıralı erişim gerekiyor mu?
    uint32_t             steal_batch;  // Steal batch size
} BridgeQueueConfig;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 3 — Scheduler Configuration
 * ════════════════════════════════════════════════════════════════════════════ */

// Scheduler configuration
typedef struct BridgeSchedulerConfig {
    // Thread pool
    uint32_t             native_threads;   // Native domain thread sayısı
    uint32_t             max_concurrent;  // Maksimum eşzamanlı çalışma

    // Timeout
    uint32_t             default_timeout_ms; // Varsayılan timeout
    uint32_t             watchdog_interval_ms; // Watchdog kontrol interval

    // GIL queue
    uint32_t             gil_queue_capacity; // GIL queue boyutu
    uint32_t             gil_timeout_ms;      // GIL acquire timeout

    // Retry
    bool                  enable_retry;        // Retry aktif mi?
    uint32_t             max_retry_attempts;   // Maksimum retry

    // Cache
    bool                  enable_cache;        // Cache aktif mi?
    uint32_t             cache_max_entries;    // Maksimum cache entry

    // Observability
    bool                  enable_execution_log; // Execution log açık mı?
    const char*          log_path;             // Log dosya yolu

    // Domain queues
    uint32_t             queue_config_count;
    BridgeQueueConfig*   queue_configs;
} BridgeSchedulerConfig;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 4 — Scheduler Handle
 * ════════════════════════════════════════════════════════════════════════════ */

// Scheduler handle — ana scheduler nesnesi
typedef struct BridgeScheduler BridgeScheduler;

/* ════════════════════════════════════════════════════════════════════════════
 * PART 5 — Scheduler API
 * ════════════════════════════════════════════════════════════════════════════
 * [BRIDGE-DEV] KRİTİK PRODUCTION FIX: Bu bölümdeki TÜM fonksiyonlar (21 adet)
 * önceden global scope'ta declare ediliyordu ama bridge_scheduler.cpp'deki
 * TANIMLARIN HEPSİ `namespace corelang::bridge { ... }` içinde. Bu, daha önce
 * bridge_graph.h ve bridge_incident.h'da bulunan ve düzeltilen aynı kalıbın
 * üçüncü tekrarı — sadece burada etkilenen yüzey daha büyük (tüm scheduler
 * API'si, BridgeScheduler::create/start/stop/submit/wait dahil).
 *
 * Önceki haliyle: bu dosyanın dışından (örn. main.cpp, ya da bir test) HİÇBİR
 * scheduler fonksiyonu çağrılamıyordu — link hatası garanti. Scheduler'ın
 * kendi iç implementasyonu (reinterpret_cast<SchedulerImpl*>(sched) deseni)
 * BridgeScheduler'ın forward-declared (incomplete type) bir opak handle
 * olması sayesinde TİP GÜVENLİ (Pimpl pattern, BridgeGraph/BridgeIncidentDB'
 * deki gerçek struct-confusion'dan farklı, doğru bir kullanım) — düzeltilmesi
 * gereken SADECE namespace bağlantısıydı, internal reinterpret_cast'lere
 * dokunulmadı.
 */
namespace corelang::bridge {

// ── Lifecycle ───────────────────────────────────────────────────────────────────
BridgeScheduler* __bridge_scheduler_create(const BridgeSchedulerConfig* config);
void             __bridge_scheduler_destroy(BridgeScheduler* sched);
BridgeSchedulerState __bridge_scheduler_get_state(BridgeScheduler* sched);

// ── Work submission ───────────────────────────────────────────────────────────────
int  __bridge_scheduler_submit(BridgeScheduler* sched, BridgeWorkItem* item);
int  __bridge_scheduler_submit_batch(BridgeScheduler* sched, BridgeWorkItem** items, uint32_t count);
void __bridge_scheduler_cancel(BridgeScheduler* sched, const char* node_name);

// ── Execution control ────────────────────────────────────────────────────────────
int  __bridge_scheduler_start(BridgeScheduler* sched);
int  __bridge_scheduler_stop(BridgeScheduler* sched);
int  __bridge_scheduler_pause(BridgeScheduler* sched);
int  __bridge_scheduler_resume(BridgeScheduler* sched);

// ── Waiting ──────────────────────────────────────────────────────────────────────
int  __bridge_scheduler_wait_node(BridgeScheduler* sched, const char* node_name, uint32_t timeout_ms);
int  __bridge_scheduler_wait_all(BridgeScheduler* sched, uint32_t timeout_ms);

// ── GIL queue operations ─────────────────────────────────────────────────────────
// [koprudsl.md §3] Python GIL için single-threaded queue
int  __bridge_scheduler_push_gil(BridgeScheduler* sched, BridgeWorkItem* item);
int  __bridge_scheduler_pop_gil(BridgeScheduler* sched, BridgeWorkItem* item_out);
uint32_t __bridge_gil_queue_size(BridgeScheduler* sched);

// ── Cache operations ─────────────────────────────────────────────────────────────
bool __bridge_scheduler_cache_hit(BridgeScheduler* sched, const char* node_name, uint64_t content_hash);
void __bridge_scheduler_cache_store(BridgeScheduler* sched, const char* node_name,
                                    uint64_t content_hash, void* output, uint32_t output_size);
void* __bridge_scheduler_cache_lookup(BridgeScheduler* sched, const char* node_name,
                                       uint64_t content_hash, uint32_t* output_size);
void __bridge_scheduler_cache_invalidate(BridgeScheduler* sched, const char* graph_name);
// [BRIDGE-DEV] KRİTİK PRODUCTION FIX (unused-code taraması ile bulundu):
// Bu iki fonksiyon .cpp'de tanımlıydı ama header'da HİÇ declare edilmemişti
// — önceki namespace düzeltme geçişinde (v3) gözden kaçmıştı. Sonuç: bu
// dosyanın dışından (bridge_scheduler.cpp'nin kendisi dışında) hiçbiri
// çağrılamıyordu. __bridge_scheduler_cache_clear, cache testleri yazılırken
// gerçek bir test senaryosunda ihtiyaç duyulup eksikliği fark edildi.
void __bridge_scheduler_cache_clear(BridgeScheduler* sched);
BridgeDomainQueue* __bridge_scheduler_get_queue(BridgeScheduler* sched, BridgeDomain domain);

// [BRIDGE-DEV] KRİTİK PRODUCTION FIX (sistematik header/cpp sembol
// karşılaştırmasıyla bulundu): __bridge_scheduler_get_queue bir
// BridgeDomainQueue* döndürüyor, ama bu handle üzerinde çalışan dört
// fonksiyon (push/pop/size/is_empty) header'da hiç declare edilmemişti —
// get_queue'yu çağırmanın HİÇBİR PRATİK FAYDASI YOKTU çünkü döndürdüğü
// handle'ı hiçbir public fonksiyonla kullanamıyordunuz.
int      __bridge_domain_queue_push(BridgeDomainQueue* q, BridgeWorkItem* item);
int      __bridge_domain_queue_pop(BridgeDomainQueue* q, BridgeWorkItem* item_out);
uint32_t __bridge_domain_queue_size(BridgeDomainQueue* q);
bool     __bridge_domain_queue_is_empty(BridgeDomainQueue* q);

// ── Execution records ────────────────────────────────────────────────────────────
uint32_t __bridge_scheduler_get_record_count(BridgeScheduler* sched);
BridgeExecRecord* __bridge_scheduler_get_records(BridgeScheduler* sched, uint32_t* out_count);
void __bridge_scheduler_clear_records(BridgeScheduler* sched);

// ── Statistics ──────────────────────────────────────────────────────────────────
typedef struct BridgeSchedulerStats {
    uint64_t            total_submitted;
    uint64_t            total_completed;
    uint64_t            total_failed;
    uint64_t            total_cached;
    uint64_t            total_retried;
    uint64_t            total_timeout;
    uint64_t            active_count;
    uint64_t            queued_count;
    uint64_t            avg_latency_us;
    uint64_t            max_latency_us;
    uint64_t            total_wait_time_us;
} BridgeSchedulerStats;

void __bridge_scheduler_get_stats(BridgeScheduler* sched, BridgeSchedulerStats* out_stats);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 6 — Execution Plan Visualization
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §3] Build sonrası scheduler topology gösterimi:
//   CPU Thread Pool:
//     ├── MotionPlanner
//     ├── Telemetry
//     └── SafetyChecks
//   Realtime Core:
//     ├── LidarInput
//     └── BrakeController
 */

// Execution plan node
typedef struct BridgeExecPlanNode {
    const char*         node_name;
    BridgeDomain        domain;
    BridgeSchedulerPriority priority;
    uint32_t            thread_id;
    bool                 parallel_ok;
    uint32_t            latency_budget_us;
    uint32_t            estimated_duration_us;
    const char*         depends_on[8];
    uint32_t            depends_count;
} BridgeExecPlanNode;

// Execution plan
typedef struct BridgeExecPlan {
    const char*         graph_name;
    uint32_t            plan_node_count;
    BridgeExecPlanNode* plan_nodes;
    uint32_t            thread_count;
    uint32_t            estimated_total_us;
} BridgeExecPlan;

// ── API: Plan generation ─────────────────────────────────────────────────────────
BridgeExecPlan* __bridge_scheduler_generate_plan(BridgeScheduler* sched, const BridgeGraph* g);
void            __bridge_exec_plan_destroy(BridgeExecPlan* plan);
void            __bridge_exec_plan_print(const BridgeExecPlan* plan, FILE* out);

} // namespace corelang::bridge

/* ════════════════════════════════════════════════════════════════════════════
 * PART 7 — Latency Constraint Solver
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §4] Bellman-Ford tabanlı latency analizi
 */

// Latency path — bir yolun latency bilgisi
typedef struct BridgeLatencyPath {
    const char*         path_name;
    uint32_t            path_length;
    const char**        nodes;
    uint64_t            total_latency_us;
    uint64_t            critical_path_us; // En uzun yol
    uint32_t            bottleneck_node_index;
} BridgeLatencyPath;

// Latency analysis result
typedef struct BridgeLatencyAnalysis {
    bool                 feasible;        // Tüm constraint'ler karşılanabilir mi?
    uint64_t            longest_path_us; // En uzun path
    uint64_t            shortest_path_us;// En kısa path
    uint32_t            path_count;
    BridgeLatencyPath*  paths;
    uint32_t            violation_count;
    const char**        violations;       // Hangi constraint'ler ihlal edildi
} BridgeLatencyAnalysis;

// ── API: Latency analysis ─────────────────────────────────────────────────────────
// [BRIDGE-DEV] Aynı namespace düzeltmesi — bu 4 fonksiyon da .cpp'de
// corelang::bridge içinde tanımlı, header'da declare edilmemişti.
namespace corelang::bridge {

BridgeLatencyAnalysis* __bridge_analyze_latency(const BridgeGraph* g);
void __bridge_latency_analysis_destroy(BridgeLatencyAnalysis* a);

} // namespace corelang::bridge

/* ════════════════════════════════════════════════════════════════════════════
 * PART 8 — Deterministic Scheduling
 * ════════════════════════════════════════════════════════════════════════════
// [koprudsl.md §3] Deterministic node işaretleme:
//   deterministic: true → cache eligible, replay eligible
//   deterministic: false → loglanır, replay'de feed edilir
 */

// Determinism tracker
typedef struct BridgeDeterminismTracker {
    uint64_t            deterministic_count;
    uint64_t            nondeterministic_count;
    uint64_t            mixed_chain_count;
    bool                 entire_graph_deterministic; // Tüm graph deterministik mi?
} BridgeDeterminismTracker;

// ── API: Determinism analysis ────────────────────────────────────────────────────
namespace corelang::bridge {

BridgeDeterminismTracker* __bridge_check_determinism(const BridgeGraph* g);
void __bridge_determinism_destroy(BridgeDeterminismTracker* t);

} // namespace corelang::bridge

#endif /* BRIDGE_SCHEDULER_H_INCLUDED */