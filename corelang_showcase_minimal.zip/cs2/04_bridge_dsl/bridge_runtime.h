/*
 * bridge_runtime.h — CoreLang Köprü DSL Runtime Header
 *
 * [koprudsl.md §2] CoreSemanticABI — Dil bağımsız semantic bridge layer
 * Her runtime önce ortak semantic modele normalize edilir:
 *   Python ↔ CoreSemanticABI ↔ Rust ↔ CoreSemanticABI ↔ C
 *
 * Bu header, compiler tarafından üretilen IR'den ve runtime tarafından
 * kullanılan C kodundan include edilebilir olmalı.
 */

#ifndef BRIDGE_RUNTIME_H_INCLUDED
#define BRIDGE_RUNTIME_H_INCLUDED

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ════════════════════════════════════════════════════════════════════════════
 * PART 1 — CoreSemanticABI (koprudsl.md §2)
 *
 * Canonical semantic bridge layer — tüm runtime'lar buna normalize edilir.
 * Binary ABI değil, semantic ABI.
 * ════════════════════════════════════════════════════════════════════════════ */

// Ownership category — bellek sahipliği kategorileri
// [koprudsl.md §1] Her dil farklı sahiplik kuralına sahip
typedef enum BridgeOwnership {
    BRIDGE_OWNED       = 0,  // CoreLang heap allocation, tek sahip
    BRIDGE_BORROWED    = 1,  // Başka sahip tarafından sağlanan referans
    BRIDGE_SHARED      = 2,  // GC/ARC tarafından yönetilen çoklu sahiplik
    BRIDGE_EXTERNAL    = 3,  // Manuel free gerektiren dış bellek
    BRIDGE_GC_OWNED    = 4,  // Python/JVM/Go GC tarafından sahiplenilen
    BRIDGE_PINNED      = 5,  // GC taşıması engellenmiş buffer
    BRIDGE_ARC_SHARED  = 6,  // Rust Arc<T> gibi paylaşımlı sahiplik
} BridgeOwnership;

// Error model — hata modeli kategorileri
// [koprudsl.md §2] C errno, Rust Result/panic, Python exception
typedef enum BridgeErrorModel {
    BRIDGE_ERR_RESULT       = 0,  // CoreLang/Rust Result<T,E>
    BRIDGE_ERR_PANIC        = 1,  // Rust panic (catch_unwind ile yakalanır)
    BRIDGE_ERR_C_ERRNO     = 2,  // C errno
    BRIDGE_ERR_CPP_EXC      = 3,  // C++ exception
    BRIDGE_ERR_PYTHON_EXC   = 4,  // Python exception hierarchy
    BRIDGE_ERR_GO_PANIC     = 5,  // Go panic/defer/recover
    BRIDGE_ERR_SIGNAL       = 6,  // UNIX signal
    BRIDGE_ERR_NONE         = 7,  // No-failure
} BridgeErrorModel;

// Async model — async çalışma modeli kategorileri
// [koprudsl.md §2] Python asyncio, Rust Tokio, CoreLang scheduler
typedef enum BridgeAsyncModel {
    BRIDGE_ASYNC_SYNC           = 0,  // Blocking senkron
    BRIDGE_ASYNC_PYTHON_ASYNCIO = 1,  // Python asyncio (tek thread, GIL)
    BRIDGE_ASYNC_RUST_TOKIO     = 2,  // Tokio runtime (multi-thread)
    BRIDGE_ASYNC_CORELANG_FUTURE= 3,  // CoreLang Future
    BRIDGE_ASYNC_THREAD_POOL    = 4,  // Blocking thread pool
} BridgeAsyncModel;

// Execution domain — çalışma domain kategorileri
// [koprudsl.md §1] Her node aynı dünyada yaşamaz
typedef enum BridgeDomain {
    BRIDGE_DOMAIN_NATIVE_CPU    = 0,  // Native compute
    BRIDGE_DOMAIN_SCRIPTING     = 1,  // Python GIL, Ruby, Lua
    BRIDGE_DOMAIN_GPU_COMPUTE   = 2,  // CUDA, Vulkan
    BRIDGE_DOMAIN_KERNEL_MODE  = 3,  // Bare-metal kernel
    BRIDGE_DOMAIN_EMBEDDED_RT   = 4,  // Embedded realtime
    BRIDGE_DOMAIN_EXTERNAL_PROC = 5,  // External process
    BRIDGE_DOMAIN_NETWORK_IO    = 6,  // Network socket
    BRIDGE_DOMAIN_UNSAFE_BLOCK  = 7,  // Unsafe block
} BridgeDomain;

// Thread safety guarantees
typedef enum BridgeThreadSafety {
    BRIDGE_THREAD_SAFE     = 0,  // Tam thread-safe
    BRIDGE_THREAD_UNSAFE    = 1,  // Thread-safe değil
    BRIDGE_THREAD_GIL_SAFE = 2,  // GIL koruması altında (Python)
} BridgeThreadSafety;

// Determinism level — belirlenimcilik seviyeleri
// [koprudsl.md §3] Boolean determinism yetmez! 5 seviye var.
typedef enum BridgeDeterminism {
    BRIDGE_DET_STRONG      = 0,  // Aynı input → her zaman aynı output
    BRIDGE_DET_TEMPORAL    = 1,  // Aynı zaman koşullarında aynı
    BRIDGE_DET_PROBABILISTIC= 2, // RNG seed aynıysa aynı
    BRIDGE_DET_SCHEDULER   = 3,  // Thread order sabitse aynı
    BRIDGE_DET_IO          = 4,  // Dış dünya sabitse aynı
    BRIDGE_DET_NONDET      = 5, // Hiçbir koşul sabit değil
} BridgeDeterminism;

// GC managed — GC tarafından yönetiliyor mu?
typedef enum BridgeGCMode {
    BRIDGE_GC_NONE       = 0,  // GC yok, manuel memory management
    BRIDGE_GC_MANAGED    = 1,  // GC tarafından yönetilen heap
    BRIDGE_GC_PINNED     = 2,  // GC koruması altında ama pinned
} BridgeGCMode;

// ── CoreSemanticABI — Canonical Bridge Normalization ────────────────────────────
// [koprudsl.md §2] Bütün runtime'lar önce ortak semantic modele normalize edilir.
// Bu yapı, bridge IR üretirken metadata taşır.
typedef struct BridgeCanonicalABI {
    BridgeOwnership     ownership;       // Bellek sahipliği kategorisi
    BridgeErrorModel   error_model;      // Hata modeli
    BridgeAsyncModel   async_model;      // Async model
    BridgeThreadSafety thread_safety;    // Thread safety garantisi
    BridgeGCMode       gc_managed;       // GC yönetimi var mı?
    BridgeDeterminism  determinism;       // Belirlenimcilik seviyesi
    BridgeDomain       source_domain;    // Kaynak domain
    BridgeDomain       target_domain;    // Hedef domain
    bool               may_block;        // Blocking I/O yapabilir mi?
    bool               may_alloc_heap;   // Heap allocation yapabilir mi?
    bool               may_throw;        // Exception/panic üretebilir mi?
    uint32_t           max_latency_us;   // Maksimum latency (microsecond)
    uint32_t           version_min;      // Minimum runtime versiyonu
    uint32_t           version_max;      // Maksimum runtime versiyonu
} BridgeCanonicalABI;

/* ── API: Canonical ABI factory fonksiyonları ──────────────────────────────── */
// [koprudsl.md §2] Her dil için canonical descriptor üret
const BridgeCanonicalABI* bridge_python_canonical(void);
const BridgeCanonicalABI* bridge_rust_canonical(bool has_panic, bool is_async);
const BridgeCanonicalABI* bridge_c_canonical(void);
const BridgeCanonicalABI* bridge_corelang_canonical(void);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 2 — Python Exception Hierarchy → ForeignError Normalization
 *
 * [koprudsl.md §2] KeyboardInterrupt ve SystemExit özel —
 * process seviyesinde ayrı tutulmalı.
 * ════════════════════════════════════════════════════════════════════════════ */

// Foreign error kind — tüm dillerdeki hataları normalize eden enum
typedef enum BridgeForeignErrorKind {
    BRIDGE_FE_C_ERRNO       = 0,  // C errno
    BRIDGE_FE_C_SIGNAL      = 1,  // UNIX signal
    BRIDGE_FE_RUST_PANIC    = 2,  // Rust panic (catch_unwind)
    BRIDGE_FE_PY_VALUE      = 3,  // Python ValueError
    BRIDGE_FE_PY_TYPE       = 4,  // Python TypeError
    BRIDGE_FE_PY_RUNTIME    = 5,  // Python RuntimeError
    BRIDGE_FE_PY_MEMORY     = 6,  // Python MemoryError
    BRIDGE_FE_PY_KEYBOARD   = 7,  // Python KeyboardInterrupt (PROCESS SEVİYESİNDE!)
    BRIDGE_FE_PY_SYSTEM     = 8,  // Python SystemExit (PROCESS SEVİYESİNDE!)
    BRIDGE_FE_PY_OTHER      = 9,  // Diğer Python exception
    BRIDGE_FE_TYPE_MISMATCH = 10, // Bridge type check failure
    BRIDGE_FE_VERSION_MISMATCH= 11, // Runtime versiyon uyuşmazlığı
    BRIDGE_FE_GIL_TIMEOUT   = 12, // GIL acquisition timeout
    BRIDGE_FE_QUEUE_FULL    = 13, // Scripting queue dolu
    BRIDGE_FE_TIMEOUT       = 14, // Node execution timeout
    BRIDGE_FE_UNKNOWN       = 15, // Bilinmeyen hata
} BridgeForeignErrorKind;

// Normalized foreign error structure — tüm hata tiplerini taşır
typedef struct BridgeForeignError {
    BridgeForeignErrorKind kind;  // Hata kategorisi
    int32_t                code;  // errno değeri, exception code, vb.
    char                   msg[256]; // Human-readable mesaj
    char                   source_func[64]; // Hangi fonksiyonda oldu
    uint64_t               timestamp_us; // Timestamp (microsecond)
} BridgeForeignError;

// ── API: Foreign error normalization ───────────────────────────────────────────
void __bridge_foreign_error_from_errno(BridgeForeignError* out);
void __bridge_foreign_error_from_rust_panic(BridgeForeignError* out, const char* panic_msg);
void __bridge_foreign_error_from_python(BridgeForeignError* out);
// [BRIDGE-DEV] KRİTİK PRODUCTION FIX: __bridge_python_exc_fetch önceden
// header'da hiç declare edilmemişti, ama src/irgen/archive/irgen_dsl_LEGACY.cpp
// içinde IRGen'in bu sembolü `extern` olarak LLVM IR'a gömdüğü görülüyor —
// yani bu, derleyicinin ürettiği koddan çağrılması beklenen GERÇEK bir
// public API, sadece header'a eklenmesi unutulmuş. __bridge_foreign_error_
// from_python zaten bunu internal olarak kullanıyor, ama IRGen'in
// doğrudan çağırabilmesi için header'da görünür olması gerekiyor.
// kind_out → BridgeForeignErrorKind ile uyumlu int kodlama (bkz. .c
// implementasyonundaki BRIDGE_FE_PY_* sabit kullanımı).
int __bridge_python_exc_fetch(int* kind_out, char* msg_buf, int msg_len);
void __bridge_foreign_error_clear(BridgeForeignError* out);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 3 — Execution Log Serialization (32-byte binary records)
 *
 * [koprudsl.md §3] Graph trace — stack trace değil, sistem davranış geçmişi.
 * ════════════════════════════════════════════════════════════════════════════ */

// Log record type
typedef enum BridgeLogType {
    BRIDGE_LOG_NODE_START  = 0,  // Node çalışmaya başladı
    BRIDGE_LOG_NODE_END    = 1,  // Node tamamlandı (success veya fail)
    BRIDGE_LOG_EDGE_FIRE   = 2,  // Edge ateşlendi (data transfer)
    BRIDGE_LOG_ERROR       = 3,  // Error/exception kaydedildi
    BRIDGE_LOG_REPLAY_MARK = 4,  // Replay marker
} BridgeLogType;

// 32-byte execution log record — content-addressed
// name_hash = FNV-1a(node_name), content_hash = FNV-1a(output)
#define BRIDGE_LOG_MAGIC 0x0B2024ED5u
typedef struct BridgeLogRecord {
    uint32_t              magic;       // Magic number (validation)
    uint32_t              seq;         // Sıra numarası (artıyor)
    uint32_t              time_ms;     // Göreceli zaman (ms)
    BridgeLogType         type;        // Record tipi
    uint32_t              name_hash;   // Node name FNV-1a hash
    uint8_t               state_or_code;// Node state (NODE_END) veya error code (ERROR)
    uint8_t               padding[3];  // Alignment
    uint64_t              content_hash;// Output content FNV-1a hash
} BridgeLogRecord;
#ifdef __cplusplus
static_assert(sizeof(BridgeLogRecord) == 32, "BridgeLogRecord must be 32 bytes");
#else
_Static_assert(sizeof(BridgeLogRecord) == 32, "BridgeLogRecord must be 32 bytes");
#endif

/* ── API: Execution log ────────────────────────────────────────────────────── */
void __bridge_log_open(const char* log_path);
void __bridge_log_close(void);
void __bridge_log_node_start(const char* node_name, uint64_t content_hint);
void __bridge_log_node_end(const char* node_name, uint64_t content_hash, uint8_t final_state);
void __bridge_log_edge_fire(const char* src_name, const char* dst_name);
void __bridge_log_error(const char* node_name, uint8_t error_code);

/* ── API: Replay ────────────────────────────────────────────────────────────── */
int  __bridge_replay_read(const char* log_path,
                          BridgeLogRecord* records_out,
                          int max_records);
void __bridge_replay_print(const char* log_path);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 4 — Node State Tracker
 *
 * [koprudsl.md §3] Graph çalışırken node durumları — VEE snapshot'ında saklanır.
 * ════════════════════════════════════════════════════════════════════════════ */

// Node execution state
typedef enum BridgeNodeState {
    BRIDGE_NODE_PENDING    = 0,  // Bağımlılıkları henüz bitmedi
    BRIDGE_NODE_READY      = 1,  // Çalışabilir, queue'da bekliyor
    BRIDGE_NODE_RUNNING    = 2,  // Aktif çalışıyor
    BRIDGE_NODE_COMPLETED  = 3,  // Bitti, output hazır
    BRIDGE_NODE_FAILED     = 4,  // Hata verdi
    BRIDGE_NODE_CACHED     = 5,  // Önceki run'dan cache'de
    BRIDGE_NODE_TIMEOUT    = 6,  // Süre aşıldı
    BRIDGE_NODE_CANCELLED  = 7,  // İptal edildi
} BridgeNodeState;

/* ── API: Node state management ────────────────────────────────────────────── */
void  __bridge_node_set_state(const char* node_name, uint8_t state);
uint8_t __bridge_node_get_state(const char* node_name);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 5 — ScriptingRuntime GIL Queue (MPSC pattern)
 *
 * [koprudsl.md §3] Python GIL için scheduler single-threaded queue kuruyor.
 * ════════════════════════════════════════════════════════════════════════════ */

// Queue item — Python callable + arguments
typedef struct BridgeGILQueueItem {
    void*      callable;     // Python callable object
    void**     args;         // Argument array
    int        arg_count;     // Argument count
    void*      result_out;   // Result output pointer (nullable)
    bool*      success_out;  // Success flag pointer (nullable)
    void (*cleanup)(void*);  // Cleanup callback for args
} BridgeGILQueueItem;

/* ── API: GIL Queue ────────────────────────────────────────────────────────── */
void __bridge_gil_queue_init(void);
void __bridge_gil_queue_push(BridgeGILQueueItem* item);
bool __bridge_gil_queue_pop(BridgeGILQueueItem* item_out);
void __bridge_gil_queue_shutdown(void);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 6 — Version Constraint Checking
 *
 * [koprudsl.md §1] Kontrat versiyonlama — runtime versiyonu kontrolü.
 * ════════════════════════════════════════════════════════════════════════════ */

// Version check result
typedef enum BridgeVersionCheckResult {
    BRIDGE_VER_OK           = 0,  // Versiyon uygun
    BRIDGE_VER_TOO_LOW      = 1,  // Minimum versiyon altında
    BRIDGE_VER_TOO_HIGH     = 2,  // Maksimum versiyon üstünde
    BRIDGE_VER_INVALID      = -1, // Geçersiz versiyon string
} BridgeVersionCheckResult;

/* ── API: Version constraint ───────────────────────────────────────────────── */
BridgeVersionCheckResult __bridge_version_check(const char* runtime_ver,
                                                  const char* min_ver,
                                                  const char* max_ver);
void __bridge_version_abort(const char* msg, int code) __attribute__((noreturn));

/* ════════════════════════════════════════════════════════════════════════════
 * PART 7 — C errno Bridge
 *
 * [koprudsl.md §2] C errno → Result<T,E> normalizasyonu.
 * ════════════════════════════════════════════════════════════════════════════ */
void __bridge_c_errno_clear(void);
int  __bridge_c_errno_get(void);
void __bridge_c_strerror(int err, char* buf, size_t bufsize);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 8 — PinnedBuffer (Buffer Protocol Wrapper)
 *
 * [koprudsl.md §2] Python buffer protocol ile GC taşıma sorunu çözümü.
 * ════════════════════════════════════════════════════════════════════════════ */

// Pinned buffer handle — GC bu belleği taşımayacak
typedef struct BridgePinnedBuffer {
    void*      data_ptr;     // Pointer to data
    size_t     data_len;     // Data length in bytes
    int        item_count;   // Number of items
    int        item_size;    // Size of each item
    void*      owner;        // Owner Python object (for decref)
    void (*release)(struct BridgePinnedBuffer*); // Release function
} BridgePinnedBuffer;

/* ── API: Pinned buffer ────────────────────────────────────────────────────── */
BridgePinnedBuffer* __bridge_python_buffer_pin(void* py_obj);
void                 __bridge_python_buffer_unpin(BridgePinnedBuffer* buf);

/* ════════════════════════════════════════════════════════════════════════════
 * PART 9 — Retry Policy ve Failure Strategy Support
 *
 * [koprudsl.md §3] Retry mekanizması ve hata yayılma stratejisi.
 * ════════════════════════════════════════════════════════════════════════════ */

// Retry backoff type
typedef enum BridgeRetryBackoff {
    BRIDGE_RETRY_FIXED      = 0,  // Sabit gecikme
    BRIDGE_RETRY_LINEAR     = 1,  // Lineer artan
    BRIDGE_RETRY_EXPONENTIAL= 2,  // Üstel geri çekilme
} BridgeRetryBackoff;

// Retry configuration
typedef struct BridgeRetryConfig {
    uint32_t           max_attempts;
    uint32_t           base_delay_ms;
    uint32_t           max_delay_ms;
    BridgeRetryBackoff backoff;
} BridgeRetryConfig;

// Failure strategy
typedef enum BridgeFailureStrategy {
    BRIDGE_FAIL_STOP          = 0,  // Graph durur
    BRIDGE_FAIL_FALLBACK     = 1,  // Alternatif node'a geç
    BRIDGE_FAIL_PARTIAL      = 2,  // Bağımlı olmayanlar devam eder
    BRIDGE_FAIL_IGNORE        = 3,  // Hata loglanır ama devam eder
} BridgeFailureStrategy;

/* ── API: Retry execution ──────────────────────────────────────────────────── */
void* __bridge_exec_with_retry(void* (*fn)(void*),
                                 void* arg,
                                 const BridgeRetryConfig* config,
                                 bool (*is_retryable)(BridgeForeignError*));

/* ════════════════════════════════════════════════════════════════════════════
 * PART 10 — Conditional Effect Evaluation
 *
 * [koprudsl.md §1] Parametreye göre değişen effect'ler.
 * Örnek: np.add(a, b) → HeapAlloc; np.add(a, b, out=c) → yok
 * ════════════════════════════════════════════════════════════════════════════ */

// Effect condition type
typedef enum BridgeEffectCondition {
    BRIDGE_COND_ALWAYS      = 0,  // Her zaman uygula
    BRIDGE_COND_PARAM_NULL  = 1,  // Parametre NULL ise
    BRIDGE_COND_PARAM_NOT_NULL= 2, // Parametre NULL değilse
    BRIDGE_COND_PARAM_EQ    = 3,  // Parametre belirli değere eşitse
    BRIDGE_COND_PARAM_GT    = 4,  // Parametre belirli değerden büyükse
    BRIDGE_COND_PARAM_LT    = 5,  // Parametre belirli değerden küçükse
} BridgeEffectCondition;

// Conditional effect rule
typedef struct BridgeConditionalEffect {
    BridgeEffectCondition condition;
    int                   param_index;     // Hangi parametre?
    void*                 condition_value; // Koşul değeri
    uint32_t              effect_bits;     // Effect bitmask (DSLEffect)
} BridgeConditionalEffect;

/* ── API: Conditional effect evaluation ───────────────────────────────────── */
uint32_t __bridge_eval_conditional_effects(const BridgeConditionalEffect* rules,
                                             int rule_count,
                                             void** params,
                                             int param_count);

#ifdef __cplusplus
}
#endif

#endif /* BRIDGE_RUNTIME_H_INCLUDED */