// ======================================================================
// bridge_dsl.h — Köprü DSL Capability Descriptor Tanımları
// ======================================================================
// GraphDSL / NodeDSL / EdgeDSL / ContractDSL
//
// OOP Requiem entegrasyonu: her DSL bir DSLCapabilityDescriptor döner.
// TypeChecker, context/privilege/effect ihlallerini compile-time yakalar.
//
// IR Lowering → irgen_dsl.cpp:
//   lowerGraphDecl    → __graph_<name>_descriptor
//   lowerNodeDecl     → __node_<name>_descriptor
//   lowerEdgeDecl     → __edge_<src>_<dst>_descriptor
//   lowerContractDecl → __contract_<name>_descriptor
// ======================================================================

#pragma once
#include "dsl.h"
#include <vector>
#include <memory>

namespace corelang::dsl {

// ── GraphDSL ─────────────────────────────────────────────────────────────────
// Pure metadata, sıfır runtime effect, Any context.
class GraphDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "GraphDSL";
        d.namespacePrefix  = "graph";
        d.effects          = DSLEffect::PolicyHint;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason = nullptr;
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override {
        (void)e; (void)ctx; return nullptr;
    }
};

// ── NodeDSL ───────────────────────────────────────────────────────────────────
// Context kısıtlaması node'un domain'ine göre TypeChecker tarafından uygulanır.
// Bu descriptor genel ortak kısıtı tanımlar — domain-specific check
// type_checker.cpp'de validateBridgeNodeDecl'de yapılır.
class NodeDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "NodeDSL";
        d.namespacePrefix  = "node";
        d.effects          = DSLEffect::PolicyHint;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason = nullptr;
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override {
        (void)e; (void)ctx; return nullptr;
    }
};

// ── EdgeDSL ───────────────────────────────────────────────────────────────────
// Pure metadata. Her context'te yasal, sıfır runtime effect.
class EdgeDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "EdgeDSL";
        d.namespacePrefix  = "edge";
        d.effects          = DSLEffect::PolicyHint;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = true;
        d.pureIfArgsPure   = true;
        d.contextRestrictionReason = nullptr;
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override {
        (void)e; (void)ctx; return nullptr;
    }
};

// ── ContractDSL ───────────────────────────────────────────────────────────────
// Dış runtime bağlama — GC / exception / unknown ABI.
// Interrupt, Freestanding Kernel, GPU device context'te YASAK:
//   - GIL acquire → interrupt context'te deadlock
//   - GC pause    → realtime latency ihlali
//   - Foreign exception → kernel/GPU'da unhandled
//
// [koprudsl.md §1] foreign_contract DSL genişletmeleri:
//   - version constraint: ">=1.24, <3.0" formatında versiyon bağlama
//   - conditional effect: "out.is_none() ? [HeapAlloc] : []"
//   - trusted_contract: "#[trusted_contract(author: ..., verified: false)]"
//   - async_model: Tokio_1_x, PythonAsyncio, Blocking
class ContractDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "ContractDSL";
        d.namespacePrefix  = "contract";
        d.effects          = DSLEffect::PolicyHint | DSLEffect::TrustCheck |
                             DSLEffect::GCAlloc | DSLEffect::ForeignCall |
                             DSLEffect::ForeignExc | DSLEffect::GILAcquire |
                             DSLEffect::AsyncRuntime;
        d.allowedContexts  = DSLContext::Normal    |
                             DSLContext::UnsafeBlock |
                             DSLContext::GPUHost;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "contract:: foreign runtime calls forbidden in interrupt handlers "
            "(GIL deadlock risk), kernel freestanding context (no ABI), "
            "and GPU device kernels (no foreign call mechanism on device)";
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override {
        (void)e; (void)ctx; return nullptr;
    }
};

// ── TrustedContract Attribute ───────────────────────────────────────────────────
// [koprudsl.md §1] Kontrat doğrulama durumu:
//   verified: false → compiler warning verir, --strict-contracts ile error
//   verified: true → CI'da doğrulandı
struct TrustedContractAttr {
    const char* author;        // Kontratı yazan kişi/kurum
    const char* verified_by;   // Doğrulama yöntemi: "static_analysis", "runtime_test", "manual"
    bool       verified;       // Doğrulandı mı?
    uint32_t   verify_date;  // Doğrulama tarihi (YYYYMMDD)
};

// ── ConditionalEffect Support ───────────────────────────────────────────────────
// [koprudsl.md §1] Parametreye göre değişen effect'ler.
// Örnek: np.add(a, b) → HeapAlloc; np.add(a, b, out=c) → yok
struct ConditionalEffectRule {
    const char*         param_name;     // Hangi parametre?
    int                 param_index;    // Parametre indeksi
    DSLEffect           condition;      // Koşul tipi
    const char*         condition_val;  // Koşul değeri (nullable)
    DSLEffect           effect_when_true;   // Koşul true ise effect
    DSLEffect           effect_when_false;  // Koşul false ise effect
};

// ── AsyncModel Annotation ───────────────────────────────────────────────────────
// [koprudsl.md §2] Async model karışık kullanım compile-time yasak.
// Kontrat seviyesinde async model belirtilir.
struct AsyncModelAnnotation {
    AsyncModel          model;          // Async model tipi
    const char*         runtime_version; // Runtime versiyon constraint
    bool                blocking_allowed; // Blocking çağrıya izin var mı?
    uint32_t            max_concurrent; // Maksimum eşzamanlı çağrı
};

// ── ForeignContract Descriptor (Genişletilmiş) ───────────────────────────────────
// [koprudsl.md §1] foreign_contract yapısı
struct ForeignContractDesc {
    const char*         name;           // Kontrat adı: "numpy", "rust_lib"
    const char*         origin;        // Runtime origin: "python", "rust", "c"
    const char*         abi_version;  // ABI versiyonu: "CPython_3_11"
    const char*         version_min;   // Minimum versiyon: ">=1.24"
    const char*         version_max;   // Maksimum versiyon: "<3.0"

    // Effect ve context constraints
    DSLEffect           effects;        // Effect bitmask
    DSLContext          context_allowed;    // İzin verilen context
    DSLContext          context_forbidden; // Yasak context

    // Ownership ve error model
    OwnershipCategory   ownership;      // Varsayılan ownership
    ErrorModel         error_model;    // Hata modeli
    AsyncModel         async_model;    // Async model

    // Trust
    TrustedContractAttr trust_info;      // Doğrulama bilgisi

    // Retry ve failure
    RetryPolicy         retry_policy;   // Retry politikası
    FailureStrategy     failure_strategy; // Hata stratejisi
    const char*         fallback_fn;   // Alternatif fonksiyon

    // Conditional effects
    uint32_t           conditional_effect_count;
    ConditionalEffectRule* conditional_effects;

    // Async annotation
    AsyncModelAnnotation async_annotation;
};

// DSLDispatcher'a tüm Köprü DSL'lerini kaydet
// [UPGRADE v2] İmza DSLRegistry& alır — dsl_registry.h forward declare yeterli.
void registerBridgeDSLs(class DSLRegistry& reg);

} // namespace corelang::dsl
