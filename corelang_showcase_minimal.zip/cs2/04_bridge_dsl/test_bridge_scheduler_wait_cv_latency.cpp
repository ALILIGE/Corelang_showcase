#include "../src/dsl/bridge_scheduler.h"
#include <cstdio>
#include <cstring>
#include <chrono>
using namespace corelang::bridge;

void instant_execute(BridgeWorkItem* item) {
    int* data = new int(42);
    item->output_ptr = data;
}

int main() {
    BridgeSchedulerConfig cfg; memset(&cfg, 0, sizeof(cfg));
    cfg.native_threads = 1;
    BridgeScheduler* sched = __bridge_scheduler_create(&cfg);
    __bridge_scheduler_start(sched);

    BridgeWorkItem item; memset(&item, 0, sizeof(item));
    item.node_name = "fast_node";
    item.content_hash = 0x1ull;
    item.execute = instant_execute;

    auto t0 = std::chrono::steady_clock::now();
    __bridge_scheduler_submit(sched, &item);
    int rc = __bridge_scheduler_wait_node(sched, "fast_node", 5000);
    auto t1 = std::chrono::steady_clock::now();
    auto elapsed_us = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count();

    printf("wait_node rc=%d, elapsed=%lld us\n", rc, (long long)elapsed_us);
    // Eski busy-poll implementasyonu ile bu süre tipik olarak 0-10ms (0-10000us)
    // arasında rastgele dağılırdı (10ms'lik poll penceresine bağlı). Condition
    // variable ile bu süre, gerçek işlemin kendi süresine (mikrosaniyeler) çok
    // daha yakın olmalı — yüzlerce mikrosaniyeyi aşmamalı (thread scheduling
    // overhead'i hariç).
    int latency_ok = (elapsed_us < 5000); // 5ms'den az — eski mekanizmada garanti edilemezdi

    // wait_all testi
    auto t2 = std::chrono::steady_clock::now();
    int rc2 = __bridge_scheduler_wait_all(sched, 5000);
    auto t3 = std::chrono::steady_clock::now();
    auto elapsed2_us = std::chrono::duration_cast<std::chrono::microseconds>(t3 - t2).count();
    printf("wait_all rc=%d, elapsed=%lld us (already completed, should return near-instantly)\n",
           rc2, (long long)elapsed2_us);
    int latency_ok2 = (elapsed2_us < 5000);

    int pass = (rc == 0) && (rc2 == 0) && latency_ok && latency_ok2;
    printf("\n%s\n", pass ? "WAIT_NODE/WAIT_ALL CV LATENCY TEST PASSED" : "TEST FAILED");

    __bridge_scheduler_destroy(sched);
    return pass ? 0 : 1;
}
