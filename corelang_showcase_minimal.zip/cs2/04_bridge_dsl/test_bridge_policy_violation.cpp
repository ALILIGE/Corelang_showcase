#include "../src/dsl/bridge_graph.h"
#include "../src/dsl/bridge_incident.h"
#include <cstdio>
#include <cstring>
using namespace corelang::bridge;

int main() {
    // === SENARYO 1: Temiz node — violation BULUNMAMALI (nullptr) ===
    BridgeGraph* g1 = __bridge_graph_create("clean_test");
    BridgeNode n1; memset(&n1, 0, sizeof(n1));
    n1.name = "clean_node";
    n1.kind = BRIDGE_NODE_COMPUTE;
    n1.domain = BRIDGE_DOMAIN_NATIVE_CPU;
    n1.effects.effects = 0;
    n1.determinism = corelang::dsl::DeterminismLevel::Strong;
    __bridge_graph_add_node(g1, &n1);

    BridgePolicy p1; memset(&p1, 0, sizeof(p1));
    p1.name = "strict_policy";
    p1.effects_forbidden = (1u << 14);
    p1.deterministic_required = true;
    __bridge_graph_add_policy(g1, &p1);

    BridgePolicyViolation* v1 = __bridge_check_policy_violation(g1, "strict_policy");
    printf("SENARYO 1 (clean node): result=%s (expected nullptr)\n", v1 ? "non-null (BUG)" : "nullptr (correct)");
    int t1 = (v1 == nullptr);
    if (v1) __bridge_policy_violation_destroy(v1);
    __bridge_graph_destroy(g1);

    // === SENARYO 2: Gerçek ihlal — violation BULUNMALI (non-null) ===
    BridgeGraph* g2 = __bridge_graph_create("violation_test");
    BridgeNode n2; memset(&n2, 0, sizeof(n2));
    n2.name = "bad_node";
    n2.kind = BRIDGE_NODE_COMPUTE;
    n2.domain = BRIDGE_DOMAIN_NATIVE_CPU;
    n2.effects.effects = (1u << 14); // GCAlloc — yasak effect
    n2.determinism = corelang::dsl::DeterminismLevel::Strong;
    __bridge_graph_add_node(g2, &n2);

    BridgePolicy p2; memset(&p2, 0, sizeof(p2));
    p2.name = "strict_policy2";
    p2.effects_forbidden = (1u << 14);
    __bridge_graph_add_policy(g2, &p2);

    BridgePolicyViolation* v2 = __bridge_check_policy_violation(g2, "strict_policy2");
    printf("SENARYO 2 (bad node): result=%s (expected non-null)\n", v2 ? "non-null (correct)" : "nullptr (BUG)");
    int t2 = (v2 != nullptr) && (v2->violated_rule != nullptr) &&
             (strcmp(v2->violated_rule, "effects_forbidden") == 0);
    if (v2) {
        printf("  violated_rule=%s reason=%s chain_length=%u\n",
               v2->violated_rule, v2->reason, v2->chain_length);
        __bridge_policy_violation_destroy(v2);
    }
    __bridge_graph_destroy(g2);

    // === SENARYO 3: Bilinmeyen policy — nullptr olmalı (regresyon kontrolü) ===
    BridgeGraph* g3 = __bridge_graph_create("unknown_policy_test");
    BridgePolicyViolation* v3 = __bridge_check_policy_violation(g3, "nonexistent_policy");
    printf("SENARYO 3 (unknown policy): result=%s (expected nullptr)\n", v3 ? "non-null (BUG)" : "nullptr (correct)");
    int t3 = (v3 == nullptr);
    __bridge_graph_destroy(g3);

    int pass = t1 && t2 && t3;
    printf("\n%s\n", pass ? "POLICY VIOLATION FIX TEST PASSED" : "TEST FAILED");
    return pass ? 0 : 1;
}
