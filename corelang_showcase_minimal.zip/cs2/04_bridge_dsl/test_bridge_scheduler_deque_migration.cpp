#include "../src/dsl/bridge_scheduler.h"
#include <cstdio>
#include <cstring>
#include <vector>
#include <atomic>
using namespace corelang::bridge;

static std::atomic<int> g_total_executed{0};

void counting_execute(BridgeWorkItem* item) {
    g_total_executed++;
}

int main() {
    BridgeSchedulerConfig cfg; memset(&cfg, 0, sizeof(cfg));
    cfg.native_threads = 4; // paralel worker'lar
    BridgeScheduler* sched = __bridge_scheduler_create(&cfg);
    __bridge_scheduler_start(sched);

    const int N = 500;
    std::vector<BridgeWorkItem> items(N);
    std::vector<std::string> names(N);
    for (int i = 0; i < N; ++i) {
        names[i] = "node_" + std::to_string(i);
        memset(&items[i], 0, sizeof(BridgeWorkItem));
        items[i].node_name = names[i].c_str();
        items[i].content_hash = (uint64_t)i;
        items[i].execute = counting_execute;
        __bridge_scheduler_submit(sched, &items[i]);
    }

    int rc = __bridge_scheduler_wait_all(sched, 10000);
    printf("wait_all rc=%d, total_executed=%d (expected %d)\n", rc, g_total_executed.load(), N);

    int pass = (rc == 0) && (g_total_executed.load() == N);
    printf("\n%s\n", pass ? "DEQUE MIGRATION TEST PASSED (500 items, 4 workers)" : "TEST FAILED");

    __bridge_scheduler_destroy(sched);
    return pass ? 0 : 1;
}
