// ======================================================================
// dsl_faz2.cpp -- Faz 2 DSL Kayit ve Descriptor Dogrulama
// ======================================================================
// Faz 2 DSL'lerini DSLDispatcher'a kaydeder.
// Kayit sirasinda her DSL'in describe() ciktisi dogrulanir:
//   name null/bos -> std::abort() (gelistirici hatasi, runtime degil)
// Gercek lowering mantigi: irgen_dsl.cpp'de.
// ======================================================================

#include "dsl_faz2.h"
#include "dsl_registry.h"
#include "../frontend/ast.h"

namespace corelang::dsl {

// [UPGRADE v2] verifyDescriptor() kaldırıldı.
// Bu kontrol artık DSLRegistry::add() içinde yapılıyor:
//   name null/boş → stderr + std::abort() (aynı garanti, tek yer).

// [UPGRADE v2] İmza değişti: DSLRegistry& alır.
// verifyDescriptor() artık DSLRegistry::add() içinde yapılıyor —
// eski addVerified lambda kaldırıldı, duplicate mantık yok.
// StateMachineDSL::canHandle() — statemachine::fn() expr cagrilarini tanimak icin.
// isCallTo helper dsl.cpp'de static tanimli; burada tekrar tanimliyoruz.
static bool isCallToNs(const corelang::Expr* e, const std::string& ns) {
    if (!e || e->kind != corelang::Expr::Kind::Call) return false;
    auto* call = static_cast<const corelang::CallExpr*>(e);
    if (!call->callee) return false;
    if (call->callee->kind == corelang::Expr::Kind::Field) {
        auto* field = static_cast<const corelang::FieldExpr*>(call->callee.get());
        if (field->base && field->base->kind == corelang::Expr::Kind::Ident) {
            auto* id = static_cast<const corelang::IdentExpr*>(field->base.get());
            return id->name == ns;
        }
    }
    return false;
}

bool StateMachineDSL::canHandle(const corelang::Expr* e) const {
    return isCallToNs(e, "statemachine");
}

void registerFaz2DSLs(DSLRegistry& reg) {
    reg.add(std::make_unique<StateMachineDSL>());
    reg.add(std::make_unique<AssumptionModuleDSL>());
    reg.add(std::make_unique<DistortDSL>());
    reg.add(std::make_unique<IntentWatchDSL>());
    reg.add(std::make_unique<DriverDSL>());
    reg.add(std::make_unique<PolicyDSL>());
    reg.add(std::make_unique<BuildDSL>());
}

} // namespace corelang::dsl
