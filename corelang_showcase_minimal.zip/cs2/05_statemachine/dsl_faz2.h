// ======================================================================
// dsl_faz2.h — CoreLang Faz 2 DSL Tanimlari (Guvenlik Mimarisi DSL'leri)
// ======================================================================
// Faz 2 DSL'leri, Stardust Crusaders guvenlik mimarisinin compiler
// entegrasyonunu saglar. Her biri DSLFrontend subclass'idir ve
// OOP Requiem capability descriptor sistemiyle korunur.
//
// DSL'ler ve mimarideki karsiliklari (bolum1_guvenlik_mimarisi.md):
//   StateMachineDSL      — statemachine keyword; compile-time state dogrulama
//   AssumptionModuleDSL  — assumption_module; ZA WARUDO gerceklik olcumu (Ring0)
//   DistortDSL           — distort; GER kontrollu non-determinism (Ring0)
//   IntentWatchDSL       — intent_watch; Wonder of U niyet tespiti (Ring0)
//   DriverDSL            — driver{...}; protokol-bazli surucu sentezi (Ring0)
//   PolicyDSL            — policy{...}; kernel performans politikasi (metadata)
//
// Kural: Tum Faz2 DSL'lerin gercek lowering mantigi irgen_dsl.cpp'dedir.
//        Bu dosya yalnizca capability descriptor ve sinif tanimlarini icerir.
//
// Statik assert'ler: Faz2 kind sabitlerinin Faz1 enum degerleriyle
// cakismadigi derleme zamaninda dogrulanir.
// ======================================================================

#pragma once
#include "dsl.h"
#include "build_dsl.h"
#include "../frontend/ast.h"

// Static assert: verify all Faz2 kind constants are distinct from Faz1 enum values
static_assert(static_cast<int>(corelang::kDeclStateMachine)  == 100, "kDeclStateMachine must be 100");
static_assert(static_cast<int>(corelang::kDeclAssumptionMod) == 101, "kDeclAssumptionMod must be 101");
static_assert(static_cast<int>(corelang::kDeclIntentWatch)   == 102, "kDeclIntentWatch must be 102");
static_assert(static_cast<int>(corelang::kDeclDriver)        == 103, "kDeclDriver must be 103");
static_assert(static_cast<int>(corelang::kDeclPolicy)        == 104, "kDeclPolicy must be 104");
static_assert(static_cast<int>(corelang::kDeclPolicyApply)   == 105, "kDeclPolicyApply must be 105");
static_assert(static_cast<int>(corelang::kDeclBuild)         == 117, "kDeclBuild must be 117");
static_assert(static_cast<int>(corelang::kStmtDistort)       == 100, "kStmtDistort must be 100");

namespace corelang::dsl {

// ── StateMachineDSL ───────────────────────────────────────────────────────────
// Compile-time verified state machine definitions.
// Pure: no runtime side effects, generates descriptor data only.
class StateMachineDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "StateMachineDSL";
        d.namespacePrefix  = "statemachine"; // statemachine::transition(...) gibi cagrilar
        d.effects          = DSLEffect::PureCompute; // sadece metadata, sifir runtime etki
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = true;
        d.pureIfArgsPure   = true;
        d.contextRestrictionReason = nullptr;
        return d;
    }
    // statemachine:: namespace cagrilarini tanimak icin isCallTo kullanilir.
    // Eger statemachine::transition() gibi expr cagrilari gelirse
    // canHandle() true doner ve lowerExpr() cagrilir.
    // Stmt-level statemachine tanimi ayrica kDeclStateMachine ile islenir (irgen_dsl.cpp).
    bool canHandle(const Expr* e) const override;
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── AssumptionModuleDSL ───────────────────────────────────────────────────────
// ZA WARUDO: assumption violation detection engine.
// Ring0 only, kernel context, freestanding-compatible.
class AssumptionModuleDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "AssumptionModuleDSL";
        d.namespacePrefix  = "assume";
        d.effects          = DSLEffect::TrustCheck;
        d.allowedContexts  = DSLContext::Kernel | DSLContext::Freestanding;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::FreestandingOk;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "assumption_module requires Ring0 kernel context; "
            "not available in user-mode or GPU code";
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── DistortDSL ────────────────────────────────────────────────────────────────
// GER: controlled reality distortion engine.
// Ring0, kernel/unsafe only. Produces PolicyHint + rollback metadata.
class DistortDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "DistortDSL";
        // namespacePrefix = nullptr — DistortDSL stmt-only; expr call yok.
        // canHandle(expr) false döner, canHandleStmt(stmt) kStmtDistort'u tanır.
        d.namespacePrefix  = nullptr;
        d.effects          = DSLEffect::PolicyHint;
        d.allowedContexts  = DSLContext::Kernel | DSLContext::UnsafeBlock;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "distort requires Ring0 privilege and kernel/unsafe context; "
            "use is prohibited in user-mode, interrupt handlers, or GPU code";
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }

    // [UPGRADE v2] SAHTE-4 FIX'in kalıcı parçası.
    // DSLDispatcher::lowerStmt() artık önce canHandleStmt() soruyor.
    // kStmtDistort (100) olan statement'ları bu DSL işler.
    bool canHandleStmt(const Stmt* s) const override {
        return s && s->kind == kStmtDistort;
    }

    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── IntentWatchDSL ────────────────────────────────────────────────────────────
// Wonder of U: intent-based threat detection.
// Ring0, kernel only. Generates calamity table.
class IntentWatchDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "IntentWatchDSL";
        d.namespacePrefix  = "intent";
        d.effects          = DSLEffect::TrustCheck;
        d.allowedContexts  = DSLContext::Kernel;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "intent_watch requires Ring0 kernel context; "
            "calamity table generation is not valid outside the kernel";
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── DriverDSL ─────────────────────────────────────────────────────────────────
// İMMANUEL: hardware driver synthesis from protocol specs.
// Ring0, kernel/freestanding, x86 + MMIO + PortIO.
class DriverDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "DriverDSL";
        d.namespacePrefix  = "driver"; // driver::register_irq(...) gibi
        d.effects          = DSLEffect::MMIO | DSLEffect::PortIO | DSLEffect::Interrupt;
        d.allowedContexts  = DSLContext::Kernel | DSLContext::Freestanding | DSLContext::Interrupt;
        d.privilege        = DSLPrivilege::Ring0;
        d.targetReq        = DSLTargetReq::FreestandingOk;
        d.requiresDSL      = {"MemoryDSL"};
        d.licmSafe         = false;
        d.gvnSafe          = false;
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason =
            "driver synthesis requires Ring0 privilege, kernel/freestanding context, "
            "and MemoryDSL for MMIO register access";
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── PolicyDSL ─────────────────────────────────────────────────────────────────
// Kernel performance policy annotations.
// Pure hint: no runtime side effect at call site, only metadata.
class PolicyDSL : public DSLFrontend {
public:
    DSLCapabilityDescriptor describe() const override {
        DSLCapabilityDescriptor d;
        d.name             = "PolicyDSL";
        d.namespacePrefix  = "policy"; // policy::set_sched(...) gibi
        d.effects          = DSLEffect::PolicyHint;
        d.allowedContexts  = DSLContext::Any;
        d.privilege        = DSLPrivilege::Any;
        d.targetReq        = DSLTargetReq::Any;
        d.licmSafe         = true;
        d.gvnSafe          = false;   // policy apply must stay in prologue
        d.pureIfArgsPure   = false;
        d.contextRestrictionReason = nullptr;
        return d;
    }
    bool canHandle(const Expr* e) const override { (void)e; return false; }
    llvm::Value* lowerExpr(const Expr* e, void* ctx) override { (void)e; (void)ctx; return nullptr; }
    void         lowerStmt(const Stmt* s, void* ctx) override { (void)s; (void)ctx; }
};

// ── Registration helper ───────────────────────────────────────────────────────
// [UPGRADE v2] İmza DSLRegistry& alacak şekilde güncellendi.
// Eski: std::vector<std::unique_ptr<DSLFrontend>>&
// Yeni: DSLRegistry& — validateDependencies() otomatik uygulanır.
void registerFaz2DSLs(class DSLRegistry& reg);

} // namespace corelang::dsl
